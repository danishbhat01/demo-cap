"""PaddleOCR (PP-OCRv4, classic OCR) engine adapter.

Backend: paddleocr 2.7.x + paddlepaddle 2.6.x on CPU (Windows-safe stack;
Paddle 3.x PIR executor is broken on CPU — see project history).

Two environment workarounds live here (both verified):
1. torch-first import: paddle ships its own libiomp5md.dll which shadows torch's
   and breaks `import torch` with WinError 127. Importing torch first pins the
   correct DLL. Only the venv order matters; guarded for torch-less envs.
2. numpy>=2 compat shim for imgaug 0.4.0 (abandoned dep of paddleocr 2.7):
   restores `np.sctypes` so `import imgaug` works. imgaug is training-only and
   never executes during inference.
"""

from ocr_pipeline.core.base_engine import BaseOCREngine

try:
    import torch  # noqa: F401  (import first: OMP DLL shadowing, see above)
except ImportError:
    pass

try:
    import numpy as _np

    if not hasattr(_np, "sctypes"):
        _np.sctypes = {
            "float": [_np.float16, _np.float32, _np.float64],
            "int": [_np.int8, _np.int16, _np.int32, _np.int64],
            "uint": [_np.uint8, _np.uint16, _np.uint32, _np.uint64],
            "complex": [_np.complex64, _np.complex128],
            "bool": [_np.bool_],
        }
except ImportError:
    pass

try:
    from paddleocr import PaddleOCR
except ImportError:
    PaddleOCR = None


class PaddleEngine(BaseOCREngine):
    # Tunable hyperparameters (plan.md §4.2). Values are OUR pipeline defaults
    # (note: upstream use_angle_cls defaults False; we default True).
    DEFAULTS = {
        "use_angle_cls": True,
        "det_db_thresh": 0.3,
        "det_limit_side_len": 960,
    }

    def __init__(self, lang: str = "en", config: dict | None = None):
        cfg = dict(self.DEFAULTS)
        unknown = []
        for k, v in dict(config or {}).items():
            if k in cfg:
                cfg[k] = v
            else:
                unknown.append(k)
        if unknown:
            print(f"  ! Ignoring unknown PaddleOCR config keys: {unknown}")
        super().__init__(name=self._display_name(cfg), config=cfg)
        self.lang = lang
        self.params = cfg
        if PaddleOCR is None:
            self.ocr = None
            print("WARNING: paddleocr not found. Running in placeholder mode.")
        else:
            # Downloads det/cls/rec models on first run (~100-200 MB).
            self.ocr = PaddleOCR(
                use_angle_cls=cfg["use_angle_cls"],
                det_db_thresh=cfg["det_db_thresh"],
                det_limit_side_len=cfg["det_limit_side_len"],
                lang=lang,
                show_log=False,
            )
            print(f"Initialized PaddleOCR engine successfully! [{self.name}]")

    @classmethod
    def _display_name(cls, cfg: dict) -> str:
        """Folder/result name; suffix encodes non-default values side-by-side."""
        base = "PaddleOCR_PPStructure"
        parts = []
        if cfg.get("use_angle_cls", True) is False:
            parts.append("noangle")
        if cfg.get("det_db_thresh", 0.3) != 0.3:
            parts.append(f"t{str(cfg['det_db_thresh']).replace('.', 'p')}")
        if cfg.get("det_limit_side_len", 960) != 960:
            parts.append(f"s{cfg['det_limit_side_len']}")
        return base if not parts else f"{base}_{'_'.join(parts)}"

    def process_document(self, file_path: str) -> dict:
        if self.ocr is None:
            return {
                "text": "paddleocr is not installed.",
                "tables": [],
                "layout": [],
            }

        from ocr_pipeline.utils.document_converter import DocumentProcessor

        print("     [PaddleOCR] Running extraction...")
        try:
            import numpy as np

            images = DocumentProcessor.normalize_to_images(file_path, dpi=300)
            lines_out, layout = [], []
            for page_idx, pil_img in enumerate(images):
                img = np.array(pil_img.convert("RGB"))
                pages = self.ocr.ocr(img, cls=self.params["use_angle_cls"])
                if not pages or not pages[0]:
                    continue
                # Paddle returns lines roughly top-down; stabilize reading order.
                page_lines = sorted(pages[0], key=lambda ln: (min(p[1] for p in ln[0]), min(p[0] for p in ln[0])))
                for box, (text, conf) in page_lines:
                    text = (text or "").strip()
                    if not text:
                        continue
                    xs = [p[0] for p in box]
                    ys = [p[1] for p in box]
                    lines_out.append(text)
                    layout.append(
                        {
                            "label": "text",
                            "bbox": [float(min(xs)), float(min(ys)), float(max(xs)), float(max(ys))],
                            "text": text,
                            "confidence": float(conf),
                            "page": page_idx + 1,
                        }
                    )
            full_text = "\n".join(lines_out)
            return self.standardize_output(
                text=full_text,
                layout=layout,
                tables=[],
                meta={"pages": len(images), "lines": len(lines_out), "dpi": 300, "lang": self.lang, "params": self.params},
            )
        except Exception as e:
            raise RuntimeError(f"PaddleOCR extraction failed for '{file_path}': {e}") from e
