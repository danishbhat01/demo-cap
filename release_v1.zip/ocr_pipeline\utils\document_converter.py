"""Input normalization utilities (Phase 1 of review_plan.md).

Problem (see review_plan §2B): engines accept different inputs —
Surya / PaddleOCR want images, MinerU / Docling accept PDFs natively,
and DOCX needs conversion. This module centralizes that logic so each
engine adapter stays thin.

Design choices:
- PyMuPDF (fitz) is the primary PDF rasterizer: pure-wheel on Windows,
  no poppler dependency (unlike pdf2image). pdf2image is kept as an
  optional fallback if installed.
- All heavy imports are lazy so `import ocr_pipeline` never fails when
  an optional engine dependency is missing.
- DOCX -> images has no lightweight faithful renderer on Windows without
  LibreOffice/Word; we fall back to rendering extracted text onto PIL
  canvases so image-only engines can still run smoke tests.
"""

import os
from typing import List

SUPPORTED_IMAGE_EXTS = {".png", ".jpg", ".jpeg", ".tif", ".tiff", ".bmp", ".webp"}
SUPPORTED_EXTS = SUPPORTED_IMAGE_EXTS | {".pdf", ".docx"}


class UnsupportedFormatError(ValueError):
    pass


class DocumentProcessor:
    """Stateless helpers to normalize PDF / DOCX / image inputs."""

    # -- detection / validation -------------------------------------------

    @staticmethod
    def detect_type(file_path: str) -> str:
        ext = os.path.splitext(file_path)[1].lower()
        if ext == ".pdf":
            return "pdf"
        if ext == ".docx":
            return "docx"
        if ext in SUPPORTED_IMAGE_EXTS:
            return "image"
        raise UnsupportedFormatError(
            f"Unsupported file type '{ext}' for '{file_path}'. "
            f"Supported: {sorted(SUPPORTED_EXTS)}"
        )

    @staticmethod
    def ensure_readable(file_path: str) -> str:
        """Validate path exists and is non-empty. Returns detected type."""
        if not os.path.exists(file_path):
            raise FileNotFoundError(f"File not found: {file_path}")
        if os.path.getsize(file_path) == 0:
            raise ValueError(
                f"File is empty (0 bytes): {file_path}. "
                "Replace it with a real document to run the pipeline."
            )
        return DocumentProcessor.detect_type(file_path)

    @staticmethod
    def get_page_count(file_path: str) -> int:
        doc_type = DocumentProcessor.ensure_readable(file_path)
        if doc_type == "image":
            return 1
        if doc_type == "pdf":
            try:
                import pymupdf

                with pymupdf.open(file_path) as doc:
                    return len(doc)
            except ImportError:
                # Fallback: pdf2image/pypdf if pymupdf missing
                try:
                    from pypdf import PdfReader

                    return len(PdfReader(file_path).pages)
                except ImportError as exc:
                    raise ImportError(
                        "get_page_count for PDFs needs PyMuPDF (`pip install pymupdf`) "
                        "or pypdf."
                    ) from exc
        # docx: approximate 1 "page" per ~500 words (no real pagination)
        text = DocumentProcessor.docx_to_text(file_path)
        return max(1, len(text.split()) // 500 + 1)

    # -- PDF -> images -----------------------------------------------------

    @staticmethod
    def pdf_to_images(file_path: str, dpi: int = 300, max_pages: int | None = None) -> List:
        """Rasterize a PDF into a list of PIL Images (high-res for OCR)."""
        DocumentProcessor.ensure_readable(file_path)
        try:
            import pymupdf
        except ImportError:
            return DocumentProcessor._pdf_to_images_via_pdf2image(
                file_path, dpi=dpi, max_pages=max_pages
            )

        zoom = dpi / 72.0
        images = []
        with pymupdf.open(file_path) as doc:
            pages = doc[:max_pages] if max_pages else doc
            for page in pages:
                pix = page.get_pixmap(matrix=pymupdf.Matrix(zoom, zoom))
                if pix.alpha:  # drop alpha for consistent RGB OCR input
                    pix = pymupdf.Pixmap(pix, 0)
                try:
                    from PIL import Image as _Image

                    images.append(
                        _Image.frombytes("RGB", (pix.width, pix.height), pix.samples)
                    )
                except Exception:
                    # Fallback for unusual colorspaces via in-memory PNG
                    import io

                    from PIL import Image as _Image2

                    images.append(_Image2.open(io.BytesIO(pix.tobytes("png"))).convert("RGB"))
        return images

    @staticmethod
    def _pdf_to_images_via_pdf2image(file_path, dpi=300, max_pages=None) -> List:
        try:
            from pdf2image import convert_from_path
        except ImportError as exc:
            raise ImportError(
                "PDF rasterization needs PyMuPDF (`pip install pymupdf`) "
                "or pdf2image + poppler."
            ) from exc
        kwargs = {"dpi": dpi}
        if max_pages:
            kwargs["first_page"] = 1
            kwargs["last_page"] = max_pages
        return convert_from_path(file_path, **kwargs)

    # -- DOCX ---------------------------------------------------------------

    @staticmethod
    def docx_to_text(file_path: str) -> str:
        DocumentProcessor.ensure_readable(file_path)
        try:
            import docx
        except ImportError as exc:
            raise ImportError(
                "DOCX support needs python-docx (`pip install python-docx`)."
            ) from exc
        doc = docx.Document(file_path)
        paras = [p.text for p in doc.paragraphs]
        tables = []
        for t in doc.tables:
            for row in t.rows:
                tables.append(" | ".join(c.text for c in row.cells))
        return "\n".join(paras + tables).strip()

    @staticmethod
    def docx_to_images(file_path: str, width: int = 1700, font_size: int = 28) -> List:
        """Best-effort DOCX -> images by rendering extracted text on canvases.

        Not a faithful layout render (that needs Word/LibreOffice), but lets
        image-only engines run smoke tests without extra system deps.
        """
        from PIL import Image, ImageDraw

        text = DocumentProcessor.docx_to_text(file_path)
        if not text.strip():
            raise ValueError(f"No extractable text in DOCX: {file_path}")
        # Paginate naively: ~40 lines per canvas
        words, lines, cur = text.split(), [], ""
        for w in words:
            trial = f"{cur} {w}".strip()
            if len(trial) > 90:
                lines.append(cur)
                cur = w
            else:
                cur = trial
        if cur:
            lines.append(cur)

        images, page_lines = [], 38
        try:
            from PIL import ImageFont

            try:
                draw_font = ImageFont.load_default(size=font_size)
            except TypeError:  # older Pillow without size param
                draw_font = ImageFont.load_default()
        except ImportError:
            draw_font = None
        for i in range(0, len(lines), page_lines):
            img = Image.new("RGB", (width, 2200), "white")
            d = ImageDraw.Draw(img)
            for j, line in enumerate(lines[i : i + page_lines]):
                d.text((80, 60 + j * 52), line, fill="black", font=draw_font)
            images.append(img)
        return images

    # -- unified entry points -------------------------------------------------

    @staticmethod
    def normalize_to_images(file_path: str, dpi: int = 300) -> List:
        """Return document pages as PIL Images regardless of input format."""
        from PIL import Image

        doc_type = DocumentProcessor.ensure_readable(file_path)
        if doc_type == "pdf":
            return DocumentProcessor.pdf_to_images(file_path, dpi=dpi)
        if doc_type == "image":
            return [Image.open(file_path).convert("RGB")]
        if doc_type == "docx":
            return DocumentProcessor.docx_to_images(file_path)
        raise UnsupportedFormatError(doc_type)  # pragma: no cover

    @staticmethod
    def native_text_fallback(file_path: str) -> str:
        """Fast native text extraction (no OCR): PDF via PyMuPDF, DOCX via python-docx.

        Useful as a sanity baseline and for ground-truth drafting. Returns ""
        for scanned-image inputs where native text is genuinely absent.
        """
        doc_type = DocumentProcessor.ensure_readable(file_path)
        if doc_type == "docx":
            return DocumentProcessor.docx_to_text(file_path)
        if doc_type == "pdf":
            try:
                import pymupdf

                with pymupdf.open(file_path) as doc:
                    return "\n".join(p.get_text() for p in doc).strip()
            except ImportError:
                return ""
        return ""  # images have no native text layer
