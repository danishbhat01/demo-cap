import importlib
import json
import os
import sys
from ocr_pipeline.core.pipeline import PipelineManager
from ocr_pipeline.core.evaluator import PipelineEvaluator

# Lazy registry: (display name, module, class) — imported only if selected,
# so unselected heavy engines (torch/paddle) never touch memory.
# Phase 3 sanitization: Surya + PaddleOCR-VL removed (backups in Temp/opencode).
ENGINE_REGISTRY = {
    "1": ("PaddleOCR (PP-Structure)", "ocr_pipeline.engines.paddle_engine", "PaddleEngine"),
    "2": ("MinerU (flash tier)", "ocr_pipeline.engines.mineru_engine", "MinerUEngine"),
    "3": ("Docling + RapidOCR", "ocr_pipeline.engines.docling_engine", "DoclingEngine"),
}

VALID_EXTENSIONS = {".pdf", ".png", ".jpg", ".jpeg", ".docx"}


def _console():
    try:
        from rich.console import Console

        return Console()
    except ImportError:
        return None


def _print_menu(console, title, items):
    """items: dict key -> label. Rich table if available, else plain print."""
    if console is None:
        print(f"\n{title}:")
        for key, label in items.items():
            print(f"  [{key}] {label}")
        print("  [A] All")
        return
    from rich.table import Table

    table = Table(title=title, show_header=True, header_style="bold cyan")
    table.add_column("Key", style="yellow", width=6)
    table.add_column("Option")
    for key, label in items.items():
        table.add_row(key, label)
    table.add_row("A", "All")
    console.print(table)


def _prompt_selection(prompt_text, valid_keys):
    """Parse '1,3' / 'A' input. Returns list of keys. Raises EOFError upstream."""
    raw = input(prompt_text).strip().upper()
    if raw == "A" or raw == "ALL":
        return list(valid_keys)
    picked = []
    for part in raw.replace(";", ",").split(","):
        part = part.strip()
        if not part:
            continue
        if part not in valid_keys:
            print(f"  Ignoring unknown option: '{part}'")
            continue
        if part not in picked:
            picked.append(part)
    return picked


TUNABLE_ENGINES = ("1", "3")  # Paddle, Docling accept config= (MinerU: flash only)


def _load_engine(key, config=None):
    label, module_path, class_name = ENGINE_REGISTRY[key]
    try:
        module = importlib.import_module(module_path)
        cls = getattr(module, class_name)
        if key in TUNABLE_ENGINES and config is not None:
            return cls(config=config)
        return cls()
    except Exception as exc:  # missing dep / model weights / DLL clash
        print(f"  ! Skipping {label}: failed to load ({exc})")
        return None


def _ask_bool(prompt, default):
    raw = input(f"{prompt} [{'Y/n' if default else 'y/N'}]: ").strip().lower()
    if not raw:
        return default
    return raw in ("y", "yes", "1", "true")


def _ask_float(prompt, default, lo=None, hi=None):
    raw = input(f"{prompt} [{default}]: ").strip()
    if not raw:
        return default
    try:
        val = float(raw)
        if (lo is None or val >= lo) and (hi is None or val <= hi):
            return val
    except ValueError:
        pass
    print(f"  Invalid — using default {default}.")
    return default


def _ask_int(prompt, default, lo=1):
    raw = input(f"{prompt} [{default}]: ").strip()
    if not raw:
        return default
    try:
        val = int(raw)
        if val >= lo:
            return val
    except ValueError:
        pass
    print(f"  Invalid — using default {default}.")
    return default


def _ask_choice(prompt, options, default):
    print(f"{prompt} [{'/'.join(options)}, default {default}]: ", end="")
    raw = input().strip().lower()
    if not raw:
        return default
    if raw in options:
        return raw
    print(f"  Invalid — using default {default}.")
    return default


def _prompt_paddle_config():
    """Default vs Advanced hyperparameters for PaddleOCR (plan.md §4.1)."""
    from ocr_pipeline.engines.paddle_engine import PaddleEngine

    defaults = PaddleEngine.DEFAULTS
    print("\nPaddleOCR configuration:")
    print("  [1] Default (angle_cls=True, thresh=0.3, side_len=960)")
    print("  [2] Advanced hyperparameters")
    try:
        choice = input("Select PaddleOCR config [1/2, default 1]: ").strip()
    except EOFError:
        return None
    if choice != "2":
        return dict(defaults)

    def ask_bool(prompt, default):
        return _ask_bool(prompt, default)

    def ask_float(prompt, default, lo=0.0, hi=1.0):
        return _ask_float(prompt, default, lo=lo, hi=hi)

    def ask_int(prompt, default, lo=1):
        return _ask_int(prompt, default, lo=lo)

    return {
        "use_angle_cls": ask_bool("  Angle classification (fix rotated text)?", defaults["use_angle_cls"]),
        "det_db_thresh": ask_float("  DB detection threshold 0..1 (lower = more sensitive)?", defaults["det_db_thresh"]),
        "det_limit_side_len": ask_int("  Long-side resize limit px (1500 for dense diagrams)?", defaults["det_limit_side_len"]),
    }


def _prompt_docling_config():
    """Default vs Advanced hyperparameters for Docling (plan.md §4.1)."""
    from ocr_pipeline.engines.docling_engine import DoclingEngine

    defaults = DoclingEngine.DEFAULTS
    print("\nDocling configuration:")
    print("  [1] Default (rapidocr, force_ocr=False, image_scale=1.0)")
    print("  [2] Advanced hyperparameters")
    try:
        choice = input("Select Docling config [1/2, default 1]: ").strip()
    except EOFError:
        return None
    if choice != "2":
        return dict(defaults)

    backend = _ask_choice("  OCR backend", ["rapidocr", "easyocr", "tesseract"], defaults["ocr_backend"])
    if backend == "tesseract":
        print("  NOTE: tesseract needs the system binary on PATH (not installed here).")
    if backend == "easyocr":
        print("  NOTE: easyocr downloads ~100MB models on first use.")
    return {
        "ocr_backend": backend,
        "force_ocr": _ask_bool("  Force vision OCR over full pages (ignore embedded text)?", defaults["force_ocr"]),
        "image_scale": _ask_float("  PDF rasterization scale (>1 = sharper but slower)?", defaults["image_scale"], lo=0.1),
    }


def _find_ground_truth(ground_truths_dir: str, base_name: str) -> str | None:
    """plan.md §2.1: <basename>.json first, then <basename>.md, else None."""
    for ext in (".json", ".md"):
        candidate = os.path.join(ground_truths_dir, f"{base_name}{ext}")
        if os.path.exists(candidate):
            return candidate
    return None


def _collect_test_files(test_docs_dir):
    os.makedirs(test_docs_dir, exist_ok=True)
    files = [
        os.path.join(test_docs_dir, f)
        for f in sorted(os.listdir(test_docs_dir))
        if os.path.splitext(f)[1].lower() in VALID_EXTENSIONS
    ]
    if not files:
        sample_file = os.path.join(test_docs_dir, "sample.pdf")
        try:
            import pymupdf

            doc = pymupdf.open()
            page = doc.new_page()
            page.insert_text(
                (72, 72),
                "This is the expected, correct text extracted from the document.",
            )
            doc.save(sample_file)
            doc.close()
            print(f"Generated sample PDF at '{sample_file}'.")
            files.append(sample_file)
        except ImportError:
            print("PyMuPDF not installed; cannot auto-generate sample PDF.")
    return files


def main():
    console = _console()
    output_directory = "comparison_outputs"
    test_docs_dir = "test_docs"

    # 1. Discover documents
    test_files = _collect_test_files(test_docs_dir)
    if not test_files:
        print(f"No documents found in '{test_docs_dir}'. Add a PDF/image/DOCX and retry.")
        sys.exit(1)

    # 2. Prompt: files
    file_items = {str(i + 1): os.path.basename(p) for i, p in enumerate(test_files)}
    _print_menu(console, "Documents in test_docs", file_items)
    try:
        picked_files = _prompt_selection(
            "Select files to run (comma separated, e.g. '1,2' or 'A'): ", file_items
        )
    except EOFError:
        print("\nNo input available (non-interactive shell). Aborting.")
        sys.exit(1)
    if not picked_files:
        print("No files selected. Nothing to do.")
        sys.exit(0)
    selected_files = [test_files[int(k) - 1] for k in picked_files]

    # 3. Prompt: engines
    engine_items = {k: v[0] for k, v in ENGINE_REGISTRY.items()}
    _print_menu(console, "Available OCR Engines", engine_items)
    try:
        picked_engines = _prompt_selection(
            "Select engines to run (comma separated, e.g. '1,3' or 'A'): ", ENGINE_REGISTRY
        )
    except EOFError:
        print("\nNo input available (non-interactive shell). Aborting.")
        sys.exit(1)
    if not picked_engines:
        print("No engines selected. Nothing to do.")
        sys.exit(0)

    # 4. Config prompts (engine tuning, plan.md §4.1) + lazy-load selected.
    # MinerU is flash-only (other tiers need a parse-server); no prompt.
    configs = {}
    if "1" in picked_engines:
        configs["1"] = _prompt_paddle_config()
    if "3" in picked_engines:
        configs["3"] = _prompt_docling_config()

    pipeline = PipelineManager(output_dir=output_directory)
    for key in picked_engines:
        engine = _load_engine(key, config=configs.get(key))
        if engine is not None:
            pipeline.add_engine(engine)
    if not pipeline.engines:
        print("All selected engines failed to load. Nothing to run.")
        sys.exit(1)

    # 5. Run pipeline per file. Ground truths live in ground_truths/ as
    # <basename>.json (keys: normalized_full_text/full_text/text/markdown) or
    # <basename>.md (raw transcript). No GT file -> extraction only, no scores.
    ground_truths_dir = "ground_truths"
    for test_file in selected_files:
        base_name = os.path.splitext(os.path.basename(test_file))[0]

        print("\n========================================")
        print(f"Processing Document: {os.path.basename(test_file)}")
        print("========================================")

        results = pipeline.process_file(test_file)

        gt_file = _find_ground_truth(ground_truths_dir, base_name)
        if gt_file is None:
            print(f"\n--- No ground truth in '{ground_truths_dir}/' for {base_name} ---")
            print("Skipping evaluation (extraction outputs saved above).")
            continue

        print(f"\n--- Running Evaluation for {base_name} (GT: {os.path.basename(gt_file)}) ---")
        evaluator = PipelineEvaluator(ground_truth_path=gt_file)
        comparison_report = evaluator.compare_engines(results)

        print(f"\n=== Final Comparison Report: {base_name} ===")
        print(json.dumps(comparison_report, indent=4))

        report_path = os.path.join(output_directory, f"{base_name}_comparison_report.json")
        with open(report_path, "w", encoding="utf-8") as f:
            json.dump(comparison_report, f, indent=4)
        print(f"\nReport saved to: {report_path}")


if __name__ == "__main__":
    main()
