"""Docling + OCR-backend engine adapter (tunable, plan.md §4).

Tunable hyperparameters (config dict):
- ocr_backend: "rapidocr" (default, verified) | "easyocr" (needs `pip install
  easyocr`, verified installed 2026-09-26, first use downloads ~100MB models)
  | "tesseract" (needs the tesseract SYSTEM binary — absent on this box, fails
  with a clear message).
- force_ocr: bool, default False. Maps to force_full_page_ocr: run vision OCR
  over full pages instead of trusting embedded PDF text.
- image_scale: float, default 1.0. PdfPipelineOptions images_scale: higher =
  better accuracy, slower.

Backend selection works because docling's OcrFactory dispatches on the TYPE of
ocr_options: RapidOcrOptions -> RapidOcrModel, EasyOcrOptions -> EasyOcrModel, etc.
"""

from ocr_pipeline.core.base_engine import BaseOCREngine

try:
    from docling.datamodel.base_models import InputFormat
    from docling.datamodel.pipeline_options import (
        EasyOcrOptions,
        PdfPipelineOptions,
        RapidOcrOptions,
        TesseractOcrOptions,
    )
    from docling.document_converter import (
        DocumentConverter,
        ImageFormatOption,
        PdfFormatOption,
    )
except ImportError:
    DocumentConverter = None

_BACKEND_LABEL = {"rapidocr": "RapidOCR", "easyocr": "EasyOCR", "tesseract": "Tesseract"}


class DoclingEngine(BaseOCREngine):
    DEFAULTS = {
        "ocr_backend": "rapidocr",
        "force_ocr": False,
        "image_scale": 1.0,
    }

    def __init__(self, config: dict | None = None):
        cfg = dict(self.DEFAULTS)
        unknown = []
        for k, v in dict(config or {}).items():
            if k in cfg:
                cfg[k] = v
            else:
                unknown.append(k)
        if unknown:
            print(f"  ! Ignoring unknown Docling config keys: {unknown}")
        backend = str(cfg["ocr_backend"]).lower()
        if backend not in _BACKEND_LABEL:
            raise ValueError(
                f"Unknown ocr_backend '{cfg['ocr_backend']}': "
                f"choose from {sorted(_BACKEND_LABEL)}."
            )
        cfg["ocr_backend"] = backend
        try:
            scale = float(cfg["image_scale"])
            if scale <= 0:
                raise ValueError
            cfg["image_scale"] = scale
        except (TypeError, ValueError):
            raise ValueError(f"Invalid image_scale '{cfg['image_scale']}': must be > 0.")
        cfg["force_ocr"] = bool(cfg["force_ocr"])
        super().__init__(name=self._display_name(cfg), config=cfg)
        self.params = cfg

        if DocumentConverter is None:
            self.converter = None
            print("WARNING: docling not found. Running in placeholder mode.")
            return

        if backend == "tesseract":
            import shutil

            if shutil.which("tesseract") is None:
                raise RuntimeError(
                    "ocr_backend='tesseract' needs the tesseract SYSTEM binary "
                    "(not a pip package) and it is not on PATH."
                )
        pipeline_options = PdfPipelineOptions()
        pipeline_options.images_scale = cfg["image_scale"]
        force = cfg["force_ocr"]
        if backend == "rapidocr":
            pipeline_options.ocr_options = RapidOcrOptions(force_full_page_ocr=force)
        elif backend == "easyocr":
            # lang=['en'] keeps first-use model downloads minimal.
            pipeline_options.ocr_options = EasyOcrOptions(
                lang=["en"], force_full_page_ocr=force
            )
        else:  # tesseract
            pipeline_options.ocr_options = TesseractOcrOptions(
                lang=["eng"], force_full_page_ocr=force
            )
        self.converter = DocumentConverter(
            format_options={
                InputFormat.PDF: PdfFormatOption(pipeline_options=pipeline_options),
                InputFormat.IMAGE: ImageFormatOption(pipeline_options=pipeline_options),
            }
        )
        print(f"Initialized Docling + {_BACKEND_LABEL[backend]} engine successfully! [{self.name}]")

    @classmethod
    def _display_name(cls, cfg: dict) -> str:
        """Folder/result name; suffix encodes non-default values side-by-side."""
        base = f"Docling_{_BACKEND_LABEL.get(str(cfg.get('ocr_backend', 'rapidocr')).lower(), 'RapidOCR')}"
        parts = []
        if cfg.get("force_ocr", False):
            parts.append("forceocr")
        if cfg.get("image_scale", 1.0) != 1.0:
            parts.append(f"s{str(cfg['image_scale']).replace('.', 'p')}")
        return base if not parts else f"{base}_{'_'.join(parts)}"

    def process_document(self, file_path: str) -> dict:
        if not self.converter:
            return {
                "text": "Docling is not installed.",
                "tables": [],
                "layout": []
            }

        print("     [Docling] Running extraction...")
        try:
            # Run the actual conversion
            result = self.converter.convert(file_path)
            doc = result.document

            # Export the full document to Markdown
            markdown_text = doc.export_to_markdown()

            return self.standardize_output(
                text=markdown_text,
                markdown=markdown_text,
                tables=[],  # Docling embeds tables in the markdown
                layout=[],
                meta={"params": self.params},
            )
        except Exception as e:
            # Raise so PipelineManager records an error status instead of
            # scoring an error string as if it were OCR output.
            raise RuntimeError(f"Docling conversion failed for '{file_path}': {e}") from e
