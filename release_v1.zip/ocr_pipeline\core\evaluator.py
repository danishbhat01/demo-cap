import json
import os
from typing import Dict, Any

def levenshtein_distance(s1, s2) -> int:
    """Calculate the Levenshtein distance between two strings or lists."""
    if len(s1) < len(s2):
        return levenshtein_distance(s2, s1)
    if len(s2) == 0:
        return len(s1)
    
    previous_row = range(len(s2) + 1)
    for i, c1 in enumerate(s1):
        current_row = [i + 1]
        for j, c2 in enumerate(s2):
            insertions = previous_row[j + 1] + 1
            deletions = current_row[j] + 1
            substitutions = previous_row[j] + (c1 != c2)
            current_row.append(min(insertions, deletions, substitutions))
        previous_row = current_row
    
    return previous_row[-1]

def _extract_text(payload: Dict[str, Any]) -> str:
    """Vision.md §2: engines may emit text under several keys. Prefer normalized."""
    if not isinstance(payload, dict):
        return ""
    text = payload.get("normalized_full_text") or payload.get("full_text") or payload.get("text") or payload.get("markdown") or ""
    return text if isinstance(text, str) else str(text)


def _normalize(text: str) -> str:
    """Collapse whitespace so trivial layout differences don't skew CER/WER."""
    return " ".join(text.split())


def calculate_cer(reference: str, hypothesis: str) -> float:
    """Calculate Character Error Rate (CER)"""
    if not isinstance(reference, str) or not isinstance(hypothesis, str):
        return 1.0
    ref_len = len(reference)
    if ref_len == 0:
        return 1.0 if len(hypothesis) > 0 else 0.0
    distance = levenshtein_distance(reference, hypothesis)
    return distance / ref_len

def calculate_wer(reference: str, hypothesis: str) -> float:
    """Calculate Word Error Rate (WER)"""
    if not isinstance(reference, str) or not isinstance(hypothesis, str):
        return 1.0
    ref_words = reference.split()
    hyp_words = hypothesis.split()
    
    ref_len = len(ref_words)
    if ref_len == 0:
        return 1.0 if len(hyp_words) > 0 else 0.0
        
    distance = levenshtein_distance(ref_words, hyp_words)
    return distance / ref_len

class PipelineEvaluator:
    def __init__(self, ground_truth_path: str = None):
        """
        Initializes the evaluator.
        ground_truth_path: JSON file (keys per _extract_text) or .md file
        (raw transcript, wrapped as {"text": ...}). Missing/empty -> None,
        and every evaluation reports "No ground truth" instead of fake scores.
        """
        self.ground_truth = None
        if ground_truth_path and os.path.exists(ground_truth_path):
            with open(ground_truth_path, 'r', encoding='utf-8') as f:
                content = f.read()
            if not content.strip():
                return
            if ground_truth_path.lower().endswith(".md"):
                self.ground_truth = {"text": content}
            else:
                self.ground_truth = json.loads(content)

    def evaluate_output(self, engine_name: str, output_path: str) -> Dict[str, Any]:
        """Evaluate a specific engine's JSON output against ground truth."""
        if not self.ground_truth:
            return {"error": "No ground truth provided for comparison."}
            
        if not os.path.exists(output_path):
            return {"error": f"Output file not found: {output_path}"}
            
        with open(output_path, 'r', encoding='utf-8') as f:
            hypothesis = json.load(f)

        ref_text = _normalize(_extract_text(self.ground_truth))
        hyp_text = _normalize(_extract_text(hypothesis))

        cer = calculate_cer(ref_text, hyp_text)
        wer = calculate_wer(ref_text, hyp_text)
        
        # Note: Advanced metrics for table extraction (e.g., TEDS score) 
        # and layout detection (e.g., Bounding Box IoU) can be added here.
        
        return {
            "metrics": {
                "CER": round(cer, 4),
                "WER": round(wer, 4)
            }
        }
        
    def compare_engines(self, pipeline_results: Dict[str, Any]) -> Dict[str, Any]:
        """Compare all engine outputs from a pipeline run and return a summary report."""
        comparison_report = {}
        for engine, result in pipeline_results.items():
            if result.get("status") == "success":
                eval_metrics = self.evaluate_output(engine, result["saved_to"])
                comparison_report[engine] = eval_metrics
            else:
                comparison_report[engine] = {"error": "Engine failed, no output to evaluate."}
                
        return comparison_report
