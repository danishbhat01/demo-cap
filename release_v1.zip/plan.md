# Phase 3: Repo Sanitization & Chunking Prep Plan

Before we build the Semantic Chunking module, we need to finalize the OCR pipeline by stripping away experiments, cleaning up old data, and documenting the architecture. 

## 1. Sanitize the Repository
- **Clear Old Data:** Delete all directories and files inside `comparison_outputs/` to ensure a completely clean slate for our final benchmark run.
- **Drop Parked Engines:** 
  - Delete `ocr_pipeline/engines/surya_engine.py`.
  - Delete `ocr_pipeline/engines/paddle_vl_engine.py`.
  - Remove all references to them from `main.py`'s `ENGINE_REGISTRY`.
- **Streamline MinerU:** 
  - Update `main.py` and `mineru_engine.py` to remove the `basic`, `standard`, and `advanced` tiers. 
  - Hardcode or only prompt for the `flash` tier, as it is the only one verified to work without a heavy GPU parse-server.

## 2. Modular Folder Documentation
To ensure the project is easy to hand off and integrate with the Chunking phase, we will add a short, simple `README.md` to each core folder. Each README will explain the folder's role and how it connects to the others:
- `ocr_pipeline/core/README.md`: Defines the central logic (the `BaseOCREngine` contract, the evaluator, and pipeline runner).
- `ocr_pipeline/engines/README.md`: Houses the active, working OCR adapters (Docling, Paddle, MinerU).
- `ocr_pipeline/utils/README.md`: Contains helpers like `document_converter.py` for rendering PDFs to images.
- `test_docs/README.md`: The dropzone for incoming test documents (`.pdf`, `.docx`, etc.).
- `ground_truths/README.md`: A completely separate folder dedicated to holding your manually formatted Ground Truth files. If a file is named `scanned.pdf`, its ground truth must be placed here as `scanned.md` or `scanned.json`.
- `comparison_outputs/README.md`: The destination folder where extracted Markdown/JSON and the final benchmark report are saved.

## 2.1 Conditional Evaluation Logic
The developer agent must update the pipeline logic (`main.py` and `evaluator.py`) to support this new split folder structure:
- When a document is processed, the system will look for a matching filename in `ground_truths/` (e.g., `scanned.md` or `scanned.json`).
- **If a ground truth exists:** Run the CER and WER evaluation and add it to the scorecard.
- **If NO ground truth exists:** Skip the evaluation entirely (do not crash, do not output fake `1.0` scores). Just run the OCR extraction and save the outputs to `comparison_outputs/`.

## 3. The Final Run
Once the repository is fully sanitized and documented:
- Execute `python main.py`.
- Run all 3 remaining engines (Paddle, Docling, MinerU) on the `DATA_GENERATION_ARCHITECTURE.pdf`.
- Generate the final, definitive scorecard.

## 4. Next Step: Semantic Chunking
With the clean Markdown files generated from the Final Run, we will create a new directory (`ocr_pipeline/chunking/`) designed to slice the Markdown by headers and prepare it for Vector DB ingestion.
