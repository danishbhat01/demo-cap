Data Generation Architecture: Phase 1 Setup
Base)
1. Overview
2. Neo4j Full Schema (Source of Truth: Agent API Reference)
3. Azure Knowledge Base Ingestion Flow (ETL)
4. The Bridge: Mapping Tabular Names to Guidelines (Synonym-Enriched
RAG)
5. Asset Consumption Mapping (Where Is It Used at Runtime?)
DATA GENERATION ARCHITECTURE: Phase 1
Setup (Neo4j & Knowledge Base)
1. Overview
Before the LangGraph validation application can process a single claim, the system's
"Brain' and "Rulebook" must be instantiated. This is a one-time, offline data.
engineering process that builds the two foundational databases:
Current Scope - Pilot: The Neo4j Knowledge Graph is currently populated.
architecture is designed to generalize to all 22 ICD-10-CM chapters. The
Knowledge Base ETL is similarly scoped to the Chapter 1 guidelines in Section
I.C.
Database
Purpose
Current Scope
Source File
Neo4j Graph
Chapter 1 (A00-
Stores the ICD.
icd10cm tabular 2026.xml
10-CM hierarchy,
Database
B99) Pilot
tabular coding
instructions,
synonyms,
Purpose
Current Scope
Database
Source File
organisms, and
clinical terms.
Chapter 1
Azure
Stores semantic
CMS Guidelines PDF (Section
Knowledge Base
Guidelines (Pilot)
I.C)
guideline chunks
for each disease
category,
enabling RAG
retrieval at
validation time.
2. Neo4j Full Schema (Source of Truth: Agent API
Reference)
The parse_tabular-3.py script reads icd10cm_tabular_2026.xml and creates
the following complete graph schema
2.1 Node Types
Other Properties
Node Label
Description
Key Property
Chapter
description
Top-level ICD-
chapter_code
10-CM chapter,
(String, unique)
e.g., Chapter
"1"
Block
A code range
block code
description
(String, unique)
within a
chapter, e.g.,
"A00-A09"
code(String,
DiseaseCode
description . billable
Individual ICD-
10-CM code,
(anbdun
(Boolean)
e.g., "A41.9"
type
Synonyms,
ClinicalTerm
term (String)
(Include/Synonym/SearchTerm),
inclusion terms,
category (organism" or null)
or organism
agents linked to
a code
Key Property
Node Label
Other Properties
Description
Wildcard or
CodeRange
range(String,
type(wildcard/range)
span targets for
unique)
coding
instructions,
e.g., "A05.-"
Always use coalesce(target. code, target. range) when traversing edges
that can point to either.
2.2 Relationship Types
Hierarchy Relationships
Meaning
Source to Target
Relationship
HAS_BLOCK
Chapter to Block
A chapter contains code
range blocks.
CONTAINS
A block contains the top-level
Block to DiseaseCode
codes in its range.
DiseaseCode to
HAS CHILD
A parent code has more
DiseaseCode
specific child codes.
Traversable with * for full
depth.
Clinical Terminology Relationships
Meaning
Source to Target
Relationship
Chapter/Block/DiseaseCode
HAS INCLUDE
Inclusion terms and
synonyms (non-organism).
to ClinicalTerm
category is NULL.
DiseaseCode to ClinicalTerm
Organism/causative agents
HAS SEARCH TERM
only. category =
"organism".
Coding Instruction Relationships (Tabular Rules)
Relationship
Meaning
Validation Logic.
EXCLUDES1
Flag as violation if both
Hard mutual exclusion. Both
codes must NEVER appear
codes present.
together on same claim.
Soft restriction. Both codes
Acceptable if both conditions
EXCLUDES2
can be assigned if both
are documented.
conditions are clinically
present.
CODE FIRST
Sequencing rule. The target
Flag if target does not appear
code must be sequenced
earlier in the diagnostic
BEFORE the source code.
sequence.
CODE_ALSO
Optional companion. May be
Suggest, but do not
needed for complete
mandate.
specificity.
USE_ADDITIONAL_CODE
Mandatory companion. An
Flag as incomplete if
additional code is required
companion code is absent
(e.g., organism specification).
from the claim..
All Coding Instruction relationships point from DiseaseCode to either
DiseaseCode or CodeRange
2.3 Neo4j Ingestion Flow
Chapter Nodes
Block Nodes
DiseaseCode Nodes
code, description, billable
ClinicalTerm Nodes
Synonyms + Organisms.
icd10cm_tabular_2026.xml
parse_tabular-3.py
Neo4j Graph
CodeRange Nodes
Wildcard + Range targets
Hierarchy Edges
HAS_BLOCK, CONTAINS,
HAS_CHILD
Clinical Edges
HAS_INCLUDE,
HAS SEARCH TERM
Tabular Instruction Edges
EXCLUDES1
EXCLUDES2,
CODE_FIRST
CODE_ALSO,
USE_ADDITIONAL_CODE
Diagram
2.4 Cypher Ingestion Example (Verified Against Agent API Reference).
// 1. Create the Disease Node (DiseaseCode) with exact Tabular description
MERGE (c:DiseaseCode {code: 'A41.9'})
SET c.description = 'Sepsis, unspecified organism',
c.billable = true
// 2. Attach Inclusion Synonym (ClinicalTerm, type=Include, category=Null).
MERGE (t:ClinicalTerm {term: 'Septicemia Nos', type: 'Include'})
MERGE (c)-[:HAS_INCLUDE]->(t)
// 3. Attach Organism Search Term (ClinicalTerm, category='organism')
MERge (org:ClinicalTerm {term: 'Staphylococcus aureus', type:
'SearchTerm',
category: 'organism'}).
MERGE (c)-[:HAS_SEARCH_TERM]->(Org)
// 4. USE_ADDITIoNAL_CODE: A41.9 REQuIRES an organism code (mandatory companion).
Points to CodeRange B95-B97 (organism codes range)
//
' range'})
MERGE (c)-[:USE ADDITIONAL_CODE]->(organism_range)
// 5. coDE_FIRst (correct direction per API Reference):
R65.20 must be preceded by a systemic infection code.
//
So R65.20 has c0DE_FIRsT pointing T0 A41.9 (not the other way around)
//
MERGE (r:DiseaseCode {code:
'R65.20'})
SET r.description = 'Severe sepsis without septic shock', r.billable =
: true
MERGE (r)-[:CODE_FIRST]->(c)
3. Azure Knowledge Base Ingestion Flow (ETL)
3.1 The Semantic Chunking Strategy
Naive approach: Split the 120-page CMS PDF every 500 tokens. Result: a 6-
paragraph Sepsis guideline gets sliced in half and RAG retrieval returns broken,
incomplete context.
Our approach (Semantic Chunking by Disease Entity): The Python ETL script
feeds entire PDF sections to GPT-4o. GPT-4o is prompted to extract one JSON object
per Disease Entity I Heading Boundary, keeping all related paragraphs together in a
single, coherent chunk..
Metadata-Enriched JSON
Azure OpenAl Embeddings
chapter, content, source
Diagram
3.2 Metadata-Enriched JSON Chunk Format
Each chunk uploaded to the Knowledge Base is structured as follows:
'guideline-Ic-001"
"Sepsis"
"Chapter 1"
"CMS_ICD10cM_Guidelines_2026.pdf"
source"
"Do not assign code R65.2, Severe sepsis, unless severe sepsis
ontent
an associated acute organ dysfunction is documented. A code from subcategory
R65.2...
The metadata fields enable Hybrid Search: the Agent can vector-search by semantic
similarity while also filtering on chapter or source, making retrieval precise and
auditable.
4. The Bridge: Mapping Tabular Names to Guidelines.
(Synonym-Enriched RAG)
The Data Engineering Challenge: The Official Tabular XML (Neo4j) and the Official
Guidelines PDF (Knowledge Base) do not always use identical terminology: * Neo4j
DiseaseCode. description : "Human immunodeficiency virus [Hiv] disease"*
Guideline PDF heading: "HIV Infections'.
The Solution (Synonym-Enriched RAG): LangGraph does not just extract the
DiseaseCode. description from Neo4j. It also extracts all official Synonyms and
Inclusion Terms via the HAs INclue relationship to clinicalTerm nodes (where
category IS NULL ) and all organism terms via HAs_SEARcH_TERM .
Infections" are clinically identical, guaranteeing a precise semantic match every time.
5. Asset Consumption Mapping (Where Is It Used at.
Runtime?)
Purpose During Runtime.
Generated Asset
Consumed By
Validation
Neo4j Graph Database
LangGraph Orchestrator
Queried before the Agent is.
invoked. LangGraph extracts
ExcluDes1, excludes2 ,
CODE FIRST,
USE_ADDITIONAL_CODE
tabular rules, the
description , and all
ClinicalTerm synonyms
for the Target Code.
Purpose During Runtime
Generated Asset
Consumed By
Validation
The Azure Al Foundry Agent
Azure Knowledge Base
Azure Validation Agent
performs native RAG during
its reasoning loop, searching
the Knowledge Base by
Disease Name + Synonyms
to fetch Code-Specific
Guidelines (Section I.C).
System Prompt (General
Azure Validation Agent
The Agent uses the statically
Guidelines)
loaded Universal Guidelines
(Sections I.A - IV) to enforce
universal billing rules,
principal diagnosis selection.
and sequencing without any
database lookup.
Generated upfront by the
JSON Evidence Database
Azure Validation Agent
LLM Extractor from the
medical chart, this is the
Clinical Ground Truth against
which all tabular rules and
guidelines are evaluated.