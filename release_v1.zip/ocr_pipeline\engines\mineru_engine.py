"""MinerU (modern `mineru` 4.x package) engine adapter.

Architecture: MinerU lives in its OWN venv (`venv_mineru/`, Python 3.11) because
it pulls transformers>=5 / its own torch build, which would disturb the main
venv's verified set (transformers 4.57, torch 2.14 CPU). This adapter shells out
to that venv's `mineru` CLI and reads back the markdown — MinerU never imports
into our process, so no dependency clash is possible by construction.

Setup (once):  venv_mineru/Scripts/python -m pip install -U "mineru[all]"
Verified with: mineru 4.0.7, tier=flash (local, no remote service, no extra
config). Other tiers (basic/standard/advanced) need a parse-server that stays
disabled on this box — flash-only by design (Phase 3 sanitization).

CLI contract used: mineru parse <pdf> --tier flash --pages all -o <outfile>
Output file = markdown with `<!-- page N of M -->` markers.
"""

import re
import subprocess
import tempfile
from pathlib import Path

from ocr_pipeline.core.base_engine import BaseOCREngine

_PAGE_MARKER = re.compile(r"<!--\s*page\s+(\d+)\s+of\s+(\d+)\s*-->", re.IGNORECASE)


def _repo_root() -> Path:
    return Path(__file__).resolve().parents[2]


def _mineru_exe() -> Path | None:
    exe = _repo_root() / "venv_mineru" / "Scripts" / "mineru.exe"
    if exe.exists():
        return exe
    exe = _repo_root() / "venv_mineru" / "bin" / "mineru"
    return exe if exe.exists() else None


class MinerUEngine(BaseOCREngine):
    TIER = "flash"  # flash-only: other tiers need a parse-server (unavailable here).

    def __init__(self, config: dict | None = None):
        super().__init__(name="MinerU", config={"tier": self.TIER})
        self.tier = self.TIER
        self.exe = _mineru_exe()
        if self.exe is None:
            print("WARNING: venv_mineru not found. Running in placeholder mode.")
        else:
            print(f"Initialized MinerU engine (CLI: {self.exe}, tier={self.tier})!")

    def process_document(self, file_path: str) -> dict:
        if self.exe is None:
            return {
                "text": "MinerU venv not set up (see mineru_engine.py docstring).",
                "tables": [],
                "layout": [],
            }

        print("     [MinerU] Running extraction...")
        try:
            # flash tier runs without extra server config; ensure idempotent start
            # in case a future tier needs it (harmless if already running).
            subprocess.run([str(self.exe), "server", "start"],
                           capture_output=True, timeout=120)
            with tempfile.TemporaryDirectory(prefix="mu_") as tmp:
                out = Path(tmp) / "out.md"
                proc = subprocess.run(
                    [str(self.exe), "parse", str(Path(file_path).resolve()),
                     "--tier", self.tier, "--pages", "all",
                     "-o", str(out), "--wait", "600"],
                    capture_output=True, text=True, timeout=900,
                )
                if proc.returncode != 0 or not out.exists():
                    raise RuntimeError(
                        f"mineru parse failed (rc={proc.returncode}): "
                        f"{(proc.stderr or proc.stdout)[-2000:]}"
                    )
                markdown = out.read_text(encoding="utf-8")

            # Split per-page on markers for the layout list.
            chunks: list[tuple[int | None, str]] = []
            cur_page, buf = None, []
            for line in markdown.splitlines(keepends=True):
                m = _PAGE_MARKER.search(line)
                if m:
                    chunks.append((cur_page, "".join(buf).strip()))
                    buf = []
                    cur_page = int(m.group(1))
                else:
                    buf.append(line)
            chunks.append((cur_page, "".join(buf).strip()))

            layout = [
                {"label": "page", "bbox": [], "text": text,
                 "confidence": 1.0, "page": page or idx + 1}
                for idx, (page, text) in enumerate(chunks) if text
            ]
            full_text = "\n\n".join(t for _, t in chunks if t).strip() or markdown.strip()
            return self.standardize_output(
                text=full_text,
                markdown=markdown,
                layout=layout,
                tables=[],  # tables embedded in markdown, consistent w/ Docling adapter
                meta={"tier": self.tier, "backend": "mineru-cli"},
            )
        except Exception as e:
            raise RuntimeError(f"MinerU extraction failed for '{file_path}': {e}") from e
