import os
import time
import traceback
from typing import List, Dict, Any
from .base_engine import BaseOCREngine

class PipelineManager:
    def __init__(self, output_dir: str = "outputs"):
        self.engines: List[BaseOCREngine] = []
        self.output_dir = output_dir

    def add_engine(self, engine: BaseOCREngine):
        """Register an OCR engine in the pipeline."""
        self.engines.append(engine)

    def process_file(self, file_path: str) -> Dict[str, Any]:
        """Run the document through all registered engines and save outputs."""
        if not os.path.exists(file_path):
            raise FileNotFoundError(f"File not found: {file_path}")

        filename = os.path.splitext(os.path.basename(file_path))[0]

        print(f"\nProcessing '{file_path}' with {len(self.engines)} engines...")

        results = {}
        for engine in self.engines:
            print(f"  -> Running {engine.name}...")
            start = time.perf_counter()
            try:
                result = engine.process_document(file_path)
                saved_path = engine.save_output(result, self.output_dir, filename)
                elapsed = round(time.perf_counter() - start, 2)
                results[engine.name] = {
                    "status": "success",
                    "saved_to": saved_path,
                    "elapsed_sec": elapsed,
                }
                print(f"     Success in {elapsed}s! Saved to: {saved_path}")
            except Exception as e:
                elapsed = round(time.perf_counter() - start, 2)
                print(f"     Failed after {elapsed}s: {str(e)}")
                traceback.print_exc()
                results[engine.name] = {
                    "status": "error",
                    "error_message": str(e),
                    "elapsed_sec": elapsed,
                }

        return results
