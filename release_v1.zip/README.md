# OCR & Document Understanding Evaluation Pipeline

Benchmark multiple OCR / document-understanding engines on the same documents and
compare them with hard metrics (CER/WER today; TEDS/IoU planned). Drop PDFs into
`test_docs/`, pick engines from an interactive menu, get a per-document report.

Full system record: [`project.md`](project.md). Vision: [`vision.md`](vision.md).

## Engine status

| # | Engine | State | Verified result (8-page test PDF) |
|---|---|---|---|
| 1 | PaddleOCR (classic CPU stack) | ✅ Real, tunable | 23 s · 105.9 KB · 322 lines w/ bboxes · tuned CER 0.181 |
| 2 | MinerU 4.0.7 (own venv, flash tier) | ✅ Real, flash-only | 9.5 s · 10,743 chars · 8/8 pages · 0.192/0.276 |
| 3 | Docling + RapidOCR | ✅ Real, tunable | 77 s · 23.1 KB · WER 0.233 (best WER) |

Surya / PaddleOCR-VL were removed in Phase 3 sanitization (backups kept outside
the repo). Definitive scorecard: MinerU most balanced · Docling best WER ·
Paddle best CER when tuned.

## Prerequisites

- Windows 10/11, Python 3.11
- Internet on first run (model weights: Paddle ~200 MB, Docling/RapidOCR ~100 MB,
  EasyOCR ~100 MB, MinerU standard-tier ~1 GB if ever enabled)

## Install

```powershell
# 1. Main env
python -m venv venv
.\venv\Scripts\python.exe -m pip install torch==2.14.0 --index-url https://download.pytorch.org/whl/cpu
.\venv\Scripts\python.exe -m pip install -r requirements.txt
# keep exactly ONE cv2 provider (see Troubleshooting — order matters):
.\venv\Scripts\python.exe -m pip uninstall -y opencv-python opencv-python-headless opencv-contrib-python
.\venv\Scripts\python.exe -m pip install --no-deps "opencv-contrib-python==4.10.0.84"

# 2. MinerU env (isolated on purpose — it needs transformers>=5 / own torch)
python -m venv venv_mineru
.\venv_mineru\Scripts\python.exe -m pip install -U "mineru[all]"
.\venv_mineru\Scripts\mineru.exe server start   # background server, keep running
```

## Run

```powershell
# 1. Drop documents into test_docs/  (.pdf .png .jpg .jpeg .docx)
# 2. Launch (ALWAYS via the venv python — system python lacks the engines)
.\venv\Scripts\python.exe main.py
```

Pick files, then engines (`1,2,3` / `A` = all). Example session:

```text
Documents in test_docs          Available OCR Engines
[1] DATA_GENERATION_...pdf      [1] PaddleOCR (PP-Structure)
[A] All                         [2] MinerU (flash tier)
Select files: A                 [3] Docling + RapidOCR
                                Select engines: A
```

## Outputs

```text
comparison_outputs/
  <EngineName>/<doc>.json        # full result: text, layout bboxes, tables, meta
  <EngineName>/<doc>.md          # human-readable markdown/text
  <doc>_comparison_report.json   # CER/WER per engine — only when a GT exists;
                                 # rewritten each run with only that run's engines
```

## Hyperparameter tuning (plan.md §4)

Selecting Paddle (1) or Docling (3) offers Default vs Advanced configs.
Non-default runs save side-by-side, e.g. `PaddleOCR_PPStructure_noangle_t0p5_s1500/`,
`Docling_EasyOCR_forceocr/`. MinerU is flash-only (no prompt). Best scores so far (golden GT):

| Config | CER | WER |
|---|---|---|
| Paddle tuned (noangle, t0.5, s1500) | **0.181** | 0.310 |
| MinerU flash | 0.192 | 0.276 |
| Paddle default | 0.253 | 0.358 |
| Docling rapidocr = easyocr | 0.354 | **0.233** |
| Docling easyocr + force_ocr | 0.439 | 0.326 |

Note: each run rewrites `<doc>_comparison_report.json` with only that run's engines —
compare across runs via the per-engine folders. MinerU is flash-only; other tiers
need a parse-server this box can't serve (attempt documented in `project.md` §8).

## Ground truth (important)

Ground truths live SEPARATE from inputs, in `ground_truths/`, named after the
document: `scanned.pdf` → `ground_truths/scanned.json` (keys
`normalized_full_text`/`full_text`/`text`/`markdown`) or `ground_truths/scanned.md`
(raw transcript). No mocks are ever created.

- GT exists → CER/WER scorecard for that document.
- No GT → extraction runs, outputs are saved, evaluation is SKIPPED (no crash,
  no fake scores). Add the transcript later and re-run to score it.

## Troubleshooting

| Symptom | Cause / fix |
|---|---|
| `WinError 127` loading torch DLLs | Paddle's `libiomp5md.dll` shadows torch's — engines already import torch first; don't reorder imports |
| Paddle `NotImplementedError` in `onednn_instruction` | PaddlePaddle 3.x on CPU — stay on the pinned 2.6.2 / paddleocr 2.7.3 |
| `import cv2` → numpy ABI error, or `cv2` empty (no `__version__`) | Mixed opencv providers: uninstalling ANY `opencv-*` dist deletes the shared `cv2/` files. Fix = uninstall ALL THREE, then force-reinstall contrib 4.10 (see Install). Never uninstall just one. |
| `np.sctypes` AttributeError | paddleocr 2.7's abandoned `imgaug` dep under numpy 2 — handled by the shim in `paddle_engine.py`, don't remove it |
| `mineru parse` → "server is not running" | Run `mineru server start` in `venv_mineru` |
| `mineru` → "parse-server disabled" | Use `--tier flash` (adapter default) or enable the parse server |
| `FileNotFoundError` on long PDF names (MinerU) | Windows MAX_PATH — rename to something short |
| `RuntimeError: ABI version` noise on stderr | Harmless paddle-under-numpy-2 warning; inference works |
| Scores > 1 (e.g. CER 290) | Hypothesis much longer than (mock) GT — supply real GT (above) |

## Removed engines

Surya and PaddleOCR-VL were deleted in Phase 3 sanitization (backups kept outside
the repo). Restore a backup to `ocr_pipeline/engines/`, re-add its
`ENGINE_REGISTRY` line, and reinstall its deps to bring one back.

## Roadmap

`ocr_pipeline/chunking/` — slice final Markdown by headers for Vector DB ingestion.
Then: TEDS (tables) → bbox IoU (layout) → memory profiling. Details in
[`project.md`](project.md).
