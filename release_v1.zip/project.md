# Project — OCR & Document Understanding Evaluation Pipeline

> Single source of truth for this repo. Audited file-by-file 2026-09-26, then
> updated as engines were built. Restored 2026-09-27 after an accidental deletion,
> with latest context: Phase 3 sanitize complete, conditional evaluation (§2.1)
> live, golden GT + scanned doc in place, definitive scorecard in. Next: chunking.

---

## 1. What this project is

A modular, extensible benchmark harness that runs **multiple OCR / document-understanding
engines** over the same documents and compares them with hard metrics. There is no single
"best" OCR engine for every document type, so the pipeline exists to answer empirically
*which engine is best for our documents*.

**End state (per `vision.md`):** drop a folder of complex PDFs into `test_docs/`, run one
command, get a per-document benchmark report saying which engine won and by how much.

---

## 2. Document map (what each doc says, and how fresh it is)

| File | Purpose | Freshness |
|---|---|---|
| `vision.md` | Goal, 4 core objectives, 5 target engines, end state | Current — still the north star |
| `review_plan.md` | Scaffold review, blockers (A/B/C), Phase 1/2/3 plan, venv advice | **Mostly stale** — Phases 1+2 done differently than written (see §11). (File robot-deleted 2026-09-27? No — user-deleted; content summarized here.) |
| `plan.md` | Phase 3: sanitize + folder docs + conditional eval + final run + chunking-next | Current — implemented as written, except folder READMEs removed per user call |
| `README.md` | Run-it-now doc: install, run, tuning table, troubleshooting | Current |
| `literature_survey.md` | User's comparative analysis of Docling/MinerU/PaddleOCR on our benchmark | Current — chunking-phase research |
| `todo.md` | Pending work list (DELETED by user 2026-09-27; chunking items live in plan.md §4) | Gone |
| `.agents/INSTRUCTIONS.md` | "Never assume on your own initiative; be precise with user's vision" | Standing instruction, followed |
| `project.md` (this file) | Full system record | Current as of restore 2026-09-27 |

---

## 3. Vision recap (from `vision.md`, verbatim objectives)

1. **Multi-Format Ingestion** — native PDFs, scanned/image PDFs, standalone images, DOCX.
2. **Standardized Extraction** — every engine wrapped in an adapter normalizing proprietary
   output into one JSON shape: reading-order text + layout bboxes (titles/paragraphs/images)
   + structured tables (Markdown/HTML).
3. **Rigorous Automated Evaluation** — CER + WER now; TEDS (tables) and IoU (layout) in future.
4. **Extensibility** — new models plug in by subclassing `BaseOCREngine`.

---

## 4. Repository layout (actual, venv/cache excluded)

```text
task1-4/
├── main.py                          # Interactive CLI: file+engine prompts, tuning flows
├── vision.md / plan.md              # vision + Phase 3 sanitize/final-run/chunking plan
├── literature_survey.md             # comparative analysis (user, chunking-phase research)
├── project.md                       # This file (system record, restored 2026-09-27)
├── README.md                        # Run-it-now doc
├── requirements.txt                 # Main-venv pins (MinerU/Surya/VL handled separately, see §10)
├── ocr_pipeline/
│   ├── core/                        # contract, runner, evaluator
│   │   ├── base_engine.py           # BaseOCREngine: contract + config + standardize_output + save_output
│   │   ├── pipeline.py              # PipelineManager: fan-out runner with timing
│   │   └── evaluator.py             # CER/WER + key-fallback (normalized_full_text first) + .md GT support
│   ├── engines/                     # 3 ACTIVE adapters (Surya/VL deleted in Phase 3)
│   │   ├── docling_engine.py        # REAL, tunable (backend/force_ocr/image_scale)
│   │   ├── paddle_engine.py         # REAL, tunable (angle/thresh/side_len)
│   │   └── mineru_engine.py         # REAL via subprocess CLI (flash-only)
│   └── utils/document_converter.py  # DocumentProcessor (imports `pymupdf`, not `fitz`)
├── test_docs/                       # input dropzone (any supported file appears in menu)
│   ├── DATA_GENERATION_ARCHITECTURE.pdf       # 466 KB, 8 pages — benchmark doc (has GT)
│   └── scanned.pdf                            # 2 MB — scanned doc (NO GT → extraction-only)
├── ground_truths/                   # GTs live here, never mocks (plan.md §2.1)
│   └── DATA_GENERATION_ARCHITECTURE.json      # 38 KB GOLDEN ground truth
├── comparison_outputs/
│   ├── <EngineName>/DATA_GENERATION_ARCHITECTURE.{json,md}  # PaddleOCR_PPStructure, MinerU, Docling_RapidOCR
│   ├── <EngineName>/scanned.{json,md}                       # same 3 engines, extraction-only
│   └── DATA_GENERATION_ARCHITECTURE_comparison_report.json  # rewritten per run (scored doc only)
├── venv/                            # Main env: Python 3.11, torch+Paddle+Docling pkgs
└── venv_mineru/                     # MinerU 4.0.7 isolation env + background server
```

Note: plan.md §2 asked for per-folder READMEs; they were written, then REMOVED per
explicit user call (caused confusion). No folder READMEs exist — this file + README.md
are the documentation.

---

## 5. Entry point — `main.py` (~300 lines, implements `plan.md` incl. §2.1 + §4 tuning)

Flow:

1. **Discover** — `_collect_test_files()` scans `test_docs/` for
   `.pdf/.png/.jpg/.jpeg/.docx` (sorted). If empty, auto-generates `sample.pdf` via
   PyMuPDF (requires `pymupdf`; prints a warning when missing).
2. **Prompt ① files** — rich table (`rich.table.Table`) of discovered files, or plain
   `print` fallback when `rich` is not installed. Accepts `1,2` / `;`-separated / `A`.
   Unknown keys ignored with a message; empty selection exits 0; `EOFError` (pipes/CI)
   aborts cleanly instead of hanging.
3. **Prompt ② engines** — rich table of the engines from `ENGINE_REGISTRY`
   (1 Paddle, 2 MinerU, 3 Docling — Surya/VL deleted in Phase 3 sanitize).
4. **Prompt ③ tuning** — Paddle: Default/Advanced (angle/thresh/side_len); Docling:
   Default/Advanced (backend/force_ocr/image_scale). MinerU is flash-only, no prompt.
   Each validates input, falling back to defaults. `TUNABLE_ENGINES = ("1", "3")`.
5. **Lazy-load** — `importlib.import_module()` only for selected keys, configs passed
   as `cls(config=...)` for tunable keys; so unselected heavy frameworks
   (torch/paddle) never load. Load failure prints
   `! Skipping <label>: failed to load (...)` and continues; if zero engines load, exit 1.
6. **Run** — one shared `PipelineManager` processes each selected file; then
   `_find_ground_truth()` checks `ground_truths/<basename>.json`, else `.md`.
   GT found → `PipelineEvaluator` scores and writes
   `comparison_outputs/<basename>_comparison_report.json`. No GT → extraction
   outputs only, evaluation skipped entirely (never mocks, never fake scores).

`ENGINE_REGISTRY` (`main.py`):

| Key | Label | Module | Class |
|---|---|---|---|
| 1 | PaddleOCR (PP-Structure) | `ocr_pipeline.engines.paddle_engine` | `PaddleEngine` |
| 2 | MinerU (flash tier) | `ocr_pipeline.engines.mineru_engine` | `MinerUEngine` |
| 3 | Docling + RapidOCR | `ocr_pipeline.engines.docling_engine` | `DoclingEngine` |

**Deliberate deviations from `plan.md` (user-approved, historical):**

- Original CLI plan proposed plain `input()`; built with **rich tables** instead because
  `rich 15.0.0` is already installed in `venv` (with plain-print fallback).
- Original plan proposed instantiating **all engines upfront** then filtering; built
  **lazy import + construct of selected only**, because eager construction would load
  heavy models into memory and defeat the plan's own memory-saving benefit.
- Plan said nothing about file selection; added **prompt ①** (user chose "pick files too").
- No `--engines` CLI flags added (user chose prompt-only).

---

## 6. Core modules

### 6.1 `ocr_pipeline/core/base_engine.py`

`BaseOCREngine(ABC)` — the contract every engine subclasses:

- `__init__(name, config=None)` — sets `self.name` (output folder + `engine` field)
  and `self.config` (hyperparameter overrides, plan.md tuning; tuning engines extend
  `self.name` from non-default values so configs save side-by-side).
- `process_document(file_path) -> dict` — **abstract**, each engine implements.
- `standardize_output(text, markdown, layout, tables, raw, meta)` — builds the
  vision.md §2 shape: `{engine, text (always present), layout[], tables[]}` plus
  optional `markdown / raw / meta`. Layout items are `{label, bbox, text, confidence}`;
  tables are `{markdown/html, bbox, page}`.
- `save_output(result, output_dir, filename)` — writes
  `<output_dir>/<engine.name>/<filename>.json` (full dict) and
  `<filename>.md` (prefers `markdown` key, else `text`); returns the JSON path.

### 6.2 `ocr_pipeline/core/pipeline.py`

`PipelineManager(output_dir)`:

- `add_engine(engine)` — register.
- `process_file(file_path)` — raises `FileNotFoundError` if missing; loops engines
  **independently** (one `try/except` each, full `traceback.print_exc()` on failure).
  Records per engine `{status: success|error, saved_to / error_message, elapsed_sec}`
  where `elapsed_sec` is `time.perf_counter()`-based (Phase 3 speed profiling, partial —
  wall time only, no memory tracking yet). Prints `Success in Xs!` / `Failed after Xs:`.

Key property: **engines extract separately** — one engine's crash never stops the others,
and the evaluator only compares what actually ran.

### 6.3 `ocr_pipeline/core/evaluator.py`

- `levenshtein_distance(s1, s2)` — works on strings (chars) and lists (words).
- `_extract_text(payload)` — key priority: `normalized_full_text` → `full_text` →
  `text` → `markdown` (golden GT uses the first two; Docling emits text+markdown).
- `_normalize(text)` — collapses all whitespace runs so trivial layout differences
  don't skew scores.
- `calculate_cer(reference, hypothesis)` — char edit distance / len(reference);
  empty-reference edge cases return 0.0/1.0.
- `calculate_wer(...)` — same on whitespace-split word lists.
- `PipelineEvaluator(ground_truth_path)` — JSON file (keys per `_extract_text`) or
  `.md` file (raw transcript wrapped as `{"text": ...}`). Missing/empty → `None`,
  and every evaluation reports "No ground truth" instead of fake scores.
- `evaluate_output(engine_name, output_path)` → `{"metrics": {"CER": x, "WER": y}}`
  (rounded to 4 dp); missing output file → `{"error": ...}`.
- `compare_engines(pipeline_results)` — success entries evaluated, error entries get
  `{"error": "Engine failed, no output to evaluate."}`.
- **Not yet built:** TEDS (tables), bounding-box IoU (layout) — noted as comments.

---

## 7. Input normalization — `ocr_pipeline/utils/document_converter.py`

`DocumentProcessor` (stateless, all `@staticmethod`, all heavy imports lazy).
Answers "do we need to convert to scanned images?": **only image-only engines need it**
(PaddleOCR variants); MinerU/Docling consume PDFs natively.

| Method | Behavior |
|---|---|
| `detect_type(path)` | `pdf` / `docx` / `image` by extension; else `UnsupportedFormatError`. Image exts: png/jpg/jpeg/tif/tiff/bmp/webp |
| `ensure_readable(path)` | `FileNotFoundError` if missing; `ValueError` if 0 bytes; else returns detected type |
| `get_page_count(path)` | image → 1; pdf → `pymupdf` page count (fallback `pypdf`); docx → words//500+1 estimate |
| `pdf_to_images(path, dpi=300, max_pages)` | PyMuPDF primary (`pymupdf.Matrix` zoom, alpha-strip to RGB, `PIL.Image.frombytes`, in-memory-PNG fallback for odd colorspaces); pdf2image fallback if `pymupdf` missing |
| `_pdf_to_images_via_pdf2image(...)` | fallback; raises helpful `ImportError` if neither backend exists |
| `docx_to_text(path)` | `python-docx` paragraphs + tables (`cell` joined with ` |
| `docx_to_images(path)` | best-effort: renders extracted text onto 1700×2200 white PIL canvases (~38 lines/page). NOT faithful layout (needs Word/LibreOffice) — smoke-test shim only |
| `normalize_to_images(path, dpi)` | unified: pdf → rasterize; image → open+RGB; docx → text-render |
| `native_text_fallback(path)` | no-OCR text-layer baseline (also handy for drafting GTs) |

**Portability fixes applied:** (1) older code called `pix.to_pil()`, absent on
PyMuPDF 1.27+ → `Image.frombytes` + alpha-strip + PNG-bytes fallback. (2) venv's
PyMuPDF 1.28.2 ships an EMPTY `fitz/` stub (`import fitz` fails; `import pymupdf`
works) → all call sites migrated from `import fitz` to `import pymupdf`
(`document_converter.py` ×3, `main.py` sample-gen). Verified: 8 pages rasterized
2483×3512, 8,427 native chars.

---

## 8. Engines — exact current state

### REAL — `engines/paddle_engine.py` (`PaddleOCR_PPStructure`, tunable)

- Backend: paddleocr 2.7.3 + paddlepaddle 2.6.2 CPU (`PaddleOCR(use_angle_cls=True,
  lang, show_log=False)`, `ocr.ocr(np_image, cls=True)` per page).
- Config: `use_angle_cls`, `det_db_thresh`, `det_limit_side_len` (all verified in
  2.7.3 arg surface; our defaults True/0.3/960). Dynamic names (`_noangle_t0p5_s1500`).
- Input via `DocumentProcessor.normalize_to_images(dpi=300)`; reading-order sort;
  axis-aligned bboxes + confidence per line; `meta={pages, lines, dpi, lang, params}`.
- Two env workarounds in-module: torch-first import (paddle's `libiomp5md.dll`
  shadows torch's → WinError 127) and a `np.sctypes` shim for abandoned
  `imgaug 0.4.0` under numpy 2.
- Verified: **105.9 KB, 322 layout lines, ~23 s. Tuned (noangle/t0.5/s1500):
  CER 0.181 vs 0.253 default.**

### REAL — `engines/mineru_engine.py` (`MinerU`, subprocess-isolated, flash-only)

- MinerU 4.0.7 lives in its OWN venv (`venv_mineru/`) — never imports into our
  process (it needs transformers>=5 / own torch). Adapter shells out to
  `venv_mineru/Scripts/mineru.exe parse <pdf> --tier flash --pages all -o <out>`
  and reads back markdown; `<!-- page N of M -->` markers become layout entries.
- **Only flash works**: `basic`/`standard`/`advanced` need the parse-server;
  `parse_server.local.mode` was flipped to `managed`, standard-tier models
  downloaded, server restarted twice — still "Local parse-server is disabled".
  The managed path wants a VLM/api-server stack (GPU-oriented); not pursued.
  Tier prompt removed in Phase 3 sanitize (flash hardcoded).
- `mineru server start` (doclib server) kept running intentionally.
- Verified: **10,743 chars, 8/8 pages, ~9.5 s flash (fastest real).**

### REAL — `engines/docling_engine.py` (`Docling_RapidOCR`, tunable)

- Config: `ocr_backend` rapidocr (default, name preserved) | easyocr (verified,
  `EasyOcrOptions(lang=["en"])`, ~90 s/doc) | tesseract (fails cleanly — no system
  binary); `force_ocr` → `force_full_page_ocr`; `image_scale` → `images_scale`.
  Dynamic names (`Docling_EasyOCR_forceocr`, …).
- Backend dispatch verified via OcrFactory (options TYPE selects the model).
- Empirical: rapidocr ≡ easyocr at defaults (0.354/0.233 — both coast on embedded
  text); force_ocr on digital PDF HURTS (0.439/0.326, 173 s). EasyOCR first use
  downloads ~100 MB models.

### DELETED in Phase 3 sanitize (per plan.md §1)

- `paddle_vl_engine.py` — was dormant-real (`PaddleOCRVL` API, needs own 3.x venv).
  Backup: `Temp/opencode/paddle_vl_engine.py.bak`.
- `surya_engine.py` — was fully built + tested on surya-ocr 0.4.14 (0.994 conf),
  then parked, then deleted. Backup: `Temp/opencode/surya_engine.py.bak`.
- Do NOT install surya-ocr 0.22+ (needs Docker or a C++ toolchain).

---

## 9. Data — `test_docs/`, `ground_truths/`, `comparison_outputs/`

### `test_docs/` (inputs only — GTs live separately since Phase 3)

- `DATA_GENERATION_ARCHITECTURE.pdf` (466 KB, 8 pages) — "Data Generation
  Architecture: Phase 1 Setup (Neo4j & Knowledge Base)"; dense paragraphs,
  headings, tables. HAS golden GT → scored.
- `scanned.pdf` (2 MB, user-added) — NO GT → extraction-only (all 3 engines
  succeeded: Paddle 12.7 s, MinerU 2.5 s, Docling 31.4 s).

### `ground_truths/` (plan.md §2: GTs live here, never mocks)

- `DATA_GENERATION_ARCHITECTURE.json` (38,497 bytes, GOLDEN, user-supplied):
  `{"document": {...8 pages...}, "pages": [...], "full_text" (9,197 chars),
  "normalized_full_text" (9,124 chars)}`. Evaluator reads the new keys first (§6.3).
- `scanned.*` ABSENT (a 53-byte mock was found and deleted) → supply a real
  transcript as `ground_truths/scanned.json` (or `.md`) to score it.

### `comparison_outputs/` (regenerated by the final run)

- Per engine per document: `<EngineName>/<basename>.json` + `<basename>.md`.
  3 engine dirs × 2 docs = 6 outputs.
- `<basename>_comparison_report.json` — rewritten per run, only for docs WITH GT
  (so only the DATA_GENERATION_ARCHITECTURE report exists; scanned has none).
- Definitive scorecard vs golden GT: PaddleOCR **0.253/0.358** · MinerU
  **0.192/0.276** (most balanced) · Docling **0.354/0.233** (best WER).
  Tuned runs (earlier, folders cleared since): Paddle-tuned CER **0.181**.

---

## 10. Environment — interpreter split (important)

Main venv (`venv\Scripts\python.exe`, Python 3.11 — ALWAYS use this) plus an
isolation venv for MinerU. System python is redundant.

| Package | `venv` (main) | `venv_mineru` |
|---|---|---|
| docling 2.130.0 / rapidocr 3.9.2 / onnxruntime 1.30.0 | ✅ | — |
| torch 2.14.0 CPU (+torchvision 0.29.0) | ✅ (install FIRST, CPU index) | own build |
| paddlepaddle 2.6.2 / paddleocr 2.7.3 / imgaug 0.4.0 | ✅ (Paddle 3.x breaks on CPU) | — |
| surya-ocr 0.4.14 (engine deleted; package still installed, harmless) | ✅ | — |
| easyocr 1.7.2 | ✅ (verified via Docling) | — |
| PyMuPDF 1.28.2 | ✅ — BUT `fitz/` stub is EMPTY; code uses `import pymupdf` (§7) | — |
| Pillow 10.4.0 / python-docx 1.2.0 / rich 15.0.0 | ✅ | — |
| numpy 2.4.6 | ✅ KEEP 2.x | — |
| opencv (`cv2`) — SINGLE provider | ✅ contrib 4.10.0.84 only (see trap below) | — |
| mineru 4.0.7 | ❌ (deliberately absent) | ✅ |
| paddle 3.x / surya 0.22 / magic-pdf / jiwer | ❌ (do-not-install, see §11) | — |

**Consequences / traps:**

1. **Run the CLI with `.\venv\Scripts\python.exe main.py`**. MinerU additionally
   needs `venv_mineru/` + its background server (`mineru server start`, restart after reboot).
2. **opencv trap (bit twice):** all `opencv-*` dists share one `cv2/` dir.
   Uninstalling ANY one deletes shared files (empty/corrupt `cv2/`); a fresh
   `pip install -r` lets paddleocr pull numpy-1-built 4.6.0.66. Safe sequence only:
   uninstall ALL THREE, then force-reinstall contrib 4.10.0.84. `requirements.txt`
   pins it as an ACTIVE requirement (a comment-only pin caused the incident).
3. Paddle needs torch imported first (OMP DLL shadowing) — handled in-module.
4. `requirements.txt` Surya section is commented (engine deleted); MinerU section
   documents the separate venv; VL + `magic-pdf` listed as do-not-install with reasons.

---

## 11. Stale / resolved items (history — do not act on these)

1. `review_plan.md` §1 "current state" (all placeholders) — outdated since Phase 2;
   file since DELETED by user.
2. `review_plan.md` §2B prescribes `pdf2image`; implementation uses **PyMuPDF primary**,
   pdf2image fallback (better Windows story — no poppler). pdf2image never installed.
3. `review_plan.md` §3 Phase 3 "timer" checkbox is half-done: `elapsed_sec` wall timing
   exists in `pipeline.py`; memory tracking, TEDS, IoU do **not**.
4. ~~Stale `comparison_outputs/comparison_report.json`~~ — DELETED during sanitization.
5. ~~Engines swallowing errors into error-text~~ — FIXED: all adapters raise
   `RuntimeError`; not-installed paths return honest "not installed" dicts by design.
6. Docling/MinerU outputs leave `tables: []` / page-level-only `layout` (tables
   embedded in markdown, no cell bboxes) — vision.md §2 wants structured tables +
   bboxes; only Paddle populates per-line bboxes + confidence. (Open, feeds chunking.)
7. MinerU tiers beyond flash UNAVAILABLE on this box (managed parse-server attempted:
   config set + models downloaded + 2 restarts, still disabled).
8. Folder READMEs were written per plan.md §2, then REMOVED per explicit user call
   (caused confusion). This file + `README.md` are the documentation.
9. `todo.md` DELETED by user 2026-09-27; pending work = plan.md §4 chunking (+ §14).

---

## 12. Verified runs (evidence, not claims)

| # | Command (workdir `task1-4/`) | Result |
|---|---|---|
| 1 | `python main.py` (system, scaffold era) | 5 placeholders ~0.00 s; CER ~0.43–0.51 vs mock GT |
| 2 | `DocumentProcessor` smoke (system) | type pdf, 1 page, 2480×3509 image, native text matches |
| 3 | DOCX smoke (system) | text + 1700×2200 image, CER/WER 0.0 on identical md |
| 4 | Full A/A, scaffold era | all 5 placeholders on real PDF |
| 5 | Selective `1`+`5` | only Docling ran (39.94 s) |
| 6 | Full A/A defaults, 8-page PDF, engines 1,2,3,5 | Paddle 23 s/105.9 KB/322 lines; VL dormant; MinerU 9.5 s/10.7 KB/8 pp; Docling 77 s/23.1 KB (vs mock GT = noise) |
| 7 | Tuned Paddle (`noangle,t0.5,s1500`) vs golden GT | CER **0.1807** (vs 0.2526 default), WER 0.3101 |
| 8 | Docling EasyOCR (default + force_ocr) vs golden GT | EasyOCR ≡ RapidOCR (0.354/0.233); force_ocr HURTS (0.439/0.326, 173 s); caught+fixed corrupt `cv2/` |
| 9 | MinerU tier probe (`basic`, `advanced`) | Clean failures ("parse-server disabled"); managed unlock attempted and exhausted |
| 10 | `import pymupdf` migration check | 8 pages rasterized, 8,427 native chars |
| 11 | **Phase 3 FINAL RUN** `A/A/defaults`, 2 docs, 3 engines | DATA_GENERATION_ARCHITECTURE scored: Paddle 0.253/0.358 · MinerU 0.192/0.276 · Docling 0.354/0.233. scanned.pdf: all 3 extracted (12.7/2.5/31.4 s), evaluation skipped, no crash, no fake scores |

---

## 13. Known blockers (from `review_plan.md` §2, residual)

- **A. Dependency hell** — contained, not solved: Paddle+torch coexist via import
  order + single opencv; MinerU fully isolated in own venv; Surya/VL deleted rather
  than cohosted. Any new heavy dep goes in its own venv + subprocess by default.
- **B. Input normalization** — done.
- **C. Output standardization** — shape done; *content* gap (tables/lists) open, §11.6.

---

## 14. Roadmap

- [x] Phase 1: `DocumentProcessor` + rasterization
- [x] Interactive CLI + tuning (Paddle/Docling/MinerU) + side-by-side naming
- [x] Golden GT + key-fallback evaluator + conditional evaluation (`ground_truths/`)
- [x] Phase 3 sanitize: deleted parked engines, cleared outputs, flash-only MinerU,
  final 3-engine benchmark, (folder READMEs written then removed per user call)
- [ ] NEXT: `ocr_pipeline/chunking/` — slice final Markdown by headers for Vector DB
  ingestion (plan.md §4). Open inputs: source engine(s) (MinerU 10.7 KB w/ page
  markers vs Docling 23 KB vs Paddle line text), chunk schema, CLI step vs standalone
- [ ] Later: scanned.pdf transcript (to score it), TEDS/IoU/memory profiling,
  cross-run report merge, Docling/MinerU `tables`+`layout` content

---

## 15. How to run / extend

```powershell
# Always use the venv (it has the engines):
.\venv\Scripts\python.exe main.py
# Select files, then engines, then per-engine Default/Advanced configs.
# MinerU needs venv_mineru's server running: .\venv_mineru\Scripts\mineru.exe server start
```

Add a new engine:

1. Create `ocr_pipeline/engines/<name>_engine.py` subclassing `BaseOCREngine`
   (`ocr_pipeline/core/base_engine.py`).
2. Lazy-import the third-party lib (`try/except ImportError`, honest
   not-installed mode — see `docling_engine.py` header).
3. Image-only lib → `DocumentProcessor.normalize_to_images()`; native-PDF lib →
   pass the path through.
4. Accept `config: dict`, extend `self.name` from non-defaults for side-by-side runs.
5. Register in `ENGINE_REGISTRY` (`main.py`) — pipeline, saving, evaluation follow.
6. Heavy or conflicting deps → OWN venv + subprocess (MinerU pattern), never main venv.
