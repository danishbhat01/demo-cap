from abc import ABC, abstractmethod
from typing import Dict, Any
import os
import json

class BaseOCREngine(ABC):
    def __init__(self, name: str, config: Dict[str, Any] | None = None):
        self.name = name
        # Engine hyperparameter overrides (plan.md §4). Subclasses that support
        # tuning read their keys here and may extend self.name so different
        # configs save side-by-side instead of overwriting each other.
        self.config: Dict[str, Any] = dict(config or {})

    @abstractmethod
    def process_document(self, file_path: str) -> Dict[str, Any]:
        """
        Process the document and return a dictionary containing the extracted data.
        The dictionary should ideally contain:
        - 'text' or 'markdown': The fully extracted string.
        - 'layout': Layout elements and reading order.
        - 'tables': Extracted tables if any.
        - 'raw': The raw output specific to the engine for deep comparison.
        """
        pass

    def standardize_output(
        self,
        text: str = "",
        markdown: str | None = None,
        layout: list | None = None,
        tables: list | None = None,
        raw: dict | None = None,
        meta: dict | None = None,
    ) -> Dict[str, Any]:
        """Build the standardized result dict from vision.md §2.

        Every engine adapter must return this shape so the pipeline and
        evaluator can treat outputs uniformly:
        - text: reading-order plain text (always present, may be "")
        - markdown: structured markdown if the engine provides it
        - layout: list of {label, bbox, text, confidence}
        - tables: list of {markdown/html, bbox, page}
        - raw: engine-native output for deep debugging
        """
        result: Dict[str, Any] = {
            "engine": self.name,
            "text": text or "",
            "layout": layout or [],
            "tables": tables or [],
        }
        if markdown is not None:
            result["markdown"] = markdown
        if raw is not None:
            result["raw"] = raw
        if meta is not None:
            result["meta"] = meta
        return result

    def save_output(self, result: Dict[str, Any], output_dir: str, filename: str):
        """
        Saves the output to the specified directory in engine-specific folders.
        """
        engine_output_dir = os.path.join(output_dir, self.name)
        os.makedirs(engine_output_dir, exist_ok=True)
        
        # Save JSON with all metadata (layout, tables, raw)
        json_path = os.path.join(engine_output_dir, f"{filename}.json")
        with open(json_path, 'w', encoding='utf-8') as f:
            json.dump(result, f, ensure_ascii=False, indent=4)
        
        # Save simple Markdown/Text for easy human reading and diffing
        content_key = "markdown" if "markdown" in result else "text"
        if content_key in result:
            txt_path = os.path.join(engine_output_dir, f"{filename}.md")
            with open(txt_path, 'w', encoding='utf-8') as f:
                f.write(result.get(content_key, ""))
                
        return json_path
