## Data Generation Architecture: Phase 1 Setup

| DATA GENERATION ARCHITECTURE: Phase 1 Setup (Neo4j & Knowledge            |
|---------------------------------------------------------------------------|
| Base)                                                                     |
| 1. Overview                                                               |
| 2. Neo4j Full Schema (Source of Truth: Agent API Reference)               |
| 3. Azure Knowledge Base Ingestion Flow (ETL)                              |
| 4. The Bridge: Mapping Tabular Names to Guidelines (Synonym-Enriched RAG) |
| 5. Asset Consumption Mapping (Where Is It Used at Runtime?)               |

## DATA GENERATION ARCHITECTURE: Phase 1 Setup (Neo4j &amp; Knowledge Base)

## 1. Overview

Before the LangGraph validation application can process a single claim, the system's 'Brain' and 'Rulebook' must be instantiated. This is a one-time, offline data engineering process that builds the two foundational databases:

Current Scope - Pilot: The Neo4j Knowledge Graph is currently populated with Chapter 1 only (Certain Infectious and Parasitic Diseases, A00-B99). The architecture is designed to generalize to all 22 ICD-10-CM chapters. The Knowledge Base ETL is similarly scoped to the Chapter 1 guidelines in Section I.C.

| Database             | Source File              | Current Scope              | Purpose                                                                 |
|----------------------|--------------------------|----------------------------|-------------------------------------------------------------------------|
| Neo4j Graph Database | icd10cm_tabular_2026.xml | Chapter 1 (A00- B99) Pilot | Stores the ICD- 10-CM hierarchy, tabular coding instructions, synonyms, |

| Database             | Source File                      | Current Scope                | Purpose organisms, and clinical terms.                                                                 |
|----------------------|----------------------------------|------------------------------|--------------------------------------------------------------------------------------------------------|
| Azure Knowledge Base | CMS Guidelines PDF (Section I.C) | Chapter 1 Guidelines (Pilot) | Stores semantic guideline chunks for each disease category, enabling RAG retrieval at validation time. |

## 2. Neo4j Full Schema (Source of Truth: Agent API Reference)

The parse\_tabular-3.py script reads icd10cm\_tabular\_2026.xml and creates the following complete graph schema.

## 2.1 Node Types

| Node Label   | Key Property                  | Other Properties                                                 | Description                                                    |
|--------------|-------------------------------|------------------------------------------------------------------|----------------------------------------------------------------|
| Chapter      | chapter_code (String, unique) | description                                                      | Top-level ICD- 10-CM chapter, e.g., Chapter '1'                |
| Block        | block_code (String, unique)   | description                                                      | A code range within a chapter, e.g., 'A00-A09'                 |
| DiseaseCode  | code (String, unique)         | description, billable (Boolean)                                  | Individual ICD- 10-CM code, e.g., 'A41.9'                      |
| ClinicalTerm | term (String)                 | type (Include/Synonym/SearchTerm), category ('organism' or null) | Synonyms, inclusion terms, or organism agents linked to a code |

| Node Label   | Key Property           | Other Properties      | Description                                                     |
|--------------|------------------------|-----------------------|-----------------------------------------------------------------|
| CodeRange    | range (String, unique) | type (wildcard/range) | Wildcard or span targets for coding instructions, e.g., 'A05.-' |

Critical: DiseaseCode uses code as its identifier. CodeRange uses range. Always use coalesce(target.code, target.range) when traversing edges that can point to either.

## 2.2 Relationship Types

Hierarchy Relationships

| Relationship   | Source to Target           | Meaning                                                                         |
|----------------|----------------------------|---------------------------------------------------------------------------------|
| HAS_BLOCK      | Chapter to Block           | A chapter contains code range blocks.                                           |
| CONTAINS       | Block to DiseaseCode       | A block contains the top-level codes in its range.                              |
| HAS_CHILD      | DiseaseCode to DiseaseCode | A parent code has more specific child codes. Traversable with * for full depth. |

Clinical Terminology Relationships

| Relationship    | Source to Target                          | Meaning                                                        |
|-----------------|-------------------------------------------|----------------------------------------------------------------|
| HAS_INCLUDE     | Chapter/Block/DiseaseCode to ClinicalTerm | Inclusion terms and synonyms (non-organism). category is NULL. |
| HAS_SEARCH_TERM | DiseaseCode to ClinicalTerm               | Organism/causative agents only. category = "organism" .        |

Coding Instruction Relationships (Tabular Rules)

| Relationship        | Meaning                                                                                 | Validation Logic                                                   |
|---------------------|-----------------------------------------------------------------------------------------|--------------------------------------------------------------------|
| EXCLUDES1           | Hard mutual exclusion. Both codes must NEVER appear together on same claim.             | Flag as violation if both codes present.                           |
| EXCLUDES2           | Soft restriction. Both codes can be assigned if both conditions are clinically present. | Acceptable if both conditions are documented.                      |
| CODE_FIRST          | Sequencing rule. The target code must be sequenced BEFORE the source code.              | Flag if target does not appear earlier in the diagnostic sequence. |
| CODE_ALSO           | Optional companion. May be needed for complete specificity.                             | Suggest, but do not mandate.                                       |
| USE_ADDITIONAL_CODE | Mandatory companion. An additional code is required (e.g., organism specification).     | Flag as incomplete if companion code is absent from the claim.     |

All Coding Instruction relationships point from DiseaseCode to either DiseaseCode or CodeRange.

## 2.3 Neo4j Ingestion Flow

<!-- image -->

Diagram

## 2.4 Cypher Ingestion Example (Verified Against Agent API Reference)

// 1. Create the Disease Node (DiseaseCode) with exact Tabular description MERGE (c:DiseaseCode {code: 'A41.9'}) SET c.description = 'Sepsis, unspecified organism', c.billable = true // 2. Attach Inclusion Synonym (ClinicalTerm, type=Include, category=NULL) MERGE (t:ClinicalTerm {term: 'Septicemia NOS', type: 'Include'}) MERGE (c)-[:HAS\_INCLUDE]-&gt;(t) // 3. Attach Organism Search Term (ClinicalTerm, category='organism') MERGE (org:ClinicalTerm {term: 'Staphylococcus aureus', type: 'SearchTerm', category: 'organism'}) MERGE (c)-[:HAS\_SEARCH\_TERM]-&gt;(org) // 4. USE\_ADDITIONAL\_CODE: A41.9 REQUIRES an organism code (mandatory companion) // Points to CodeRange B95-B97 (organism codes range)

<!-- image -->

## 3. Azure Knowledge Base Ingestion Flow (ETL)

## 3.1 The Semantic Chunking Strategy

Naive approach: Split the 120-page CMS PDF every 500 tokens. Result: a 6paragraph Sepsis guideline gets sliced in half and RAG retrieval returns broken, incomplete context. Our approach (Semantic Chunking by Disease Entity): The Python ETL script feeds entire PDF sections to GPT-4o. GPT-4o is prompted to extract one JSON object per Disease Entity / Heading Boundary, keeping all related paragraphs together in a

single, coherent chunk.

<!-- image -->

Diagram

## 3.2 Metadata-Enriched JSON Chunk Format

Each chunk uploaded to the Knowledge Base is structured as follows:

<!-- image -->

The metadata fields enable Hybrid Search: the Agent can vector-search by semantic similarity while also filtering on chapter or source, making retrieval precise and auditable.

## 4. The Bridge: Mapping Tabular Names to Guidelines (Synonym-Enriched RAG)

The Data Engineering Challenge: The Official Tabular XML (Neo4j) and the Official Guidelines PDF (Knowledge Base) do not always use identical terminology: * Neo4j DiseaseCode.description: 'Human immunodeficiency virus [HIV] disease' * Guideline PDF heading: 'HIV Infections' The Solution (Synonym-Enriched RAG): LangGraph does not just extract the DiseaseCode.description from Neo4j. It also extracts all official Synonyms and Inclusion Terms via the HAS\_INCLUDE relationship to ClinicalTerm nodes (where category IS NULL) and all organism terms via HAS\_SEARCH\_TERM. This enriched payload (Primary Name + Synonyms + Organisms) is passed to the Azure Validation Agent. The Agent searches the Knowledge Base using this richer context. The underlying vector embeddings understand that 'HIV disease' and 'HIV Infections' are clinically identical, guaranteeing a precise semantic match every time.

## 5. Asset Consumption Mapping (Where Is It Used at Runtime?)

| Generated Asset      | Consumed By            | Purpose During Runtime Validation                                                                                                                                                                 |
|----------------------|------------------------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Neo4j Graph Database | LangGraph Orchestrator | Queried before the Agent is invoked. LangGraph extracts EXCLUDES1, EXCLUDES2, CODE_FIRST , USE_ADDITIONAL_CODE tabular rules, the description, and all ClinicalTerm synonyms for the Target Code. |

| Generated Asset                    | Consumed By            | Purpose During Runtime Validation                                                                                                                                                            |
|------------------------------------|------------------------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Azure Knowledge Base               | Azure Validation Agent | The Azure AI Foundry Agent performs native RAG during its reasoning loop, searching the Knowledge Base by Disease Name + Synonyms to fetch Code-Specific Guidelines (Section I.C).           |
| System Prompt (General Guidelines) | Azure Validation Agent | The Agent uses the statically loaded Universal Guidelines (Sections I.A - IV) to enforce universal billing rules, principal diagnosis selection, and sequencing without any database lookup. |
| JSON Evidence Database             | Azure Validation Agent | Generated upfront by the LLM Extractor from the medical chart, this is the Clinical Ground Truth against which all tabular rules and guidelines are evaluated.                               |