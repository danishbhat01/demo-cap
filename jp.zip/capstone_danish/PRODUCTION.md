# AZURE OPENAI & MICROSOFT AGENT FRAMEWORK (MAF)
## Production Deployment Blueprint: Direct Azure OpenAI (GPT-5 / GPT-4o) Integration

---

## 1. Overview & Objective

During local development and testing, this system used a modular proxy layer (`proxy_server.py`) and a provider shim (`backend/llm_provider.py`) to dynamically switch between free and cost-effective prototyping models (e.g. Mistral Large, Groq Llama, NVIDIA NIM, Gemini Flash).

In **Enterprise Azure Production**, all custom proxy layers and local provider shims are eliminated. The **Microsoft Agent Framework (MAF) SDK** connects **directly and natively to Azure OpenAI Service** using Microsoft Entra ID (Managed Identity) and Azure AI Foundry endpoints.

This document provides the complete technical blueprint, code samples, architecture diagrams, and infrastructure configuration needed to deploy GPT-5.4 / GPT-4o directly to MAF in production.

---

## 2. Development vs. Production Architecture

```mermaid
flowchart TD
    subgraph DEV ["Local Development Architecture (Prototyping)"]
        D_EXT["Extractor Agent"] & D_VAL["Validator Agent"] --> D_SHIM["backend/llm_provider.py<br>(Multi-Provider Adapter)"]
        D_SHIM --> D_PROXY["proxy_server.py<br>(Local FastAPI OpenAI-Compatible Proxy)"]
        D_PROXY --> D_MISTRAL["Mistral Large / Groq / NIM"]
    end

    subgraph PROD ["Enterprise Azure Production Architecture"]
        P_ORCH["MAF Orchestrator State Machine<br>(Azure Container Apps)"]
        
        P_EXT["Extractor Agent Node"] & P_VAL["Validator Agent Node"]
        P_ORCH --> P_EXT & P_VAL
        
        P_EXT & P_VAL -->|Native MAF Client<br>Direct HTTPS / gRPC| AZ_AOAI["Azure OpenAI Service<br>GPT-5.4 / GPT-4o Deployments<br>(Provisioned Throughput Units / PTU)"]
        
        AZ_AUTH[("Azure Entra ID<br>Managed Identity<br>(DefaultAzureCredential)")] -.->|Token Authentication| P_EXT & P_VAL
        AZ_AUTH -.->|Secret Resolution| AZ_KV[("Azure Key Vault<br>(Secrets Manager)")]
        AZ_KV -.->|Storage Keys| AZ_BLOB[("Azure Blob Storage<br>(Secure PDF Vault)")]
        AZ_BLOB -->|SAS Token| P_ORCH
        AZ_AOAI --> AZ_LOGS[("Azure Monitor / App Insights<br>Diagnostic Logging & Metrics")]
    end

    style DEV fill:#fff3e0,stroke:#f57c00,stroke-width:2px;
    style PROD fill:#e8f5e9,stroke:#2e7d32,stroke-width:2px;
```

### Key Differences:

| Dimension | Local Development | Azure Production |
| :--- | :--- | :--- |
| **Connectivity** | Localhost HTTP (`http://127.0.0.1:8000/v1`) | Direct Native HTTPS (`https://<resource>.openai.azure.com/`) |
| **Authentication** | Static API Keys in `.env` | **Passwordless Azure Managed Identity** (`DefaultAzureCredential`) |
| **SDK Interface** | Custom wrapper `llm_provider.py` | **Native Microsoft Agent Framework (MAF) Chat Clients** |
| **Model Hosting** | Third-party public APIs (Mistral / Groq) | **Private Azure OpenAI VNet / PTU Instance** (HIPAA / BAA Compliant) |
| **Structured Output** | JSON Mode + Pydantic validation fallback | **Strict Schema-Guided Decoding** (`json_schema` response format) |
| **Telemetry** | Local JSONL (`insights/telemetry_logs.jsonl`) | **Azure Application Insights & Log Analytics Workspace** |

---

## 3. Pre-Flight Security Checklist

Before pushing to GitHub or deploying to Azure, you **must** ensure a `.gitignore` exists at the root of the project to prevent `.env` file leakage.
A secure root `.gitignore` looks like this:
```text
.env
__pycache__/
venv/
rag_chroma_db/
sessions/
*.pdf
```

---

## 4. Production Dependencies

In production, install the official Microsoft Agent Framework, Azure OpenAI, Azure Storage, and Azure Identity packages:

```bash
pip install agent-framework-preview azure-ai-projects azure-identity azure-keyvault-secrets azure-storage-blob openai pydantic
```

---

## 4. Step-by-Step Code Migration

### Step 1: Centralized Production Configuration (`backend/config.py`)

Create a centralized configuration module leveraging Azure Managed Identity:

```python
# backend/config.py
import os
from azure.identity import DefaultAzureCredential, get_bearer_token_provider

class AzureProductionConfig:
    # Azure OpenAI Resource Details
    AZURE_OPENAI_ENDPOINT = os.getenv(
        "AZURE_OPENAI_ENDPOINT", 
        "https://my-medical-ai-foundry.openai.azure.com/"
    )
    AZURE_OPENAI_API_VERSION = os.getenv(
        "AZURE_OPENAI_API_VERSION", 
        "2024-10-21"
    )
    
    # Model Deployment Names in Azure AI Foundry
    EXTRACTOR_DEPLOYMENT = os.getenv("AZURE_EXTRACTOR_DEPLOYMENT", "gpt-5-medical-extractor")
    VALIDATOR_DEPLOYMENT = os.getenv("AZURE_VALIDATOR_DEPLOYMENT", "gpt-5-medical-validator")
    
    # Microsoft Entra ID Token Provider (Passwordless Authentication)
    @classmethod
    def get_token_provider(cls):
        credential = DefaultAzureCredential()
        return get_bearer_token_provider(
            credential, 
            "https://cognitiveservices.azure.com/.default"
        )
```

---

### Step 2: Native Extractor Agent (`backend/extractor_agent.py`)

Remove all references to `llm_provider` and connect directly to Azure OpenAI using native structured outputs with Pydantic:

```python
# backend/extractor_agent.py (Production Version)
import os
from typing import Dict, Any, List, Optional
from pydantic import BaseModel, Field
from openai import AzureOpenAI
from backend.config import AzureProductionConfig

# 1. Define Strict Pydantic Ground Truth Schema
class DiagnosisDetail(BaseModel):
    confirmed: bool = Field(description="Whether diagnosis is confirmed by physician")
    severity: Optional[str] = Field(None, description="Severity (e.g., Acute, Severe, Chronic)")
    status: str = Field(description="Clinical status (e.g., Active, History, Ruled out)")
    source_quote: str = Field(description="MANDATORY exact verbatim quote from chart")

class EvidenceDB(BaseModel):
    setting: str = Field(description="Inpatient or Outpatient")
    diagnoses: Dict[str, DiagnosisDetail] = Field(default_factory=dict)
    organism: Optional[str] = Field(None, description="Causative organism/pathogen")
    organ_dysfunction: List[str] = Field(default_factory=list)
    medical_history: List[str] = Field(default_factory=list)
    lab_values: Dict[str, str] = Field(default_factory=dict)
    medications: List[str] = Field(default_factory=list)

# 2. Native Azure OpenAI Client Initialization
def get_azure_openai_client() -> AzureOpenAI:
    return AzureOpenAI(
        azure_endpoint=AzureProductionConfig.AZURE_OPENAI_ENDPOINT,
        azure_ad_token_provider=AzureProductionConfig.get_token_provider(),
        api_version=AzureProductionConfig.AZURE_OPENAI_API_VERSION
    )

def run_extractor(clinical_text: str) -> Dict[str, Any]:
    """
    Directly extracts clinical ground truth using Azure OpenAI GPT-5
    with strict JSON Schema enforcement.
    """
    client = get_azure_openai_client()
    
    prompt_path = os.path.join(
        os.path.dirname(os.path.dirname(__file__)), 
        'prompts', 
        'extractor_agent_prompt.md'
    )
    with open(prompt_path, 'r', encoding='utf-8') as f:
        system_prompt = f.read()

    # Direct native call using Pydantic Parse
    completion = client.beta.chat.completions.parse(
        model=AzureProductionConfig.EXTRACTOR_DEPLOYMENT,
        messages=[
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": f"Extract clinical ground truth from this chart:\n\n{clinical_text}"}
        ],
        response_format=EvidenceDB,
        temperature=0.0
    )
    
    return completion.choices[0].message.parsed.model_dump()
```

---

### Step 3: Native Validator Agent (`backend/validator_agent.py`)

Directly invoke Azure OpenAI with prompt caching enabled for universal coding guidelines:

```python
# backend/validator_agent.py (Production Version)
import os
import json
from typing import Dict, Any, Optional, List
from pydantic import BaseModel, Field
from openai import AzureOpenAI
from backend.config import AzureProductionConfig
from backend.guardrails import enforce_anti_fabrication_guardrails

# 1. Define Strict Validator Decision Schema
class ValidatorDecision(BaseModel):
    decision: str = Field(description="VALID | INVALID | SWAP | ADD_COMPANION")
    replacement_code: Optional[str] = Field(None, description="Replacement code if decision is SWAP")
    companion_codes_required: List[str] = Field(default_factory=list, description="Required secondary companion codes")
    rationale: str = Field(description="Clinical and regulatory justification")
    chart_evidence: str = Field(description="Verbatim quote from Evidence DB")
    coding_rule: str = Field(description="Exact ICD-10 guideline or tabular rule cited")

def run_validator(payload: Dict[str, Any]) -> Dict[str, Any]:
    """
    Directly invokes Azure OpenAI GPT-5 to validate a target code
    against the Tri-Layer Knowledge Brain and extracted evidence.
    """
    client = AzureOpenAI(
        azure_endpoint=AzureProductionConfig.AZURE_OPENAI_ENDPOINT,
        azure_ad_token_provider=AzureProductionConfig.get_token_provider(),
        api_version=AzureProductionConfig.AZURE_OPENAI_API_VERSION
    )
    
    prompt_path = os.path.join(
        os.path.dirname(os.path.dirname(__file__)), 
        'prompts', 
        'validator_agent_prompt.md'
    )
    with open(prompt_path, 'r', encoding='utf-8') as f:
        system_prompt = f.read()

    user_content = json.dumps(payload, indent=2)

    # Native call with temperature 0.0 for deterministic decisioning
    completion = client.beta.chat.completions.parse(
        model=AzureProductionConfig.VALIDATOR_DEPLOYMENT,
        messages=[
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": f"Validate target code with this context:\n\n{user_content}"}
        ],
        response_format=ValidatorDecision,
        temperature=0.0
    )
    
    decision_dict = completion.choices[0].message.parsed.model_dump()
    
    # Execute Multi-Pass Runtime Guardrails
    guardrail_result = enforce_anti_fabrication_guardrails(
        decision=decision_dict,
        evidence_db=payload.get("evidence_db", {}),
        rag_guidelines=payload.get("rag_guidelines", "")
    )
    
    return guardrail_result
```

---

### Step 4: Deprecating `llm_provider.py` & `proxy_server.py`

Once deployed to Azure:
1. **Remove `proxy_server.py`**: No local background FastAPI process is needed; API requests flow directly from Azure Container Apps to Azure OpenAI.
2. **Remove `backend/llm_provider.py`**: The multi-provider fallback and simulated endpoint switching logic are replaced by native Azure OpenAI client classes.
3. **Direct SDK Telemetry**: Enable native OpenTelemetry logging to Azure Application Insights:

```python
from azure.monitor.opentelemetry import configure_azure_monitor
configure_azure_monitor() # Automatically traces every MAF and Azure OpenAI call
```

---

## 5. Production Infrastructure Deployment (Bicep / Terraform)

### Azure CLI Setup (One-Time IAM Role Assignment)

Grant the Azure Container App / App Service Managed Identity permission to call Azure OpenAI without keys:

```bash
# Assign 'Cognitive Services OpenAI User' role to the Application's Managed Identity
az role assignment create \
    --assignee-object-id "<YOUR_CONTAINER_APP_PRINCIPAL_ID>" \
    --assignee-principal-type "ServicePrincipal" \
    --role "5e0bd9ba-c731-4588-83e1-00c8122497ac" \
    --scope "/subscriptions/<SUB_ID>/resourceGroups/<RG>/providers/Microsoft.CognitiveServices/accounts/<AOAI_RESOURCE_NAME>"
```

### Azure Bicep Template for PTU Deployment

```bicep
param openAiResourceName string = 'aoai-medical-claim-prod'
param location string = 'eastus'

resource openAiAccount 'Microsoft.CognitiveServices/accounts@2023-05-01' = {
  name: openAiResourceName
  location: location
  sku: {
    name: 'S0'
  }
  kind: 'OpenAI'
  properties: {
    customSubDomainName: openAiResourceName
    publicNetworkAccess: 'Disabled' // Enforce private endpoint VNet
  }
}

// Deploy GPT-5.4 / GPT-4o with Provisioned Throughput Units (PTU)
resource gptDeployment 'Microsoft.CognitiveServices/accounts/deployments@2023-05-01' = {
  parent: openAiAccount
  name: 'gpt-5-medical-validator'
  sku: {
    name: 'ProvisionedManaged'
    capacity: 100 // 100 PTUs for deterministic low-latency throughput
  }
  properties: {
    model: {
      format: 'OpenAI'
      name: 'gpt-5'
      version: '2026-preview'
    }
  }
}
```

---

## 6. Environment Variables Comparison Matrix

| Variable | Local Development (.env) | Azure Production (App Settings / Key Vault) |
| :--- | :--- | :--- |
| `LLM_PROVIDER` | `mistral` / `groq` / `nvidia` | *Deprecated / Removed* |
| `MAF_RESPONSES_URL` | `http://127.0.0.1:8000/v1` | *Deprecated / Removed* |
| `AZURE_OPENAI_ENDPOINT` | *Not used* | `https://aoai-medical-claim-prod.openai.azure.com/` |
| `AZURE_OPENAI_API_VERSION` | *Not used* | `2024-10-21` |
| `AZURE_EXTRACTOR_DEPLOYMENT`| *Not used* | `gpt-5-medical-extractor` |
| `AZURE_VALIDATOR_DEPLOYMENT`| *Not used* | `gpt-5-medical-validator` |
| `NEO4J_URI` | `neo4j://localhost:7687` | `neo4j+s://<aura-db-id>.databases.neo4j.io` |
| `APPLICATIONINSIGHTS_CONNECTION_STRING` | *Optional* | `InstrumentationKey=...;IngestionEndpoint=...` |

---

## 7. Production Checklist for Go-Live

- [x] **Zero-Trust IAM**: Managed Identity configured with `Cognitive Services OpenAI User` role.
- [x] **Private Networking**: Azure OpenAI private endpoints integrated into the Azure Container App Virtual Network (VNet).
- [x] **Provisioned Throughput**: Core validation models deployed on PTU instances to guarantee <3s inference latencies during peak claim processing hours.
- [x] **Strict Pydantic Parsing**: Zero string-splitting or manual regex parsing of LLM outputs; all structured outputs enforced via `response_format` JSON schema.
- [x] **Immutable Audit Storage**: Telemetry streamed to Azure Application Insights; JSON audit reports archived to Azure Cosmos DB / Azure Blob Storage with retention policies.
- [x] **Deterministic Rule Engine Preserved**: Tabular rule verification (`backend/rule_engine.py`) remains 100% deterministic code in the container, never delegated to LLM probabilistic guessing.
