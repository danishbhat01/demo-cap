# Azure Cosmos DB Migration Plan

This document outlines the step-by-step strategy for migrating the local ChromaDB vector database to **Azure Cosmos DB for MongoDB vCore** (which supports native Vector Search). 

While the current iteration of the project uses ChromaDB for local development, testing, and the capstone demonstration, this plan serves as the blueprint for the enterprise cloud deployment phase.

---

## 1. Architecture Overview

### Current State (Local)
* **ETL:** PyMuPDF extracts text $\rightarrow$ SentenceTransformers embeds chunks $\rightarrow$ Saved to local `rag_chroma_db` folder.
* **Retrieval:** `data_agent.py` loads the local ChromaDB directory and performs a local similarity search.

### Future State (Azure Production)
* **ETL:** PyMuPDF extracts text $\rightarrow$ SentenceTransformers (or Azure OpenAI `text-embedding-ada-002`) embeds chunks $\rightarrow$ Pushed to an Azure Cosmos DB collection.
* **Retrieval:** `data_agent.py` authenticates via connection string (stored in Azure Key Vault), embeds the search query, and uses the native MongoDB `$vectorSearch` pipeline to retrieve chunks.

---

## 2. ETL Pipeline Migration (Populating Cosmos DB)

The ETL pipeline (`data/guideline_data/vector_db_creator/etl_pipeline.py`) will be updated to use `pymongo` instead of the `chromadb` client.

### Step 2.1: Establish Connection and Create Vector Index
Before inserting documents, Cosmos DB requires a specific Vector Index to be defined on the collection.

```python
import os
import pymongo

# 1. Connect to Azure Cosmos DB (Credentials securely fetched from Azure Key Vault)
client = pymongo.MongoClient(os.getenv("COSMOS_CONNECTION_STRING"))
db = client["MedicalCodingDB"]
collection = db["Guidelines"]

# 2. Create the Vector Index (Run once during initial setup)
db.command({
    "createIndexes": "Guidelines",
    "indexes": [{
        "key": {"embedding": "cosmosSearch"},
        "name": "vectorSearchIndex",
        "cosmosSearchOptions": {
            "kind": "vector-ivf",
            "numLists": 1,
            "similarity": "COS",
            "dimensions": 384 # 384 for MiniLM, 1536 if switching to Azure OpenAI
        }
    }]
})
```

### Step 2.2: Insert Vector Documents
The chunking logic remains identical. We just format the output as a MongoDB JSON document and insert it.

```python
# 3. Insert Chunks (Same chunking loop currently used)
for chunk in chunks:
    # Compute the embedding array
    embedding = embedding_function(chunk["text"])
    
    document = {
        "chunk_id": chunk["id"],
        "disease_entity": chunk["disease_entity"],
        "source": chunk["source"],
        "text": chunk["text"],
        "embedding": embedding # The high-dimensional array
    }
    collection.insert_one(document)
```

---

## 3. Application Migration (Fetching from Cosmos DB)

The retrieval logic in `backend/data_agent.py` will be updated to replace ChromaDB's `.query()` method with a MongoDB aggregation pipeline using the native `$vectorSearch` operator.

### Step 3.1: Update `get_rag_guidelines`
The `data_agent.py` function will be refactored as follows:

```python
def get_rag_guidelines(disease_name: str, synonyms: list) -> list[dict]:
    # 1. Compute embedding for the search query (e.g., "HIV Acquired immunodeficiency syndrome")
    search_query = " ".join([disease_name] + synonyms)
    query_vector = embedding_function(search_query)
    
    # 2. Run Native Vector Search in Cosmos DB
    pipeline = [
        {
            "$search": {
                "cosmosSearch": {
                    "vector": query_vector,
                    "path": "embedding",
                    "k": 2 # Return the top 2 most relevant chunks
                },
                "returnStoredSource": True 
            }
        },
        {
            "$project": {
                "embedding": 0, # Exclude the huge vector array from the response to save bandwidth
                "_id": 0
            }
        }
    ]
    
    # Execute the query against Cosmos DB
    results = collection.aggregate(pipeline)
    
    # 3. Format exactly like the old ChromaDB response for seamless integration
    retrieved_chunks = []
    for doc in results:
        retrieved_chunks.append({
            "source": doc.get("source", "Unknown Section"),
            "disease_entity": doc.get("disease_entity", "Unknown Entity"),
            "text": doc.get("text", "")
        })
        
    return retrieved_chunks
```

---

## 4. Why This Migration is Seamless

1. **Decoupled Architecture:** The Microsoft Agent Framework (MAF) state machine (Nodes 0 through 7) has no dependencies on the underlying vector database. It simply expects `get_rag_guidelines` to return a list of dictionaries containing `"text"` and `"source"`. 
2. **Key Vault Integration:** The `COSMOS_CONNECTION_STRING` is injected dynamically at runtime via Azure Key Vault. This allows developers to toggle between local ChromaDB and cloud Cosmos DB effortlessly by swapping environment variables.
