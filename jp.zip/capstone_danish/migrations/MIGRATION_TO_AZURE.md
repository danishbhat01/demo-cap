# Cloud Migration Guide

This document details exactly how to transition this medical coding system from a local development environment (running local ChromaDB, local Neo4j, and local models) to the target highly-scalable production infrastructure on Azure.

## 1. Environment Variables Configuration
To trigger the cloud pathways, you must provide the following credentials in your `.env` file on your office laptop. The application logic is designed to automatically detect these keys and route traffic to the cloud services.

```env
# Azure OpenAI (For System LLM and Cosmos DB Embeddings)
AZURE_OPENAI_API_KEY=your_azure_openai_key
AZURE_OPENAI_ENDPOINT=https://your-resource-name.openai.azure.com/

# Azure Key Vault (For Blob Storage Secrets)
AZURE_KEY_VAULT_URL=https://your-vault.vault.azure.net/

# Azure Cosmos DB for MongoDB (vCore) (Vector Database)
COSMOS_MONGO_URI=mongodb+srv://<user>:<password>@<cluster>.mongocluster.cosmos.azure.com/?tls=true&authMechanism=SCRAM-SHA-256&retrywrites=false&maxIdleTimeMS=120000

# Neo4j Aura (Knowledge Graph)
NEO4J_URI=neo4j+s://<your-db-id>.databases.neo4j.io
NEO4J_USERNAME=neo4j
NEO4J_PASSWORD=your_aura_password
```

## 2. Pre-Flight Security (Critical)
Before pushing to GitHub for an Azure deployment, you **must** ensure a `.gitignore` exists at the root of the project to prevent `.env` file leakage.
Create a root `.gitignore` containing:
```text
.env
__pycache__/
venv/
rag_chroma_db/
sessions/
*.pdf
```

## 3. Hard Removal of Local Vector Database (ChromaDB)
Once you have migrated to Cosmos DB, you should remove the heavy local vector search libraries to dramatically reduce your Docker image size and RAM usage.

### Update Requirements.txt
Remove the following packages from your `requirements.txt`:
- `chromadb`
- `sentence-transformers`

**Add** the following required Azure SDKs for production:
- `azure-identity`
- `azure-keyvault-secrets`
- `azure-storage-blob`

### Code Cleanup in `backend/data_agent.py`
To fully sanitize the codebase, you can completely delete the ChromaDB fallback block.

**Delete Lines:**
```python
# Initialize ChromaDB for local fallback RAG
try:
    chroma_client = chromadb.PersistentClient(path=os.path.join(os.path.dirname(__file__), '..', 'rag_chroma_db'))
    sentence_transformer_ef = embedding_functions.SentenceTransformerEmbeddingFunction(model_name="all-MiniLM-L6-v2")
    collection = chroma_client.get_collection(name="icd10_guidelines", embedding_function=sentence_transformer_ef)
except Exception as e:
    print(f"Warning: Could not initialize local ChromaDB: {e}")
    collection = None
```

Inside `get_rag_guidelines()`, delete the **Branch 2: Local ChromaDB Fallback** section entirely.

## 4. Neo4j Migration to Aura
The transition to Neo4j Aura is entirely seamless. Because Neo4j's Cypher driver (`neo4j` python package) is identical for local and cloud databases, all you have to do is change the `NEO4J_URI` from `bolt://localhost:7687` to your `neo4j+s://...` Aura endpoint. **No code changes are required.**

## 5. Local Model Removal
If you were using any local GGUF models or Ollama for the Validator Agent in `llm_provider.py`, you can now completely strip that out. 
The system will natively use `AzureOpenAI` via the `openai` python package using the endpoint provided in the `.env` file.
