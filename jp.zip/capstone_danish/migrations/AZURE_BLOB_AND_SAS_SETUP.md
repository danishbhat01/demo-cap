# Azure Blob Storage & SAS URL Setup Guide

**STATUS: [✅ IMPLEMENTED IN CODE (`api/blob_service.py`)]**

> **Context:** This guide is for your office laptop / Azure deployment environment.
> The logic to dynamically switch between Azure SAS Tokens and Local Disk is completely implemented. Your local machine continues to use the `data/uploads/` filesystem automatically when Azure keys are absent.

---

## What This Guide Covers

1. Setting up Azure Blob Storage for PDF persistence.
2. Configuring the connection secret in Azure Key Vault.
3. Enabling SAS URL generation for the React frontend (PDF evidence highlighting).
4. Verifying it works using the included dummy test.

---

## Prerequisites

Make sure you have the following Azure resources already provisioned:

- Azure Key Vault (with Managed Identity assigned to your Container Apps)
- Azure Storage Account (General Purpose v2)

---

## Step 1: Create the Blob Container

In the Azure Portal:

1. Navigate to your Storage Account.
2. Click **Containers** → **+ Container**.
3. Name it: `pdf-uploads`
4. Set access level: **Private (no anonymous access)**.

---

## Step 2: Get the Connection String

1. In your Storage Account, go to **Access Keys** under **Security + Networking**.
2. Copy **Connection string** under `key1`.
3. It will look like:
   ```
   DefaultEndpointsProtocol=https;AccountName=...;AccountKey=...;EndpointSuffix=core.windows.net
   ```

---

## Step 3: Store the Secret in Azure Key Vault

1. In your Azure Key Vault, click **Secrets** → **+ Generate/Import**.
2. Set the name to: `AZURE-STORAGE-CONNECTION-STRING`
   *(Note: Key Vault uses hyphens, the code auto-translates underscores to hyphens)*
3. Paste the connection string as the value and save.

---

## Step 4: Set the Environment Variable

On your office laptop (or in the Azure Container App environment settings), set:

```bash
AZURE_KEY_VAULT_URL=https://your-keyvault-name.vault.azure.net/
AZURE_BLOB_CONTAINER=pdf-uploads
```

> The code will automatically use `DefaultAzureCredential`, which uses your Managed Identity on Azure (or `az login` credentials locally on your office laptop).

---

## Step 5: Install Required SDK Packages

```bash
pip install azure-storage-blob azure-identity azure-keyvault-secrets
```

Add these to `requirements.txt` when ready.

---

## Step 6: Verify Using the Dummy Test

Run from the project root on your office laptop:

```bash
python -m tests.test_blob_service
```

**Expected output in Azure mode:**
```
[Mode] Running in: AZURE
[Upload] Uploading dummy PDF for job_id: test-job-00000000
[Upload] SUCCESS → jobs/test-job-00000000/chart.pdf
[URL] Generating access URL for frontend...
[URL] SUCCESS → https://your-account.blob.core.windows.net/pdf-uploads/jobs/...?sv=...
All checks passed!
```

**Expected output in local mode (no credentials):**
```
[Mode] Running in: LOCAL FILESYSTEM
[Upload] SUCCESS → /tmp/tmpXXXXXX/chart.pdf
[URL] SUCCESS → /tmp/tmpXXXXXX/chart.pdf
All checks passed!
```

---

## Step 7: How Evidence Highlighting Works (Frontend Integration)

Once the Azure mode is active, the FastAPI endpoint `GET /jobs/{job_id}/pdf/{doc_type}` can be extended to return a SAS URL instead of serving the binary file directly. Call `blob_service.get_pdf_url()` with the `job_id` and the PDF filename to get a temporary secure URL (valid 1 hour by default), then pass it to the React PDF viewer (`react-pdf` or `pdf.js`).

---

## Files Touched By This Feature

| File | Purpose |
|---|---|
| `api/blob_service.py` | The 3-tier storage abstraction (Key Vault → .env → Local) |
| `tests/test_blob_service.py` | Dummy test to verify both local and Azure modes |
| `migrations/AZURE_BLOB_AND_SAS_SETUP.md` | This document |
