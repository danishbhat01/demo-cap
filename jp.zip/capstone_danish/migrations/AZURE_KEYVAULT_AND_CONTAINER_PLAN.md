# Azure Key Vault & Containerization Migration Plan

**STATUS: [✅ IMPLEMENTED IN CODE]**
*Note: Key Vault secret resolution was directly implemented inside `api/blob_service.py` rather than a global `secrets_manager.py` to keep the codebase modular.*

This document outlines the required steps to migrate the local `.env` secrets architecture to a secure **Azure Key Vault** implementation, and details the strategy for splitting the monolithic API into a decoupled two-container architecture.

These changes should be executed **only** when the project is migrated to the corporate/office environment where Azure Key Vault is accessible.

---

## 1. Secrets Management (Key Vault Sanitization)

Currently, the application relies on `os.environ.get()` to pull secrets from a local `.env` file. To migrate to Azure securely, the `api/blob_service.py` intercepts these requests using `DefaultAzureCredential`.

### Step 1.1: Create `backend/secrets_manager.py`
Create this new file to act as the abstraction layer. It will attempt to pull from Key Vault if `AZURE_KEY_VAULT_URL` is set, and seamlessly fall back to local environment variables if it fails or if the URL is missing.

```python
import os
from dotenv import load_dotenv

# Ensure local .env is loaded for local development
dotenv_path = os.path.join(os.path.dirname(__file__), '..', '.env')
load_dotenv(dotenv_path)

_secret_client = None
_use_keyvault = False

def init_keyvault():
    """Initializes the Azure Key Vault client if the URL is provided."""
    global _secret_client, _use_keyvault
    keyvault_url = os.environ.get("AZURE_KEY_VAULT_URL")
    
    if keyvault_url:
        try:
            from azure.identity import DefaultAzureCredential
            from azure.keyvault.secrets import SecretClient
            
            # DefaultAzureCredential automatically uses Managed Identity in Azure
            credential = DefaultAzureCredential()
            _secret_client = SecretClient(vault_url=keyvault_url, credential=credential)
            _use_keyvault = True
            print(f"Azure Key Vault successfully initialized: {keyvault_url}")
        except ImportError:
            print("Warning: azure-identity or azure-keyvault-secrets SDK not installed. Falling back to local env.")
        except Exception as e:
            print(f"Warning: Failed to connect to Key Vault: {e}")

def get_secret(secret_name: str, default: str = None) -> str:
    """
    Fetches a secret from Azure Key Vault. 
    Falls back to os.environ.get() if Key Vault is disabled or the secret is missing.
    """
    if _use_keyvault and _secret_client:
        # Azure Key Vault naming convention uses hyphens instead of underscores
        kv_secret_name = secret_name.replace("_", "-")
        try:
            return _secret_client.get_secret(kv_secret_name).value
        except Exception:
            # Secret not found in Vault, allow fallback to local environment
            pass
            
    return os.environ.get(secret_name, default)

# Auto-initialize on import
init_keyvault()
```

### Step 1.2: Sanitize Factory Logic
Replace all instances of `os.environ.get()` with the new `get_secret()` function. 

**In `backend/llm_provider.py`:**
```python
from .secrets_manager import get_secret

def get_llm_client(temperature: float = 0.0) -> OpenAIChatClient:
    azure_key = get_secret("AZURE_OPENAI_KEY")
    azure_endpoint = get_secret("AZURE_OPENAI_ENDPOINT")
    # ... apply to GEMINI_API_KEY, MISTRAL_API_KEY, etc.
```

**In `api/ocr_service.py`:**
```python
import sys
import os
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'backend')))
from secrets_manager import get_secret

def _extract_with_mistral(pdf_path: str) -> str:
    mistral_key = get_secret("MISTRAL_API_KEY")
    # ...
```

**In `backend/orchestrator.py` (Neo4j Connection):**
```python
from .secrets_manager import get_secret

def run_claim_validation(...):
    neo4j_uri = get_secret("NEO4J_URI", "bolt://localhost:7687")
    neo4j_user = get_secret("NEO4J_USER", "neo4j")
    neo4j_password = get_secret("NEO4J_PASSWORD", "password")
    
    with GraphDatabase.driver(neo4j_uri, auth=(neo4j_user, neo4j_password)) as driver:
        # ...
```

---

## 2. Decoupled Containerization Architecture

Currently, the FastAPI application (`api/main.py`) spawns a background thread to run the orchestrator in the exact same container. To meet enterprise requirements, this must be decoupled into two containers.

### Container A: The API Web Server (FastAPI)
* **Role:** Receives PDF uploads from the React Frontend (hosted on Azure Web Apps).
* **Action:** Saves the PDFs to Azure Blob Storage instead of the local filesystem.
* **Message Broker:** Drops a JSON payload onto an **Azure Service Bus Queue** containing the Blob Storage URIs and the `job_id`.
* **Status Checks:** Continues to serve GET requests for job status by querying the shared database (or Redis).

### Container B: The Backend Worker (MAF Orchestrator)
* **Role:** An infinite loop script that listens to the Azure Service Bus Queue.
* **Action:** When a message arrives, it downloads the PDFs from Blob Storage.
* **Execution:** It runs `orchestrator.py` natively.
* **Result:** It pushes intermediate progress and final results back to the database.

### Required Azure Infrastructure Changes
1. **Azure Service Bus:** Create a queue (e.g., `audit-jobs-queue`).
2. **Azure Blob Storage:** Create a container (e.g., `pdf-uploads`).
3. **Container Apps / AKS:** Deploy Container A (Exposed via ingress) and Container B (Internal worker only, scaled via KEDA based on queue length).
