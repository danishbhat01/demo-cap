import os
import sys
import json
from datetime import datetime

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '../backend')))
from orchestrator import run_claim_validation

def write_audit_report(test_case_num, name, state):
    reports_dir = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'insights', 'audit_reports')
    os.makedirs(reports_dir, exist_ok=True)
    
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    filename = f"TC{test_case_num}_{name.replace(' ', '_')}_{timestamp}.json"
    filepath = os.path.join(reports_dir, filename)
    
    report_data = {
        "test_case": name,
        "raw_claimed_codes": state["raw_claimed_codes"],
        "final_validated_sequence": state["validated_sequence"],
        "dropped_codes": state["dropped_codes"],
        "suggested_additions": state["suggested_additions"],
        "detailed_audit": state["audit_report"]
    }
    
    with open(filepath, 'w', encoding='utf-8') as f:
        json.dump(report_data, f, indent=2)
        
    print(f"\n[{name}] Audit report saved to {filepath}")

def safe_print(text):
    try:
        print(text)
    except UnicodeEncodeError:
        print(text.encode('ascii', 'replace').decode('ascii'))

def print_summary(state):
    safe_print("\n" + "="*50)
    safe_print("FINAL VALIDATED AUDIT REPORT")
    safe_print("="*50)
    safe_print("VALIDATED SEQUENCE:")
    for v in state["validated_sequence"]:
        safe_print(f"  - {v['code']} (Type: {v['type']}, Position: {v['sequencing_position']})")
        
    if state["dropped_codes"]:
        safe_print("\nDROPPED CODES:")
        for d in state["dropped_codes"]:
            safe_print(f"  - {d['code']}: {d['reason']}")
            
    if state["suggested_additions"]:
        safe_print("\nSUGGESTED ADDITIONS:")
        for s in state["suggested_additions"]:
            safe_print(f"  - {s['code']}: {s['reason']}")
            
    safe_print("\nDETAILED DECISIONS:")
    for detail in state["audit_report"]:
        safe_print(f"\n[{detail['decision']}] Code: {detail['code']}")
        safe_print(f"  Rationale: {detail['rationale']}")
        safe_print(f"  Chart Evidence: {detail['chart_evidence']}")
        safe_print(f"  Coding Rule: {detail['coding_rule']}")
        if detail.get('swap_to'):
             safe_print(f"  Swapped To: {detail['swap_to']}")
        if detail.get('companion_codes_required'):
            safe_print(f"  Companion Codes Required: {', '.join(detail['companion_codes_required'])}")
        if detail.get('warnings'):
            safe_print(f"  Warnings: {', '.join(detail['warnings'])}")
    safe_print("="*50 + "\n")

def run_test_case(test_case_num, name, clinical_text, code_queue):
    print(f"\n\n{'#'*80}")
    print(f"RUNNING TEST CASE {test_case_num}: {name}")
    print(f"{'#'*80}")
    print(f"[Input] Claimed Codes: {code_queue}")
    print(f"[Input] Clinical Text:\n{clinical_text}")
    
    state = run_claim_validation(clinical_text, code_queue)
    
    write_audit_report(test_case_num, name, state)
    print_summary(state)

if __name__ == "__main__":
    print("STARTING FULL PIPELINE TEST RUNNER")
    
    # Test Case 1
    tc1_text = "Patient is admitted to Inpatient. Sepsis confirmed, severity=Severe. Blood cultures came back positive for MRSA. Acute kidney failure documented as organ dysfunction."
    tc1_codes = ["A41.9", "R65.20"]
    run_test_case(1, "Sepsis_MRSA_CodeRange", tc1_text, tc1_codes)
    
    # Test Case 2
    tc2_text = "Patient admitted to Outpatient. Known HIV-positive, CD4 count 620 cells/uL, viral load undetectable. Patient is currently asymptomatic."
    tc2_codes = ["B20"]
    run_test_case(2, "HIV_Asymptomatic_Swap", tc2_text, tc2_codes)
    
    # Test Case 3
    tc3_text = "Inpatient admission. HIV confirmed. Patient is highly symptomatic with history of AIDS."
    tc3_codes = ["B20", "Z21"]
    run_test_case(3, "HIV_Excludes1_Conflict", tc3_text, tc3_codes)
    
    # Test Case 4
    # M49.82 is Chapter 13. It should be dropped at Node 3 as "not in knowledge graph". A18.01 should be processed.
    tc4_text = "Patient admitted to Inpatient. MRI confirms spinal TB at C4-C5 level (Tuberculosis of spine)."
    tc4_codes = ["A18.01", "M49.82"]
    run_test_case(4, "TB_Missing_Code_Drop", tc4_text, tc4_codes)
    
    # Test Case 5
    tc5_text = "Patient is admitted to Inpatient. Sepsis confirmed. Past medical history: Chronic viral hepatitis B without delta-agent."
    tc5_codes = ["A41.9"]
    run_test_case(5, "Undercoding_Detection", tc5_text, tc5_codes)
    
    print("\nALL TEST CASES COMPLETED.")
