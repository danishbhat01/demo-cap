import os
import sys
from dotenv import load_dotenv

sys.path.append(os.path.dirname(os.path.dirname(__file__)))
sys.path.append(os.path.join(os.path.dirname(os.path.dirname(__file__)), 'backend'))

load_dotenv(os.path.join(os.path.dirname(os.path.dirname(__file__)), '.env'))

from backend.orchestrator import run_claim_validation
from tests.test_runner import print_summary, write_audit_report

def main():
    claimed_codes = [
        "A41.9",
        "R65.20"
    ]
    
    clinical_text = """
    ST MARYS REGIONAL MEDICAL CENTER
    INPATIENT HISTORY AND PHYSICAL
    
    CHIEF COMPLAINT: Fever, altered mental status, and acute hypotension.
    
    HISTORY OF PRESENT ILLNESS:
    68-year-old male admitted with severe sepsis. Blood cultures on admission grew Methicillin-resistant Staphylococcus aureus (MRSA). 
    Patient developed acute kidney failure as organ dysfunction secondary to severe sepsis.
    
    DISCHARGE SUMMARY:
    Final Diagnoses:
    1. Severe sepsis due to MRSA bacteremia
    2. Acute kidney failure secondary to sepsis
    
    Condition on discharge: Stable.
    """
    
    print("="*60)
    print("STARTING TEST CASE 1 PIPELINE RUN")
    print("="*60)
    
    final_state = run_claim_validation(clinical_text, claimed_codes)
    
    write_audit_report(1, "Test_Case_1_Sepsis_MRSA", final_state)
    print_summary(final_state)

if __name__ == "__main__":
    main()
