"""
Layer 3 Test: Validator Agent (The Clinical Judge)
Tests clinical reasoning and decision-making over ICD-10 guidelines and evidence.
"""
import os
import sys
import json

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '../backend')))
from validator_agent import run_validator

def test_validator_layer():
    print("=" * 60)
    print("  LAYER 3 TEST: VALIDATOR AGENT (CLINICAL JUDGE)")
    print("=" * 60)

    test_payload = {
        "target_code": "A41.02",
        "description": "Sepsis due to Methicillin resistant Staphylococcus aureus",
        "evidence_db": {
            "diagnoses": [
                {
                    "name": "Sepsis due to MRSA",
                    "confirmed": True,
                    "organism": "MRSA"
                }
            ],
            "raw_text_summary": "54yo male admitted with Sepsis due to MRSA. Blood cultures grew MRSA."
        },
        "retrieved_guidelines": [
            {
                "section": "Section I.C.1.e.1.a",
                "title": "Combination codes for MRSA infection",
                "text": "When a combination code for MRSA infection is available (such as A41.02, Sepsis due to Methicillin resistant Staphylococcus aureus), use that code."
            }
        ],
        "tabular_rules": {
            "EXCLUDES1": [],
            "CODE_FIRST": [],
            "USE_ADDITIONAL_CODE": []
        },
        "claimed_codes": ["A41.9", "B95.62"]
    }

    print("\n[Input] Testing Target Code: A41.02")
    print(f"Evidence: {test_payload['evidence_db']['diagnoses'][0]['name']}")
    
    print("\n[Running] Validator Agent...")
    verdict = run_validator(test_payload)

    print("\n[Output] Validator Decision:")
    print(f"  Decision: {verdict.decision}")
    print(f"  Rationale: {verdict.rationale}")
    print(f"  Sequencing: {verdict.sequencing_position}")
    print(f"  Warnings: {verdict.warnings}")

    assert verdict.decision in ["VALID", "SWAP"], f"Expected VALID or SWAP, got {verdict.decision}"
    assert len(verdict.rationale) > 0, "Rationale must not be empty"

    print("\n[PASS] Layer 3 (Validator Agent) successfully verified!")

if __name__ == "__main__":
    test_validator_layer()
