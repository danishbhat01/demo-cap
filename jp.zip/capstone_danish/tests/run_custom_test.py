import os
import sys
import json
from dotenv import load_dotenv

# Set paths
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, BASE_DIR)
sys.path.insert(0, os.path.join(BASE_DIR, 'backend'))

# Load environment variables
load_dotenv(os.path.join(BASE_DIR, '.env'), override=True)

from backend.orchestrator import run_claim_validation
from tests.test_runner import print_summary, write_audit_report

def main():
    print("\n" + "=" * 70)
    print("      CUSTOM CLAIM VALIDATION TEST RUNNER")
    print("=" * 70)

    # =========================================================================
    # 1. ENTER YOUR CLAIMED ICD-10 CODES HERE
    # =========================================================================
    claimed_codes = [
        "B39.3",
    "B59",
    "J96.01",
    "D84.9"
    ]

    # =========================================================================
    # 2. PASTE YOUR CLINICAL MEDICAL CHART TEXT (OR DISCHARGE SUMMARY) HERE
    # =========================================================================
    clinical_text ="""
    ST MARYS REGIONAL MEDICAL CENTER

INPATIENT

------------------------------------------------------------

CHIEF COMPLAINT

persistent fever worsening shortness of breath
progressive fatigue weight loss x4 weeks

------------------------------------------------------------

HISTORY OF PRESENT ILLNESS

58 year old male

history of renal transplant three years ago

currently receiving tacrolimus and prednisone

reports persistent fever dry cough increasing dyspnea

symptoms gradually worsening over past month

denies history HIV infection

------------------------------------------------------------

PAST MEDICAL HISTORY

renal transplant

chronic immunosuppressive therapy

hypertension

------------------------------------------------------------

HOME MEDICATIONS

Tacrolimus

Prednisone

Amlodipine

------------------------------------------------------------

ALLERGIES

NKDA

------------------------------------------------------------

PHYSICAL EXAM

temperature 101.8 F

pulse 110

blood pressure 118/72

respiratory rate 28

oxygen saturation 86 percent room air

general

chronically ill appearing

lungs

diffuse bilateral crackles

oral mucosa

multiple ulcerative lesions

============================================================

PAGE 2

LAB RESULTS

CBC

WBC 2.8

Hemoglobin 9.6

Platelets 135

Fungal antigen

Histoplasma urine antigen POSITIVE

LDH elevated

------------------------------------------------------------

RADIOLOGY

CT CHEST

Diffuse bilateral pulmonary infiltrates

Multiple pulmonary nodules

Findings concerning for disseminated fungal infection

============================================================

PAGE 3

INFECTIOUS DISEASE CONSULT

Jennifer Smith MD

Bronchoscopy performed

BAL specimen positive for Pneumocystis jirovecii by PCR

Bone marrow biopsy demonstrates disseminated
Histoplasma capsulatum infection

ASSESSMENT

Disseminated histoplasmosis confirmed

Pneumocystis jirovecii pneumonia confirmed

No evidence HIV infection

============================================================

PAGE 4

PROGRESS NOTE

Hospital Day 4

patient improving on liposomal amphotericin B

TMP SMX continued

oxygen requirement decreasing

repeat cultures negative for bacterial infection

============================================================

PAGE 5

DISCHARGE SUMMARY

hospital course

patient admitted for disseminated histoplasmosis
with concurrent Pneumocystis jirovecii pneumonia

clinical improvement after antifungal therapy
and TMP SMX

------------------------------------------------------------

FINAL DIAGNOSES

Disseminated histoplasmosis

Pneumocystis jirovecii pneumonia

Acute hypoxemic respiratory failure

Chronic immunosuppression after renal transplant

------------------------------------------------------------

DISCHARGE MEDICATIONS

Liposomal Amphotericin B

TMP SMX

Prednisone

Tacrolimus

------------------------------------------------------------

Electronically signed

Jennifer Smith MD

08/03/2026
"""

    # =========================================================================
    # 3. RUN THE PIPELINE
    # =========================================================================
    final_state = run_claim_validation(clinical_text, claimed_codes)

    write_audit_report("Custom", "Custom_Test_Case", final_state)
    print_summary(final_state)


if __name__ == "__main__":
    main()