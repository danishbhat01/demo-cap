import os
import sys
import json
from dotenv import load_dotenv

# Set paths
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, BASE_DIR)
sys.path.insert(0, os.path.join(BASE_DIR, 'backend'))

# Load environment variables
load_dotenv(os.path.join(BASE_DIR, '.env'), override=True)

from backend.orchestrator import run_claim_validation
from tests.test_runner import print_summary, write_audit_report

def main():
    print("\n" + "=" * 70)
    print("           TEST CASE 4 PIPELINE RUNNER")
    print("=" * 70)

    # =========================================================================
    # 1. ENTER YOUR CLAIMED ICD-10 CODES HERE
    # =========================================================================
    claimed_codes = [
        "A41.9",
        "B95.62",
        "I33.0",
        "R65.20"
    ]

    # =========================================================================
    # 2. PASTE YOUR CLINICAL MEDICAL CHART TEXT HERE
    # =========================================================================
    clinical_text = """
    ST MARYS REGIONAL MEDICAL CENTER

INPATIENT

------------------------------------------------------------

CHIEF COMPLAINT

fever x5 days

chills

progressive fatigue

shortness of breath

generalized weakness

------------------------------------------------------------

HISTORY OF PRESENT ILLNESS

54 year old male presented with persistent fever chills
progressive weakness and worsening shortness of breath
for approximately five days

patient reports symptoms began several days after redness
developed around chronic hemodialysis catheter site

reports decreased appetite

denies recent travel

denies sick contacts

no vomiting

no diarrhea

blood cultures obtained prior to antibiotics

patient admitted for suspected severe systemic infection

------------------------------------------------------------

PAST MEDICAL HISTORY

end stage renal disease on hemodialysis

hypertension

type 2 diabetes mellitus

------------------------------------------------------------

PAST SURGICAL HISTORY

dialysis catheter placement

------------------------------------------------------------

SOCIAL HISTORY

former smoker

drinks alcohol occasionally

denies intravenous drug use

------------------------------------------------------------

HOME MEDICATIONS

amlodipine

insulin glargine

calcium acetate

------------------------------------------------------------

ALLERGIES

NKDA

------------------------------------------------------------

REVIEW OF SYSTEMS

constitutional

positive fever

positive chills

positive fatigue

respiratory

positive shortness of breath

negative productive cough

cardiovascular

negative chest pain

GI

poor appetite

negative abdominal pain

neurological

denies focal weakness

------------------------------------------------------------

PHYSICAL EXAM

temperature 103.4 F

pulse 126

blood pressure 90/58

respiratory rate 28

oxygen saturation 93 percent room air

general

appears acutely ill

HEENT

dry mucous membranes

neck supple

heart

tachycardic

new systolic murmur appreciated

lungs

clear bilaterally

abdomen

soft nontender

extremities

mild erythema surrounding right internal jugular dialysis
catheter insertion site

------------------------------------------------------------

INITIAL ASSESSMENT

severe sepsis

suspected catheter related bloodstream infection

possible infective endocarditis

infectious disease consultation requested

patient admitted to internal medicine

============================================================

PAGE 2

EMERGENCY DEPARTMENT PHYSICIAN NOTE

patient remained hypotensive after initial fluid
resuscitation

broad spectrum intravenous antibiotics initiated

blood cultures pending

------------------------------------------------------------

LAB RESULTS

CBC

WBC 18.4

Hemoglobin 10.8

Platelets 196

CMP

Sodium 131

Potassium 5.2

Creatinine 6.2

AST 42

ALT 36

Lactate 4.9 mmol L

Procalcitonin markedly elevated

------------------------------------------------------------

MICROBIOLOGY

Blood cultures

Positive in 2 of 2 bottles

Methicillin resistant Staphylococcus aureus MRSA isolated

------------------------------------------------------------

RADIOLOGY REPORT

Chest X ray

No focal pulmonary infiltrate

------------------------------------------------------------

ECHOCARDIOGRAM

Large mobile vegetation attached to native mitral valve

Findings highly consistent with acute infective
endocarditis

------------------------------------------------------------

MEDICATIONS STARTED

Vancomycin IV

Piperacillin Tazobactam IV

Intravenous fluids

============================================================

PAGE 3

INFECTIOUS DISEASE CONSULT

Sarah Mitchell MD

history reviewed

blood cultures confirmed MRSA bacteremia

clinical findings diagnostic of sepsis due to MRSA

native mitral valve infective endocarditis secondary to
MRSA bacteremia

recommend discontinue empiric broad spectrum therapy

continue intravenous vancomycin

------------------------------------------------------------

ASSESSMENT

Sepsis due to MRSA

MRSA bacteremia

Acute infective endocarditis involving native mitral valve

No evidence meningitis

No evidence osteomyelitis

No evidence pneumonia

============================================================

PAGE 4

PROGRESS NOTE

Hospital Day 4

patient afebrile overnight

blood pressure improved

repeat blood cultures negative

continue intravenous vancomycin

repeat assessment

MRSA sepsis improving

infective endocarditis clinically improving

============================================================

PAGE 5

DISCHARGE SUMMARY

hospital course

patient admitted with severe sepsis secondary to MRSA
bloodstream infection complicated by acute infective
endocarditis

responded well to intravenous vancomycin

repeat blood cultures sterile prior to discharge

infectious disease follow up arranged

------------------------------------------------------------

FINAL DIAGNOSES

Sepsis due to MRSA

Acute infective endocarditis of native mitral valve

MRSA bacteremia

------------------------------------------------------------

DISCHARGE MEDICATIONS

Vancomycin IV

Home antihypertensive medications

Insulin

------------------------------------------------------------

Electronically signed

Sarah Mitchell MD

08/14/2026
    """

    # =========================================================================
    # 3. RUN PIPELINE & GENERATE AUDIT REPORT
    # =========================================================================
    print(f"\n[Input] Claimed Codes: {claimed_codes}")
    print(f"[Input] Medical Chart:\n{clinical_text.strip()}\n")
    print("=" * 70)
    print("Processing claim through Graph & LLM Validation Pipeline...")
    print("=" * 70)

    final_state = run_claim_validation(clinical_text, claimed_codes)

    # Save and display audit results
    write_audit_report(4, "Test_Case_4", final_state)
    print_summary(final_state)

    # Print Full JSON
    print("\n" + "=" * 70)
    print("COMPLETE AUDIT REPORT JSON FOR TEST CASE 4:")
    print("=" * 70)
    report_data = {
        "test_case": "Test_Case_4",
        "raw_claimed_codes": final_state["raw_claimed_codes"],
        "final_validated_sequence": final_state["validated_sequence"],
        "dropped_codes": final_state["dropped_codes"],
        "suggested_additions": final_state["suggested_additions"],
        "detailed_audit": final_state["audit_report"]
    }
    print(json.dumps(report_data, indent=2))

if __name__ == "__main__":
    main()
