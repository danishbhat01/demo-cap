# Medical Coding AI Pipeline Tests & Test Suites

This directory contains test suites designed to test both the end-to-end Multi-Agent Framework (MAF) pipeline and each individual layer in isolation.

All execution logs and generated audit reports are automatically stored in the [`insights/`](../insights/) directory.

---

## 1. End-to-End Test Cases (`run_testcase*.py`)

| Script | Test Case | Scenario Tested |
| :--- | :--- | :--- |
| [`run_testcase1.py`](run_testcase1.py) | **Test Case 1** | **MRSA Sepsis Combination Swap**: Swaps `A41.9` to `A41.02`, drops redundant `B95.62`. |
| [`run_testcase2.py`](run_testcase2.py) | **Test Case 2** | **Asymptomatic HIV**: Swaps `B20` to `Z21` when HIV is asymptomatic with no opportunistic infection. |
| [`run_testcase3.py`](run_testcase3.py) | **Test Case 3** | **HIV Excludes1 Conflict**: Reconciles mutual exclusion conflict between `B20` and `Z21`. |
| [`run_testcase4.py`](run_testcase4.py) | **Test Case 4** | **Missing Code & Scope Filtering**: MRSA Sepsis swap, out-of-scope manual review flags (`I33.0`, `R65.20`). |
| [`run_custom_test.py`](run_custom_test.py) | **Custom Test** | Interactive runner to test custom medical chart text & claim codes. |

### Running End-to-End Test Cases
```powershell
.\venv\Scripts\python tests/run_testcase1.py
.\venv\Scripts\python tests/run_testcase2.py
.\venv\Scripts\python tests/run_testcase3.py
.\venv\Scripts\python tests/run_testcase4.py
.\venv\Scripts\python tests/run_custom_test.py
```

---

## 2. Layer-by-Layer Unit Tests

| Script | Layer Tested | Description |
| :--- | :--- | :--- |
| [`test_layer1_extractor.py`](test_layer1_extractor.py) | **Layer 1: Extractor Agent** | Verifies extraction of clinical diagnoses, organisms, and lab values from unstructured notes into `evidence_db`. |
| [`test_layer2_undercoding.py`](test_layer2_undercoding.py) | **Layer 2: Under-coding Agent** | Verifies Neo4j Knowledge Graph candidate retrieval for unbilled documented diagnoses. |
| [`test_layer3_validator.py`](test_layer3_validator.py) | **Layer 3: Validator Agent** | Verifies clinical LLM judgment, alignment checks, and guideline adherence. |
| [`test_layer4_rule_engine.py`](test_layer4_rule_engine.py) | **Layer 4: Tabular Rule Engine** | Verifies deterministic tabular rules (`EXCLUDES1`, `CODE_FIRST`, `USE_ADDITIONAL_CODE`, range matching). |

### Running Layer Tests
```powershell
.\venv\Scripts\python tests/test_layer1_extractor.py
.\venv\Scripts\python tests/test_layer2_undercoding.py
.\venv\Scripts\python tests/test_layer3_validator.py
.\venv\Scripts\python tests/test_layer4_rule_engine.py
```
