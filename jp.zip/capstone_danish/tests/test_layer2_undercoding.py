"""
Layer 2 Test: Under-coding Agent & Neo4j Knowledge Graph Lookup
Tests graph-based candidate code retrieval for unbilled documented diagnoses.
"""
import os
import sys
from dotenv import load_dotenv
from neo4j import GraphDatabase

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '../backend')))
import data_agent

load_dotenv(os.path.abspath(os.path.join(os.path.dirname(__file__), '../.env')))

def test_undercoding_layer():
    print("=" * 60)
    print("  LAYER 2 TEST: UNDER-CODING GRAPH RETRIEVAL")
    print("=" * 60)

    neo4j_uri = os.getenv('NEO4J_URI')
    neo4j_auth = (os.getenv('NEO4J_USERNAME'), os.getenv('NEO4J_PASSWORD'))
    
    with GraphDatabase.driver(neo4j_uri, auth=neo4j_auth) as driver:
        test_queries = [
            {"diagnosis": "Cholera due to Vibrio cholerae", "organism": "Vibrio cholerae"},
            {"diagnosis": "Tuberculosis of lung", "organism": "Mycobacterium tuberculosis"},
            {"diagnosis": "Sepsis due to MRSA", "organism": "MRSA"}
        ]

        for item in test_queries:
            diag = item["diagnosis"]
            org = item["organism"]
            print(f"\n[Query] Diagnosis: '{diag}' | Organism: '{org}'")
            
            matches = data_agent.under_coding_neo4j_lookup(diag, driver, organism=org)
            print(f"  Matches Found ({len(matches)}):")
            for m in matches:
                print(f"    - Code: {m.get('code')} | {m.get('description')} (Score: {m.get('best_match_count')})")
            
            assert len(matches) > 0, f"Expected graph matches for '{diag}'"

    print("\n[PASS] Layer 2 (Under-coding Graph Lookup) successfully verified!")

if __name__ == "__main__":
    test_undercoding_layer()
