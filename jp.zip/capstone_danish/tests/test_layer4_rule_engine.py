"""
Layer 4 Test: Deterministic Tabular Rule Engine (backend/rule_engine.py)
Tests:
1. RangeMatcher: exact, wildcards, closed ranges (e.g. B95-B97).
2. EXCLUDES1 order-independent conflict resolution (B20 vs Z21).
3. CODE_FIRST missing vs satisfied dependency resolution.
4. USE_ADDITIONAL_CODE companion code enforcement.
5. Evidence organism resolution and sequence ordering.
"""
import os
import sys
from pathlib import Path

BACKEND_DIR = Path(__file__).parent.parent / "backend"
sys.path.insert(0, str(BACKEND_DIR))

from rule_engine import (
    RangeMatcher,
    find_organism_for_code,
    reconcile_claim_rules
)

def test_rule_engine_layer():
    print("=" * 60)
    print("  LAYER 4 TEST: TABULAR RULE ENGINE")
    print("=" * 60)

    # 1. RangeMatcher tests
    assert RangeMatcher.matches("B95.62", "B95.62")
    assert not RangeMatcher.matches("B95.62", "B95.61")
    assert RangeMatcher.matches("A05.0", "A05.-")
    assert RangeMatcher.matches("B95.62", "B95-B97")
    assert not RangeMatcher.matches("A41.9", "B95-B97")
    print("[PASS] 1. RangeMatcher (wildcards & closed ranges)")

    # 2. EXCLUDES1 conflict resolution
    clinical_verdicts = [
        {
            "code": "Z21",
            "decision": "VALID",
            "rationale": "Patient is HIV positive without current symptoms.",
            "chart_evidence": "Known HIV positive",
            "coding_rule": "Section I.C.1.a.2",
            "sequencing_position": "secondary"
        },
        {
            "code": "B20",
            "decision": "VALID",
            "rationale": "Patient has confirmed AIDS defining illness.",
            "chart_evidence": "History of AIDS with active opportunistic infection",
            "coding_rule": "Section I.C.1.a.1",
            "sequencing_position": "principal"
        }
    ]

    tabular_rules = {
        "B20": {
            "disease_name": "Human immunodeficiency virus [HIV] disease",
            "EXCLUDES1": [{"target": "Z21", "target_type": "DiseaseCode"}]
        },
        "Z21": {
            "disease_name": "Asymptomatic human immunodeficiency virus [HIV] infection status",
            "EXCLUDES1": [{"target": "B20", "target_type": "DiseaseCode"}]
        }
    }

    result = reconcile_claim_rules(clinical_verdicts, tabular_rules, {})
    valid_codes = [v["code"] for v in result["validated_sequence"]]
    assert "B20" in valid_codes
    assert "Z21" not in valid_codes
    print("[PASS] 2. EXCLUDES1 Mutual Exclusion (B20 retained, Z21 dropped)")

    # 3. CODE_FIRST enforcement
    clinical_cf = [
        {
            "code": "B59",
            "decision": "VALID",
            "rationale": "Pneumocystosis documented.",
            "chart_evidence": "Pneumocystis pneumonia",
            "coding_rule": "Section I.C.1.a.2.b",
            "sequencing_position": "principal"
        },
        {
            "code": "B20",
            "decision": "VALID",
            "rationale": "Underlying HIV documented.",
            "chart_evidence": "HIV disease",
            "coding_rule": "Section I.C.1.a.1",
            "sequencing_position": "secondary"
        }
    ]

    tabular_cf = {
        "B59": {
            "disease_name": "Pneumocystosis",
            "CODE_FIRST": [{"target": "B20", "target_type": "DiseaseCode"}]
        },
        "B20": {
            "disease_name": "Human immunodeficiency virus [HIV] disease"
        }
    }

    result_cf = reconcile_claim_rules(clinical_cf, tabular_cf, {})
    seq = [v["code"] for v in result_cf["validated_sequence"]]
    assert seq == ["B20", "B59"], f"Expected B20 (principal) then B59 (secondary), got {seq}"
    print("[PASS] 3. CODE_FIRST Sequencing (B20 sequenced before manifestation B59)")

    print("\n[PASS] Layer 4 (Tabular Rule Engine) successfully verified!")

if __name__ == "__main__":
    test_rule_engine_layer()
