import os
import sys
from dotenv import load_dotenv

# Add the parent directory (root) to the Python path so we can import from backend
sys.path.append(os.path.dirname(os.path.dirname(__file__)))
sys.path.append(os.path.join(os.path.dirname(os.path.dirname(__file__)), 'backend'))

# Load environment variables from the root .env file
load_dotenv(os.path.join(os.path.dirname(os.path.dirname(__file__)), '.env'))

# Import the orchestrator and summary printer from the backend module
from backend.orchestrator import run_claim_validation
from tests.test_runner import print_summary, write_audit_report

def main():
    # =====================================================================
    # 1. PUT YOUR CLAIMED CODES HERE
    # =====================================================================
    claimed_codes = [
        "B20",
        "Z21",
        "J96.01"
    ]
    
    # =====================================================================
    # 2. PASTE YOUR CLINICAL CHART TEXT (OR JSON) HERE
    # =====================================================================
    clinical_text = """
    ST MARYS REGIONAL MEDICAL CENTER

INPATIENT 
------------------------------------------------------------

CHIEF COMPLAINT

fever x10 days worsening shortness of breath dry cough
generalized weakness wt loss approx 15 lbs over last 2 mos

------------------------------------------------------------

HISTORY OF PRESENT ILLNESS

42 year old male known HIV positive for several years
reports stopped taking HIV medications several months ago
because unable to obtain refills

complains progressive fatigue increasing dyspnea on exertion
persistent dry cough chills night sweats

denies chest pain

poor appetite

reports occasional diarrhea

no recent travel

no known tuberculosis exposure

------------------------------------------------------------

PAST MEDICAL HISTORY

HIV infection

history medication non compliance

oral candidiasis approx 2 years ago

------------------------------------------------------------

PAST SURGICAL HISTORY

none reported

------------------------------------------------------------

SOCIAL HISTORY

lives alone

former smoker

drinks alcohol occasionally

denies IV drug use

------------------------------------------------------------

HOME MEDICATIONS

patient unable recall ART regimen

states has not taken medications for many months

------------------------------------------------------------

ALLERGIES

NKDA

------------------------------------------------------------

REVIEW OF SYSTEMS

constitutional

positive fever
positive chills
positive fatigue
positive weight loss

respiratory

positive cough
positive shortness breath

cardiovascular

negative chest pain
negative palpitations

GI

poor appetite
intermittent diarrhea

neurological

denies focal weakness
denies seizure

------------------------------------------------------------

PHYSICAL EXAM

temperature 102.1 F

pulse 118

blood pressure 102/64

respiratory rate 30

oxygen saturation 88 percent room air

general

appears chronically ill cachectic

HEENT

oral thrush noted

neck supple

lungs

diffuse bilateral crackles

no wheezing

heart

tachycardic regular rhythm

abdomen

soft nontender

extremities

no edema

------------------------------------------------------------

INITIAL ASSESSMENT

acute hypoxic respiratory failure

suspected opportunistic pulmonary infection

known HIV infection

infectious disease consultation requested

patient admitted to internal medicine

============================================================

PAGE 2

EMERGENCY DEPARTMENT PHYSICIAN NOTE

patient remains hypoxic despite nasal cannula

placed on high flow oxygen

CT CHEST ORDERED

Differential Diagnosis

Pneumocystis jirovecii pneumonia

community acquired pneumonia

fungal pneumonia

pulmonary tuberculosis

------------------------------------------------------------

LAB RESULTS

CBC

WBC 3.2

Hemoglobin 10.2

Platelets 152

CMP

Sodium 132

Potassium 4.0

Creatinine 1.0

AST 55

ALT 48

LDH markedly elevated

ABG

PaO2 decreased

------------------------------------------------------------

RADIOLOGY REPORT

CT CHEST

Diffuse bilateral ground glass opacities

Findings highly suspicious for Pneumocystis jirovecii
pneumonia

------------------------------------------------------------

MEDICATIONS STARTED

TMP SMX IV

Prednisone

Supplemental Oxygen

============================================================

PAGE 3

INFECTIOUS DISEASE CONSULT

Elizabeth Green MD

history reviewed

known HIV disease

patient discontinued antiretroviral therapy approximately
8 to 10 months ago

bronchoscopy completed

BAL specimen positive for Pneumocystis jirovecii by PCR

CD4 COUNT

86 cells mm3

HIV VIRAL LOAD

greater than 750000 copies per mL

------------------------------------------------------------

ASSESSMENT

Advanced HIV disease

Pneumocystis jirovecii pneumonia confirmed

continue TMP SMX

restart ART after stabilization

patient educated importance medication compliance

============================================================

PAGE 4

PROGRESS NOTE

Hospital Day 3

patient breathing improved

oxygen requirement reduced

afebrile overnight

repeat assessment

advanced HIV disease with confirmed
Pneumocystis jirovecii pneumonia

continue antibiotics

continue corticosteroids

blood cultures negative

no evidence bacterial sepsis

no evidence meningitis

no evidence active tuberculosis

============================================================

PAGE 5

DISCHARGE SUMMARY

hospital course

patient admitted with severe hypoxemia secondary to
Pneumocystis jirovecii pneumonia in setting of advanced
HIV disease

clinical improvement after IV TMP SMX and corticosteroids

infectious disease follow up arranged

------------------------------------------------------------

FINAL DIAGNOSES

HIV disease

Pneumocystis jirovecii pneumonia

Acute hypoxemic respiratory failure

------------------------------------------------------------

DISCHARGE MEDICATIONS

TMP SMX

Prednisone taper

Antiretroviral therapy

------------------------------------------------------------

Electronically signed

Robert Wilson MD

07/23/2026
    """
    
    print("="*60)
    print("STARTING TEST CASE 2 PIPELINE RUN")
    print("="*60)
    
    # 3. Run the pipeline
    final_state = run_claim_validation(clinical_text, claimed_codes)
    
    # 4. Save and print results
    write_audit_report(2, "Test_Case_2", final_state)
    print_summary(final_state)
    
if __name__ == "__main__":
    main()
