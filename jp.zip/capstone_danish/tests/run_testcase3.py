import os
import sys
from dotenv import load_dotenv

# Add the parent directory (root) to the Python path so we can import from backend
sys.path.append(os.path.dirname(os.path.dirname(__file__)))
sys.path.append(os.path.join(os.path.dirname(os.path.dirname(__file__)), 'backend'))

# Load environment variables from the root .env file
load_dotenv(os.path.join(os.path.dirname(os.path.dirname(__file__)), '.env'))

# Import the orchestrator and summary printer from the backend module
from backend.orchestrator import run_claim_validation
from tests.test_runner import print_summary, write_audit_report

def main():
    # =====================================================================
    # 1. PUT YOUR CLAIMED CODES HERE
    # =====================================================================
    claimed_codes = [
    "A41.9",
    "B95.62",
    "N17.9"
    ]
    
    # =====================================================================
    # 2. PASTE YOUR CLINICAL CHART TEXT (OR JSON) HERE
    # =====================================================================
    clinical_text = """
    GREEN VALLEY MEDICAL CENTER

INPATIENT MEDICAL RECORD

MRN 8842103
PATIENT MICHAEL HARRIS
DOB 03/22/1961

============================================================

CHIEF COMPLAINT

fever confusion generalized weakness for 2 days

============================================================

HISTORY OF PRESENT ILLNESS

65 year old male brought by family because of worsening
confusion fever and chills.

Patient reports painful redness over the left lower leg
for approximately one week.

Family states patient became progressively lethargic over
last 24 hours.

No recent travel.

============================================================

PAST MEDICAL HISTORY

Type 2 diabetes mellitus

Hypertension

Peripheral vascular disease

============================================================

PHYSICAL EXAM

Temperature 103.4 F

Heart Rate 128

Blood Pressure 86/54

Respiratory Rate 28

Oxygen Saturation 95 percent

General

Appears toxic

Skin

Large erythematous cellulitis over left calf

Purulent drainage noted

============================================================

LABORATORY

WBC 22.8

Lactic Acid 5.9

Creatinine 1.8

Blood cultures collected

============================================================

INITIAL ASSESSMENT

Sepsis secondary to left leg cellulitis

Broad spectrum antibiotics initiated

============================================================

PAGE 2

MICROBIOLOGY

Blood cultures

Methicillin resistant Staphylococcus aureus isolated

MRSA confirmed

Wound culture

MRSA isolated

============================================================

INFECTIOUS DISEASE CONSULT

Assessment

MRSA bacteremia

Sepsis due to MRSA

Left lower extremity cellulitis

Continue IV Vancomycin

============================================================

PAGE 3

HOSPITAL COURSE

Clinical improvement after IV antibiotics

Repeat blood cultures negative

============================================================

DISCHARGE SUMMARY

FINAL DIAGNOSES

Sepsis due to MRSA

MRSA bacteremia

Left leg cellulitis

Acute kidney injury likely secondary to sepsis

Discharged home with infectious disease follow up.
    """
    
    print("="*60)
    print("STARTING TEST CASE 3 PIPELINE RUN")
    print("="*60)
    
    # 3. Run the pipeline
    final_state = run_claim_validation(clinical_text, claimed_codes)
    
    # 4. Save and print results
    write_audit_report(3, "Test_Case_3", final_state)
    print_summary(final_state)
    
if __name__ == "__main__":
    main()
