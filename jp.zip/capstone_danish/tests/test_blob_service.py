"""
Dummy test for blob_service.py.
Tests LOCAL FILESYSTEM mode (no Azure credentials needed).
When AZURE_STORAGE_CONNECTION_STRING is set in .env, it will auto-switch to Azure mode.

Run from the project root:
    python -m tests.test_blob_service
"""
import os
import sys
import tempfile

# Add the project root to path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from api.blob_service import is_azure_mode, upload_pdf, get_pdf_url

def test_blob_service():
    print("=" * 60)
    print("  Blob Service Dummy Test")
    print("=" * 60)

    # ---------------------------------------------------------------
    # Step 1: Report which mode we are in
    # ---------------------------------------------------------------
    mode = "AZURE" if is_azure_mode() else "LOCAL FILESYSTEM"
    print(f"\n[Mode] Running in: {mode}")

    # ---------------------------------------------------------------
    # Step 2: Create a dummy PDF (just a few bytes for testing)
    # ---------------------------------------------------------------
    dummy_pdf_bytes = b"%PDF-1.4 dummy test content for blob_service test"
    job_id = "test-job-00000000"
    filename = "chart.pdf"

    with tempfile.TemporaryDirectory() as tmpdir:
        print(f"[Upload] Uploading dummy PDF for job_id: {job_id}")

        try:
            result_path = upload_pdf(
                file_bytes=dummy_pdf_bytes,
                job_id=job_id,
                filename=filename,
                local_dir=tmpdir
            )
            print(f"[Upload] SUCCESS -> {result_path}")
        except Exception as e:
            print(f"[Upload] FAILED -> {e}")
            return

        # ---------------------------------------------------------------
        # Step 3: Get the URL/path for frontend access
        # ---------------------------------------------------------------
        print(f"\n[URL] Generating access URL for frontend...")
        try:
            url = get_pdf_url(
                job_id=job_id,
                filename=filename,
                local_path=result_path,
                expiry_hours=1
            )
            print(f"[URL] SUCCESS -> {url}")
        except Exception as e:
            print(f"[URL] FAILED -> {e}")
            return

    print("\n" + "=" * 60)
    print("  All checks passed! Blob Service is working correctly.")
    print("=" * 60)


if __name__ == "__main__":
    test_blob_service()
