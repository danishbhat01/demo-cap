"""
Layer 1 Test: Extractor Agent
Tests clinical entity extraction from unstructured medical chart notes.
"""
import os
import sys
import json

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '../backend')))
from extractor_agent import run_extractor

def test_extractor_layer():
    print("=" * 60)
    print("  LAYER 1 TEST: EXTRACTOR AGENT")
    print("=" * 60)

    sample_chart = """
    DISCHARGE SUMMARY
    Patient was admitted with severe sepsis secondary to MRSA bacteremia.
    Blood cultures confirmed Methicillin-resistant Staphylococcus aureus.
    Past Medical History: Type 2 diabetes mellitus, Hypertension.
    Assessment: Sepsis due to MRSA, resolved.
    """

    print("\n[Input] Sample Clinical Chart:")
    print(sample_chart.strip())
    
    print("\n[Running] Extractor Agent...")
    evidence_db = run_extractor(sample_chart)

    print("\n[Output] Extracted Evidence DB:")
    print(json.dumps(evidence_db, indent=2))

    assert "diagnoses" in evidence_db, "evidence_db must contain 'diagnoses'"
    assert len(evidence_db["diagnoses"]) > 0, "Should extract at least one diagnosis"
    
    diag_names = [d["name"].lower() for d in evidence_db["diagnoses"]]
    print(f"\nExtracted Diagnoses: {diag_names}")
    
    has_sepsis = any("sepsis" in d for d in diag_names)
    assert has_sepsis, "Extractor should identify sepsis"

    print("\n[PASS] Layer 1 (Extractor Agent) successfully verified!")

if __name__ == "__main__":
    test_extractor_layer()
