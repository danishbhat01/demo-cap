# Architecture Q&A Guide
### AI Medical Coder & Claim Validation Pipeline
*Plain-language answers to common questions about this architecture*

---

## Section 1: Why These Tools?

---

**Q: Why use MAF SDK when Azure already provides its own orchestrator?**

Azure has orchestration tools, but they are built for a different kind of problem. Azure's tools work well when you have a fixed, predictable flow â€” Step 1 happens, then Step 2, then done. 

Our pipeline is different. We have a queue of medical codes, and we process them one at a time. For each code, the steps change based on what Neo4j returns and what the doctor's chart says. Some codes need extra companion codes added to the queue dynamically. This kind of "pop one item, process it, decide what happens next, loop back" behavior requires a proper cyclic state machine.

The Microsoft Agent Framework (MAF) SDK is purpose-built for exactly this. Azure's Prompt Flow, for example, is a Directed Acyclic Graph â€” it does not support going backwards or looping without hacky workarounds. And Azure Prompt Flow is actually being retired in 2027, making it a poor foundation for new architecture.

More importantly: if the AI is the orchestrator, you lose control over the exact sequence of steps. In a medical compliance context, that is unacceptable. With MAF SDK (written in Python), the code controls when the AI is called, what it sees, and what happens with its response â€” not the AI itself.

---

**Q: Microsoft has a new Azure Agentic Framework (and Semantic Kernel). Since they do similar things, why pick MAF SDK over them?**

While Microsoft's Agentic Frameworks are powerful, they are primarily optimized for "Conversational Agents" (agents talking to each other) and giving the LLM autonomy to decide what to do next. 

In healthcare billing, giving an LLM autonomy to decide the workflow is a compliance risk. We don't want the AI to decide *when* to check the rules. We want absolute, rigid control: **Fetch Rules â†’ Validate Code â†’ Re-Queue if needed.** 

MAF SDK is designed around explicit graph edges and state management. The graph (the Python code) determines the routing, not the AI. MAF SDK handles the complex state (our Evidence DB and our growing/shrinking queue of codes) seamlessly as a first-class feature across loops, whereas building that deterministic, graph-based control loop in Azure Agent Service (the conversational agent product) requires significantly more custom boilerplate code.

---

**Q: Why not use Azure Durable Functions for the orchestration?**

Azure Durable Functions is great for orchestrating traditional software tasks (like "charge a credit card, wait 3 days, send an email"). However, orchestrating an AI agent is a very different job.

When MAF SDK loops, it automatically manages the AI's "memory" (the chat history) and handles the specific data formats that AI models need to reason properly. It also natively understands how to let the AI use tools (like searching the vector database) and feed the answers back into the loop. 

If we used Durable Functions, we would have to write a massive amount of custom, complex code just to handle basic AI memory and tool-calling. MAF SDK is built specifically for AI agent workflows, making the development much faster and cleaner.

---

**Q: But you have to Dockerize the MAF SDK application. Isn't that extra work?**

Yes, but that extra work buys you something important: your core pipeline logic becomes cloud-agnostic. Azure handles the AI and OCR services, but the actual validation logic lives in a Docker container deployed on Azure Container Apps â€” which auto-scales with claim volume and can be moved to any cloud provider without rewriting the pipeline. It also keeps the intellectual property of the pipeline (the validation logic) separate from Azure's proprietary tools.

---

**Q: Why use Neo4j instead of a regular database?**

The ICD-10-CM coding rules are not just a flat list of records. They are a web of relationships. A disease code can exclude another code, require a companion code, demand a specific sequencing order, and have parent-child code hierarchies â€” all at once. 

A regular SQL table forces you to write complex multi-table JOIN queries to reconstruct these relationships. A graph database like Neo4j stores relationships as first-class citizens, so asking "what are all the rules connected to this code?" is a single, clean traversal instead of a complicated query.

---

**Q: Why use Azure Document Intelligence for OCR instead of something simpler?**

Medical charts contain a mix of typed text, handwritten notes, scanned images, lab result tables, and physician shorthand. A basic OCR tool handles clean typed documents well but fails badly on the complex, mixed-format documents common in healthcare. Azure Document Intelligence is specifically trained on document layouts and table structures, giving much higher extraction accuracy â€” which is critical because any information missed at this stage becomes a permanent blind spot for the entire validation pipeline.

---

## Section 2: How the Guidelines Work

---

**Q: Why are the general guidelines stored in the System Prompt instead of the database?**

Think of the System Prompt as the AI's permanent memory â€” things it always knows before any conversation even begins. The general ICD-10-CM guidelines (Sections I.A, I.B, II, III, and IV) cover universal rules that apply to every single medical claim regardless of diagnosis. Things like "always code to the highest level of specificity" or "for inpatient claims, sequence the principal diagnosis first."

Since these rules never change between claims, putting them in the database and querying them every time would be wasteful. Loading them into the System Prompt once means the AI always has them in context without any retrieval step.

---

**Q: Doesn't putting 20,000 tokens in the System Prompt make every call very expensive?**

It would be expensive if we were passing the full text in every API request body. But Azure AI Foundry Agents work differently â€” you define a persistent agent with its own ID. The system prompt is stored server-side on Azure. When your MAF SDK code calls the agent, it just says "use Agent ID X" â€” Azure handles attaching the cached system prompt internally. This is called prompt caching, and it means the provider does not recompute the cost of those 20,000 tokens on every call.

---

**Q: Why are the chapter-specific guidelines stored in a Vector Database (RAG) instead of Neo4j?**

The original plan actually did propose storing them in Neo4j as structured nodes. That plan was abandoned for a good reason: guidelines are written in prose â€” paragraphs of medical reasoning. Prose is not structured data. You cannot usefully query prose with a graph relationship.

The smarter approach is to store guidelines as text chunks in a Vector Database and let the AI search for the relevant chunk using semantic similarity. The AI understands that "HIV disease" and "HIV infections" mean the same thing, so it finds the right guideline even when the exact words don't match. A graph database cannot do this â€” it only matches what you tell it to match explicitly.

---

**Q: What is "semantic chunking" and why does it matter?**

When you split a 120-page PDF into chunks, the naive approach is to cut it every 500 words. The problem is that a 6-paragraph guideline about Sepsis might get sliced in half â€” one chunk has the first 3 paragraphs, another has the last 3. When the AI searches for the Sepsis guideline, it might only retrieve the first half and miss a critical rule in the second half.

Semantic chunking uses GPT-4o to read the PDF and split it by meaning â€” specifically by disease entity. The entire Sepsis guideline stays in one chunk. The entire HIV guideline stays in one chunk. When the AI queries for "Sepsis," it gets the complete, coherent set of rules for Sepsis â€” nothing split, nothing missing.

---

## Section 3: How the Validation Works

---

**Q: Walk me through what happens when a doctor submits codes B20 and A41.9.**

Step 1 — The medical chart is uploaded. Azure Document Intelligence reads the scan and extracts raw text. An LLM then converts that raw text into a clean, structured JSON object: the "Evidence Database." This is the ground truth about what is actually documented in the chart.

Step 2 — The MAF SDK orchestrator takes control. It places the two codes (B20 and A41.9) into a queue and begins processing them one at a time.

Step 3 — For the first code (say A41.9, Sepsis), MAF SDK queries Neo4j. Neo4j returns the hard tabular rules: in this case, a "USE_ADDITIONAL_CODE" rule requiring an organism code to be present. It also returns the exact disease name: "Sepsis, unspecified."

Step 4 — MAF SDK assembles a payload: the Evidence Database + the Neo4j rules + the disease name. It sends this to the Azure AI Foundry Validation Agent.

Step 5 — The Agent already knows the universal guidelines from its System Prompt. It uses the disease name "Sepsis" to search the Vector Database and retrieves the specific chapter guidelines for Sepsis. Now it has all three layers of information: universal rules, code-specific guidelines, and tabular rules.

Step 6 — The Agent cross-references everything against the Evidence Database. Is the organism code present? Is severe sepsis documented? Is this an inpatient claim? It makes a decision for each rule and outputs a verdict with a detailed justification.

Step 7 — MAF SDK loops back and repeats for B20 (HIV). The loop ends when the queue is empty.

---

**Q: Not every Neo4j rule will apply to every code. How does the system know which rules matter?**

The tabular rules in Neo4j are not enforced blindly. They are just retrieved and handed to the AI as context. The Agent's job is to read both the rule and the Evidence Database and decide: does this rule actually apply given what is documented in this patient's chart?

For example, an EXCLUDES1 rule between two codes only matters if both codes are present in the same claim. The Agent checks — if only one is present, the rule is irrelevant and ignored. The validation is always conditional on the actual clinical evidence, not on the abstract existence of a rule.

---

**Q: What is the "Tri-Layer Brain" described in the architecture?**

It is a conceptual name for the three distinct sources of knowledge the Validation Agent draws on simultaneously.

Layer 1 is the System Prompt — universal coding rules that the Agent always knows, regardless of the claim being processed.

Layer 2 is the Vector Knowledge Base — disease-specific guidelines retrieved on demand using the disease name from Neo4j as the search query.

Layer 3 is the Neo4j Tabular Data — hard structural rules (exclusions, sequencing, companion codes) retrieved by MAF SDK before the Agent is even called.

These three layers together allow the Agent to reason about a code with full context: universal rules, disease-specific narrative guidelines, and hard structural constraints all at once. No single layer is sufficient on its own.

---

## Section 4: Costs & Scalability

---

**Q: What does the "token budget" mean in the context of AI calls?**

Every time you call an AI model, you send it text (your question, the patient evidence, the guidelines) and it sends text back (its answer). Providers charge you based on the volume of text, measured in tokens (roughly 4 characters = 1 token). A "token budget" is a soft limit on how long your AI responses should be â€” it helps control costs and encourages the AI to be concise rather than verbose.

---

**Q: How does this architecture scale if the hospital processes thousands of claims per day?**

The stateless design of the pipeline makes it naturally scalable. The MAF SDK application runs inside a Docker container deployed on Azure Container Apps. Azure Container Apps auto-scales horizontally â€” if 1,000 claims arrive simultaneously, Azure spins up additional container instances automatically and distributes the load. Each instance runs independently, so there is no bottleneck. Once claim volume drops, extra instances are shut down and you stop paying for them.

---

**Q: What is the current scope of the Neo4j database, and why is it limited?**

The Neo4j graph is currently populated with Chapter 1 of ICD-10-CM only â€” codes A00 through B99, covering infectious and parasitic diseases. This is a deliberate pilot scope. The full ICD-10-CM classification has 22 chapters and tens of thousands of codes. Building the complete graph in one go is not practical for a capstone proof-of-concept. Chapter 1 was chosen because it is well-documented, has clear coding guidelines, and the HIV/Sepsis example (B20, A41.9) falls within it â€” making it an ideal, demonstrable slice of the full system.

---

## Section 5: Architect-Level Drill-Down

---

**Q: How do you prevent the AI from "hallucinating" clinical facts that aren't actually in the patient's chart?**

Hallucination is the biggest risk in medical AI. We handle this by separating the extraction from the validation. 

Before validation even begins, a separate AI agent reads the OCR text and creates the "Evidence Database" (a rigid JSON file enforced by Pydantic). This agent's prompt strictly forbids medical reasoning â€” its only job is to extract exact quotes and values. The Validation Agent later trusts this JSON as absolute ground truth. If the Validation Agent can't find proof for a code inside that JSON, it drops the code. It is not allowed to guess or assume based on its training data.

---

**Q: If the MAF SDK loop can dynamically add new codes to the queue, how do you prevent an infinite loop?**

Infinite loops happen when an agent keeps adding the same requirement over and over. We solve this entirely in the MAF SDK code (the deterministic layer). 

MAF SDK maintains a "processed codes" list in its state. Before a new code is pushed to the queue (for example, an organism code requested by a `USE_ADDITIONAL_CODE` rule), MAF SDK checks if that code has already been evaluated. If it has, it refuses to add it again. We also implement a hard `MaximumIterations` cap (e.g., 20 loops maximum per claim) to act as a failsafe circuit breaker.

---

**Q: Healthcare is highly regulated. How can an auditor verify why the AI made a decision?**

"Black box" AI is unacceptable in healthcare billing. That's why the final output of this pipeline isn't just a list of codes. It is a structured table that forces the AI to "show its work." 

For every code, the AI must output the exact clinical evidence it relied on from the chart (e.g., "Patient admitted with severe sepsis"), and it must cite the exact guideline or Neo4j rule it used (e.g., "ICD-10-CM Section I.C.1.d.1.a"). If an auditor questions a claim, they have a deterministic paper trail showing exactly what rule was applied and why.

---

**Q: Are you sending Protected Health Information (PHI) to a public AI model?**

No. We are using **Azure OpenAI Service**, not the public ChatGPT API. Azure OpenAI is HIPAA-eligible and enterprise-secured. Microsoft guarantees that the data sent to the Azure OpenAI API remains within your private Azure tenant and is never used to train OpenAI's base models. This satisfies the strict data privacy requirements of hospital IT departments.

---

**Q: Where are all the API keys and secrets stored when deployed?**

In Azure production, we use **Azure Key Vault** paired with **Managed Identity**. The codebase never hardcodes a secret, and there are no keys in the cloud environment variables. The Docker container simply requests a token from Azure Active Directory, which unlocks the Key Vault. The Python backend then securely pulls the Blob Storage keys and OpenAI endpoints directly into memory at runtime.

---

**Q: How does the system handle a situation where a doctor under-codes, but also uses a generic code (e.g. A41.9 instead of A41.02)?**

This is solved by separating concerns between Node 1 (Under-coding Engine) and Node 3 (Specificity Engine).
The Under-coding Engine strictly checks for *entirely missing* 3-character families. If the chart says "MRSA Sepsis" but only `A41.9` is claimed, the Under-coding Engine sees that the `A41` family is already present and ignores it.
Instead, Node 3 (Specificity Engine) fetches the specific codes for the `A41` family, reads the chart, and executes an **intra-family upgrade**, swapping `A41.9` to `A41.02`. This prevents the two engines from accidentally generating duplicate or conflicting recommendations.

---

## Section 6: Cost Analysis & ROI

---

**Q: What is the processing cost per ICD Code?**

The cost to process a single ICD code through the validation loop is approximately **$0.035 to $0.05**.
Here is the breakdown:
*   **System Prompt Caching:** The 20,000-token guideline system prompt is cached by Azure, slashing the input cost by ~50%.
*   **MAF SDK Payload:** Sending the JSON Evidence DB and Neo4j rules uses roughly 2,000 tokens.
*   **Output Reasoning:** The structured justification table output is usually under 500 tokens.
*   Using current standard GPT-4o enterprise pricing, this specific validation loop costs pennies per code.

**Q: What is the total cost to validate a full patient claim?**

The cost for a complete claim is roughly **$0.25 to $0.35 per claim**.
This includes the upfront extraction steps:
1.  **Azure Document Intelligence (OCR):** ~$0.05 (assuming a 5-page medical chart).
2.  **Evidence Extraction (LLM to JSON):** ~$0.02 (processing the raw text into Pydantic JSON).
3.  **Code Validation:** ~$0.20 (assuming an average of 4-5 ICD codes claimed on the chart, at ~$0.04 each).

**Q: What is the overall ROI and cost benefit to the client/hospital?**

The return on investment (ROI) is massive when compared to manual coding validation.
*   **Human Cost:** A certified inpatient medical coder costs approximately $30â€“$40 per hour. Reviewing a complex multi-code inpatient claim manually takes about 10â€“15 minutes, equating to a labor cost of **$5.00 to $10.00 per claim**.
*   **AI Cost:** At **$0.30 per claim**, the AI pipeline is over **15x to 30x cheaper** than human labor.
*   **Speed & Revenue Cycle:** A human takes 15 minutes; the AI pipeline executes the MAF SDK loop in under 10 seconds. This drastically reduces "Discharged Not Final Billed" (DNFB) days, accelerating the hospital's revenue cycle and catching costly coding omissions (like missing organism codes) before the claim is ever sent to the insurance payer.

