# FINAL ARCHITECTURE SPECIFICATION
## Multi-Agent AI Medical Coding & Claim Validation System
### Complete Layer-by-Layer Architectural Blueprint, Data Flow Diagrams & Presentation Reference

---

## 1. Executive Summary & Architecture Overview

The **Multi-Agent Medical Claim Validation System** is an enterprise-grade, deterministic AI pipeline designed to ingest unstructured clinical records and medical billing claims, validate ICD-10-CM diagnostic codes against official regulatory guidelines, detect under-coding opportunities, resolve complex coding constraints (`EXCLUDES1`, `CODE_FIRST`, `USE_ADDITIONAL_CODE`), and produce tamper-evident, audit-ready compliance reports.

### Core Architectural Pillars
1. **Tri-Layer Knowledge Brain**: Integrates (1) static Universal Guidelines, operational coding rules, and citation mandates in system prompts, (2) dynamic Chapter-Specific narrative guidelines in Vector RAG (ChromaDB / Azure Cosmos DB Vector Search), and (3) rigid tabular coding rules in a Neo4j Knowledge Graph.
2. **Zero-Inference Clinical Extraction**: Uses strict Pydantic schemas with mandatory verbatim `source_quote` field groundings, preventing LLMs from fabricating clinical evidence.
3. **Multi-Agent Orchestration**: Implements a Microsoft Agent Framework (MAF) state machine with isolated agents for Extraction, Graph Discovery, Validation, and Tabular Rule Enforcement.
4. **Deterministic Tabular Rule Engine**: Enforces mathematical and relational ICD-10 logic deterministically in code—never relying on LLM guesswork for legal exclusions or sequencing.
5. **Multi-Pass Runtime Anti-Fabrication Guardrails**: Intercepts LLM outputs to enforce exact numeric grounding, fuzzy text validation, and guideline verification before saving audit artifacts.

---

## 2. High-Level Architecture Diagram

```mermaid
flowchart TD
    subgraph INGESTION ["0. Ingestion Layer"]
        DOC["Patient Medical Chart<br>(PDF / Scanned Note)"] --> OCR["Azure AI Document Intelligence<br>(High-Fidelity OCR)"]
        OCR --> RAW_TEXT["Unstructured Clinical Text"]
        CLAIM_CODES["Billed Claim Codes<br>(e.g., A41.9, B20)"]
    end

    subgraph LAYER1 ["Layer 1: Ground Truth Extraction"]
        RAW_TEXT --> EXTRACTOR["Node 0: Extractor Agent<br>(LLM + Pydantic Schema)"]
        EXTRACTOR --> EDB["JSON Evidence Database<br>(Diagnoses, Organisms, Vitals, Source Quotes)"]
    end

    subgraph LAYER2 ["Layer 2: Under-Coding & Graph Discovery"]
        EDB & CLAIM_CODES --> UNDERCODE["Node 1: Under-Coding Check<br>(Cypher Lexical Token Matcher)"]
        UNDERCODE <--> N4J_DISC[("Neo4j Knowledge Graph<br>(Chapter 1: A00-B99)")]
        UNDERCODE --> QUEUE["Node 2: Queue Router<br>(Priority Code Queue)"]
    end

    subgraph LAYER3 ["Layer 3: Tri-Layer Knowledge Assembly"]
        QUEUE --> NODE3["Node 3: Data Agent<br>(Neo4j & Vector Lookups)"]
        NODE3 --> NODE4["Node 4: Payload Assembler"]
        
        subgraph BRAIN ["The Tri-Layer Brain"]
            PROMPT_CACHE[("Layer 3A: System Prompt Injection<br>Universal Rules I.A - IV &amp; Citations")]
            VDB_RAG[("Layer 3B: Vector Knowledge Base<br>Narrative Guidelines Sec I.C (Cosmos DB Vector)")]
            N4J_TABULAR[("Layer 3C: Tabular Graph<br>EXCLUDES1, CODE_FIRST, UAC (Neo4j)")]
        end

        NODE4 <--> PROMPT_CACHE
        NODE4 <--> VDB_RAG
        NODE4 <--> N4J_TABULAR
        NODE4 --> VALIDATOR_PAYLOAD["Hydrated Validation Context Payload"]
    end

    subgraph LAYER4 ["Layer 4: Clinical Validation & Guardrails"]
        VALIDATOR_PAYLOAD --> FASTPATH{"FastPath Alignment<br>Exact Substring Match?"}
        FASTPATH -->|Yes| FAST_VERDICT["Direct Match Verdict"]
        FASTPATH -->|No / Ambiguous| VAL_AGENT["Node 5: Validator Agent<br>(Clinical LLM Judge)"]
        VAL_AGENT --> GUARDRAILS{"3-Pass Runtime Guardrails<br>(Numeric + Text + Guideline Grounding)"}
        GUARDRAILS -->|Pass| VERDICT["Validation Decision<br>(VALID / INVALID / SWAP / ADD_COMPANION)"]
        GUARDRAILS -->|Fail / Hallucination| RETRY["Self-Correction Loop<br>(Max 1 Retry -> Manual Review)"]
        RETRY --> VERDICT
        FAST_VERDICT --> VERDICT
        VERDICT --> DECISION_ROUTER["Node 6: Decision Router"]
        DECISION_ROUTER -->|Enqueue Swap/Companion| QUEUE
    end

    subgraph LAYER5 ["Layer 5: Deterministic Tabular Rule Engine"]
        DECISION_ROUTER -->|Queue Empty| RULE_ENGINE["Node 7: Rule Engine<br>(reconcile_claim_rules)"]
        RULE_ENGINE --> RECON_E1["1. EXCLUDES1 Mutual Exclusion Pass"]
        RECON_E1 --> RECON_CF["2. CODE_FIRST Dependency & Sequencing Pass"]
        RECON_CF --> RECON_UAC["3. USE_ADDITIONAL_CODE Mandatory Companion Pass"]
        RECON_UAC --> RECON_ADV["4. Advisory Compilation (EXCLUDES2 / CODE_ALSO)"]
    end

    subgraph LAYER6 ["Layer 6: Insights & Compliance Artifacts"]
        RECON_ADV --> COMPILE["Final Audit Compiler"]
        COMPILE --> AUDIT_JSON["insights/audit_reports/<br>Timestamped JSON Audit Report"]
        COMPILE --> TELEMETRY_LOG["insights/telemetry_logs.jsonl<br>Runtime Observability & Guardrail Logs"]
        COMPILE --> UI_REPORT["Validated Claim Sequence & Table<br>(Principal + Secondary Codes)"]
    end

    style INGESTION fill:#f8f9fa,stroke:#6c757d,stroke-width:2px;
    style LAYER1 fill:#e3f2fd,stroke:#1976d2,stroke-width:2px;
    style LAYER2 fill:#ede7f6,stroke:#512da8,stroke-width:2px;
    style LAYER3 fill:#e8f5e9,stroke:#388e3c,stroke-width:2px;
    style LAYER4 fill:#fff3e0,stroke:#f57c00,stroke-width:2px;
    style LAYER5 fill:#fce4ec,stroke:#c2185b,stroke-width:2px;
    style LAYER6 fill:#e0f2f1,stroke:#00796b,stroke-width:2px;
```

---

## 3. Detailed Layer-by-Layer Breakdown

### Layer 0: Knowledge Asset Ingestion & Setup (Offline)
Before real-time claims are processed, two foundational knowledge bases are indexed. *(For detailed ETL parsing algorithms, regex chunking patterns, and raw payloads, see [DATA_ARCHITECTURE.md](file:///c:/Users/danis/Desktop/capstone/capstone_danish/DATA_ARCHITECTURE.md).)*

1. **Tabular Knowledge Graph (Neo4j)**:
   * **Scope**: Stays in **Neo4j** across all local development and Azure production environments (Neo4j AuraDB / Azure Neo4j VM).
   * **Contents**: Disease codes, descriptions, billable flags, synonyms, organism hints, and deterministic rule relationships (`EXCLUDES1`, `EXCLUDES2`, `CODE_FIRST`, `CODE_ALSO`, `USE_ADDITIONAL_CODE`).
2. **Guideline Vector Database (ChromaDB / Azure Cosmos DB Vector Search)**:
   * **Scope**: Local `chromadb` index migrates to **Azure Cosmos DB Vector Search** in production.
   * **Contents**: Chapter-specific narrative coding guidelines (Section I.C) chunked by disease entity headers.

---

### Layer 1: Ground Truth Clinical Extraction Engine
* **Purpose**: Transforms noisy, unstructured physician notes and discharge summaries into a rigid, typed JSON object representing absolute clinical ground truth.
* **Component**: `backend/extractor_agent.py` driven by `prompts/extractor_agent_prompt.md`.
* **Technology**: LLM + strict Pydantic JSON Schema enforcement.

#### Medicolegal Extraction Rules (System Prompt):
1. **Zero-Hallucination Constraint**: Extractor must only record clinician-named conditions. Lab values, vitals, or medication patterns must never be converted into independent diagnoses.
2. **Mandatory Verbatim `source_quote`**: Every diagnosis requires an exact sentence from the chart. Quotes from "Final Diagnosis" or "Discharge Summary" sections take priority over HPI notes.
3. **Strict Status Enum**: `status` must strictly equal `Active | History of | Suspected | Ruled out`.
4. **Organism & Dysfunction Mapping**: Causative pathogens (e.g. MRSA, Klebsiella) are linked directly inside the diagnosis object. Organ failures (e.g. Acute Kidney Injury) are extracted to the `organ_dysfunction` array.

---

### Layer 2: Proactive Under-Coding Detection & Graph Discovery
* **Purpose**: Identifies documented clinical conditions in the chart that the provider forgot to bill on the claim form.
* **Component**: `data_agent.under_coding_neo4j_lookup()` in `backend/data_agent.py`.
* **Discovery Mechanism**:
  1. Compares all confirmed `diagnoses` and `organism` entries in `evidence_db` against `raw_claimed_codes`.
  2. For unbilled conditions, extracts clinical tokens and queries Neo4j `DiseaseCode` nodes using Cypher text scoring.
  3. **Loop Guard & Family Masking**: Applies a strict 3-character family masking block against currently claimed codes. For example, if `A41.9` is claimed, the Under-Coding Engine will NOT suggest `A41.02`. This guarantees the Under-Coding Engine strictly handles **cross-family** missing codes, cleanly handing off **intra-family** specificity upgrades entirely to Node 3 (Specificity Engine) to prevent duplicate looping.
  4. Discovered candidates are enqueued into `code_queue` tagged with `{"code": "...", "type": "undercoding"}`.

---

### Layer 3: Tri-Layer Knowledge Assembly & Context Hydration
* **Purpose**: Prepares a complete 360-degree knowledge context for every candidate code before clinical validation.
* **Components**: `Node 3: Data Agent` & `Node 4: Payload Assembler` in `backend/orchestrator.py`.
* **The Tri-Layer Brain Architecture**:

| Knowledge Layer | Storage & Delivery | Scope & Content | Key Strategy |
| :--- | :--- | :--- | :--- |
| **Layer 3A: System Prompt Injection** | System Prompt (`validator_agent_prompt.md`) | Universal rules (Sections I.A, I.B, II, III, IV), operational coding rules (e.g. II.H/III.C uncertain diagnoses, III.B abnormal findings), and **citation mandates**. | Embedded in prompt context to guarantee universal compliance without RAG dependency. |
| **Layer 3B: Narrative Guidelines** | Vector DB (Azure Cosmos DB for MongoDB vCore) | Chapter-specific clinical coding guidelines (Section I.C) chunked by disease entity. | **Text-to-Vector Flow:** Backend Python sends disease strings to Azure OpenAI (`text-embedding-3-small`) to generate a vector array, then passes this mathematical vector directly to **Azure Cosmos DB for MongoDB (vCore)** via `$vectorSearch` for high-speed dynamic RAG retrieval. |
| **Layer 3C: Tabular Rules** | Graph DB (Neo4j / Neo4j Aura) | Rigid structural constraints: `EXCLUDES1`, `EXCLUDES2`, `CODE_FIRST`, `CODE_ALSO`, `USE_ADDITIONAL_CODE`. | Indexed Cypher graph traversals returning code relationships (<10ms). |

* **Scope Boundary Guard**: Validates whether the code falls within the pilot scope (Chapter 1: `A00-B99`). Out-of-scope codes (e.g. `I33.0`, `R65.20`) are immediately routed to `MANUAL_REVIEW` ("Outside Chapter 1 pilot scope") with no hallucinated decisions.

---

### Layer 4: Clinical Validation, FastPath & Guardrails
* **Purpose**: Evaluates candidate codes against extracted evidence and hydrated guidelines to render individual code decisions.
* **Components**: `Node 5: Validator Agent` (`backend/validator_agent.py`) and `backend/guardrails.py`.

```mermaid
flowchart TD
    IN[Input Context Payload] --> FP_CHECK{FastPath Match?<br>Exact Synonym / Inclusion}
    FP_CHECK -->|Yes| FP_PASS[Generate FastPath Valid Verdict]
    FP_CHECK -->|No / Ambiguous| LLM_VAL[Invoke Validator Agent LLM]
    
    LLM_VAL --> GUARD1{Pass 1: Numeric Grounding<br>Numbers in citation exist in DB?}
    GUARD1 -->|Fail| RETRY_1[Corrective Feedback Prompt]
    GUARD1 -->|Pass| GUARD2{Pass 2: String Grounding<br>Citation >= 85% match in DB?}
    GUARD2 -->|Fail| RETRY_1
    GUARD2 -->|Pass| GUARD3{Pass 3: Guideline Citation<br>Section exists in RAG text?}
    GUARD3 -->|Fail| RETRY_1
    GUARD3 -->|Pass| VERDICT_OUT[Final Validated Decision]
    
    RETRY_1 --> LLM_VAL_RETRY[Validator Agent Retry #1]
    LLM_VAL_RETRY --> GUARD_RETRY{Re-eval Guardrails}
    GUARD_RETRY -->|Pass| VERDICT_OUT
    GUARD_RETRY -->|Fail| MR_OUT[Route to MANUAL_REVIEW]
    FP_PASS --> VERDICT_OUT
```

#### Operational Validator Rules & Decision Types:
* **Operational Rules (System Prompt)**: Enforces Section II.H / III.C (coding uncertain diagnoses as confirmed in inpatient), Section IV.H (never coding uncertain diagnoses as confirmed in outpatient), Section III.B (ignoring abnormal lab/pathology results without documented clinician diagnosis), and mandatory section citations (e.g., `Section I.C.1.a.2`, `Section I.A.19`, `EXCLUDES1 (B20)`).
* **`VALID`**: Code is clinically supported by verbatim text and complies with guidelines.
* **`INVALID`**: Code is unsupported, contradicted, or ruled out by provider documentation.
* **`SWAP`**: Code must be replaced by a more specific or combined code (e.g., swapping `A41.9` ➔ `A41.02`). The new code is enqueued into Node 2 with `"type": "swap"`.
* **`ADD_COMPANION`**: Code is valid but requires a mandatory secondary companion (e.g. `USE_ADDITIONAL_CODE`). Enqueued into Node 2 with `"type": "companion"`.

---

### Layer 5: Deterministic Tabular Rule Engine (Global Reconciliation)
* **Purpose**: Performs whole-claim multi-code constraint reconciliation. While Layer 4 evaluates codes individually, Layer 5 ensures global compliance across the entire claim.
* **Module**: `Node 7: Rule Engine` in `backend/rule_engine.py` (`reconcile_claim_rules`).
* **Implementation**: Deterministic Python algorithms with `RangeMatcher` (supporting exact codes `B20`, wildcards `B95.*`, and closed ranges `A00.0-B99.9`).

```mermaid
flowchart TD
    POOL[Pool of Valid & Candidate Codes] --> P1[Pass 1: EXCLUDES1 Mutual Exclusion]
    P1 -->|Identify mutually exclusive pairs| E1_DROP[Drop Secondary / Incompatible Code<br>e.g., Drop Z21 if active B20 present]
    
    E1_DROP --> P2[Pass 2: CODE_FIRST Dependency & Sequencing]
    P2 -->|Check required etiology code| CF_CHECK{Etiology Present?}
    CF_CHECK -->|Yes| CF_SEQ[Promote Etiology to Principal<br>Sequence Manifestation as Secondary]
    CF_CHECK -->|No| CF_DROP[Mark Manifestation INVALID<br>Log Missing Etiology Dependency]
    
    CF_SEQ --> P3[Pass 3: USE_ADDITIONAL_CODE Companion Verification]
    P3 -->|Check mandatory companion ranges| UAC_CHECK{Companion Present?}
    UAC_CHECK -->|Yes| UAC_VALID[Mark Code Fully VALID]
    UAC_CHECK -->|No| UAC_INCOMP[Mark Code INCOMPLETE<br>Log Missing Mandatory Companion]
    
    UAC_VALID & UAC_INCOMP --> P4[Pass 4: Advisory Notes Compilation]
    P4 --> SEQ[Pass 5: Final Sequence Assembly<br>Principal First -> Secondaries]
```

---

### Layer 6: Insights, Reporting & Compliance Telemetry
* **Purpose**: Generates structured, immutable JSON audit trails for compliance auditors, electronic billing systems, and healthcare analytics dashboards.
* **Storage Location**: [`insights/`](file:///c:/Users/danis/Desktop/capstone/capstone_danish/insights)
  * **`insights/audit_reports/`**: Detailed JSON reports with code statuses, verbatim quotes, guideline section citations, and reconciliation notes.
  * **`insights/telemetry_logs.jsonl`**: Real-time trace logs capturing token usage, execution durations, and guardrail intervention logs.

---

### Layer 7: Frontend Web Dashboard
* **Purpose**: Provides a paste-and-audit interface for real-time visualization of the validation lifecycle.
* **Component**: Next.js 16 + React 19 UI in `frontend/`.
* **Key Capabilities**:
  * **Dynamic PDF Viewer**: Renders the multi-page mock clinical charts with interactive zoom controls (40%-250%).
  * **Azure Blob SAS Engine**: Fetches PDFs securely using temporary Shared Access Signature URLs.
  * **5-Column Claim Table**: Streamlined results table displaying verified sequences, justifications, and rule warnings.
  * **Cloud-Ready Networking**: Fetches backend endpoints dynamically via `process.env.NEXT_PUBLIC_API_URL` without any hardcoded localhost bindings.

---

## 4. End-to-End Sequence Diagram

```mermaid
sequenceDiagram
    autonumber
    actor Clinician as Provider / Billing Coder
    participant DocIntel as Azure AI Doc Intelligence
    participant Orch as MAF Orchestrator
    participant Ext as Node 0: Extractor Agent
    participant N4J as Neo4j Graph DB
    participant VDB as Cosmos DB Vector (RAG)
    participant Val as Node 5: Validator Agent
    participant Guard as Guardrail Engine
    participant Rules as Node 7: Rule Engine
    participant Rep as Insights Storage

    Clinician->>DocIntel: Upload Patient Chart (PDF) + Billed Codes
    DocIntel-->>Orch: Return High-Fidelity Clinical Text
    Orch->>Ext: Extract Clinical Ground Truth (Node 0)
    Ext-->>Orch: Return structured evidence_db with source_quotes
    
    Orch->>N4J: Query unbilled diagnoses for under-coding (Node 1)
    N4J-->>Orch: Return candidate codes (e.g. A41.02)
    Orch->>Orch: Populate Priority Code Queue (Node 2)
    
    loop For each code in Queue
        Orch->>N4J: Fetch Tabular Rules (Node 3: EXCLUDES1, CODE_FIRST, UAC)
        N4J-->>Orch: Return rules & disease synonyms
        Orch->>VDB: Fetch narrative Section I.C guidelines for disease
        VDB-->>Orch: Return guideline text chunks
        Orch->>Orch: Assemble Hydrated Payload (Node 4)
        
        alt FastPath match exists
            Orch->>Orch: Assign FastPath VALID
        else Complex validation needed
            Orch->>Val: Call Validator Agent with Context (Node 5)
            Val-->>Guard: Return Decision (VALID/INVALID/SWAP/ADD_COMPANION)
            Guard->>Guard: Execute Numeric & Text Grounding Passes
            Guard-->>Orch: Return verified verdict (Node 6)
        end
        
        opt Verdict is SWAP or ADD_COMPANION
            Orch->>Orch: Push replacement/companion to queue (Node 2)
        end
    end
    
    Orch->>Rules: Pass all validated codes to Rule Engine (Node 7)
    Rules->>Rules: Run EXCLUDES1 pairwise mutual exclusion
    Rules->>Rules: Run CODE_FIRST etiology promotion & sequencing
    Rules->>Rules: Run USE_ADDITIONAL_CODE companion audit
    Rules-->>Orch: Return final validated_sequence + dropped_codes
    
    Orch->>Rep: Write JSON report to insights/audit_reports/
    Orch->>Rep: Log telemetry to insights/telemetry_logs.jsonl
    Orch-->>Clinician: Return Final Validated Claim Audit
```

---

## 5. Microsoft Agent Framework (MAF) Orchestration Engine

The pipeline is orchestrated by the **Microsoft Agent Framework (MAF)** state machine (`backend/orchestrator.py`), coordinating multi-agent lifecycles, graph lookups, runtime guardrails, and deterministic rule enforcement.

### MAF State Machine Architecture & Transitions

```mermaid
stateDiagram-v2
    [*] --> INITIALIZE: Ingest Chart Text & Billed Codes
    INITIALIZE --> UNDER_CODING_CHECK: evidence_db generated (Node 0 Extractor)
    UNDER_CODING_CHECK --> QUEUE_ROUTER: Unbilled candidate codes discovered (Node 1)
    
    QUEUE_ROUTER --> NEO4J_QUERY: Dequeue next target code (Node 2)
    QUEUE_ROUTER --> COMPILE_OUTPUT: Code queue exhausted (Trigger Node 7 Rule Engine)
    
    NEO4J_QUERY --> PAYLOAD_ASSEMBLER: Code within Chapter 1 pilot scope (Node 3)
    NEO4J_QUERY --> QUEUE_ROUTER: Out-of-scope code (Route to MANUAL_REVIEW)
    
    PAYLOAD_ASSEMBLER --> VALIDATION_AGENT_CALL: Hydrate Tri-Layer Context (Node 4)
    VALIDATION_AGENT_CALL --> DECISION_ROUTER: Clinical verdict & evidence returned (Node 5)
    
    DECISION_ROUTER --> QUEUE_ROUTER: Enqueue SWAP / ADD_COMPANION codes (Node 6)
    
    COMPILE_OUTPUT --> [*]: Save to insights/ and complete execution (Node 7)
```

### State Contract & Observability

The orchestrator manages a central, typed state contract (`ClaimValidationState`) throughout the execution lifecycle. Every node transition is wrapped in an OpenTelemetry trace span, emitting observability logs to **Azure Application Insights** and local telemetry logs:

```python
class ClaimValidationState(TypedDict):
    raw_claimed_codes: list[str]
    evidence_db: dict
    code_queue: list[dict]
    processed_codes: list[str]
    iteration_count: int
    validated_sequence: list[dict]
    dropped_codes: list[dict]
    suggested_additions: list[dict]
    audit_report: list[dict]
    tabular_rules_by_code: dict[str, dict]
    documented_evidence_codes: list[str]
    current_node: str
    current_target_code: str | None
    current_target_type: str | None
    current_tabular_rules: dict | None
    current_rag_guidelines: str | None
    current_verdict: Any | None
    current_retries: int
```

### Node-by-Node Execution Matrix

| Node | Name | Input | Output | MAF Responsibilities & Invariants |
| :--- | :--- | :--- | :--- | :--- |
| **Node 0** | `INITIALIZE` | Raw clinical text | `evidence_db` | Invokes the **MAF Extractor Agent** with strict Pydantic schemas. Extracts verified diagnoses, vitals, organisms, and verbatim quotes. |
| **Node 1** | `UNDER_CODING_CHECK` | `evidence_db`, `claimed_codes` | `code_queue` | Identifies documented but unbilled conditions via Neo4j lexical search; tags candidates as `{"type": "undercoding"}`. |
| **Node 2** | `QUEUE_ROUTER` | `code_queue`, `iteration_count` | `current_target_code` | Dequeues the next candidate in FIFO order. Enforces a **20-iteration safety limit** to guarantee loop termination. |
| **Node 3** | `NEO4J_QUERY` | `current_target_code` | `tabular_rules` | Queries Neo4j for tabular rules (`EXCLUDES1`, `CODE_FIRST`, `USE_ADDITIONAL_CODE`). Enforces Chapter 1 pilot scope boundaries. |
| **Node 4** | `PAYLOAD_ASSEMBLER` | Rules, Guidelines, Evidence | `hydrated_payload` | Assembles the Tri-Layer Brain context payload (System Prompt + RAG Guidelines + Neo4j Rules). |
| **Node 5** | `VALIDATION_AGENT_CALL` | `hydrated_payload` | `raw_verdict` | FastPath heuristic check or **MAF Validator Agent** invocation with 3-pass runtime anti-fabrication guardrails. |
| **Node 6** | `DECISION_ROUTER` | `raw_verdict` | Updated `code_queue` | Enqueues replacements (`"type": "swap"`) or mandatory secondaries (`"type": "companion"`) back to the queue. |
| **Node 7** | `COMPILE_OUTPUT` | All validated codes | Final Audit Report | Dispatches to the deterministic **Tabular Rule Engine** (`backend/rule_engine.py`) and archives reports to [`insights/`](file:///c:/Users/danis/Desktop/capstone/capstone_danish/insights). |

---

## 6. Real-World Test Case Validation Scenarios

| Test Case | Clinical Scenario | Billed Codes | Pipeline Action & Resolution | Final Output Sequence |
| :--- | :--- | :--- | :--- | :--- |
| **Test Case 1** | Severe sepsis due to MRSA with acute kidney injury. | `A41.9` (Unspecified Sepsis)<br>`B95.62` (MRSA secondary organism) | **Combination Swap**: Identifies provider documentation of MRSA sepsis. Swaps `A41.9` ➔ `A41.02` (Sepsis due to MRSA). Drops `B95.62` as redundant since organism is included in combination code. | **`A41.02`** *(Principal)* |
| **Test Case 2** | Asymptomatic HIV patient admitted for unrelated acute appendicitis. | `B20` (Active HIV Disease) | **Asymptomatic Swap**: Extracted evidence notes patient is asymptomatic with normal CD4. RAG retrieves Guideline I.C.1.a.2 forbidding `B20`. Swaps `B20` ➔ `Z21` (Asymptomatic HIV status). | **`Z21`** *(Secondary)* |
| **Test Case 3** | Claim incorrectly bills both active HIV and asymptomatic HIV status. | `B20`<br>`Z21` | **Excludes1 Reconciliation**: Rule Engine detects pairwise `EXCLUDES1` violation between `B20` and `Z21`. Verifies chart confirms active AIDS-defining illness, retaining `B20` and dropping `Z21`. | **`B20`** *(Principal)* |
| **Test Case 4** | MRSA Sepsis with acute infective endocarditis and non-pilot systemic codes. | `A41.9`<br>`I33.0` (Endocarditis)<br>`R65.20` (Severe sepsis) | **Scope Routing & Swap**: Swaps `A41.9` ➔ `A41.02`. Flags `I33.0` (Chapter 9) and `R65.20` (Chapter 18) for **Manual Review** due to pilot boundary protection. | **`A41.02`** *(Valid)*<br>`I33.0`, `R65.20` *(Manual Review)* |

---

## 7. Technology Stack & Enterprise Production Mapping

| Subsystem | Local Demo Implementation | Enterprise Azure Cloud Production Architecture |
| :--- | :--- | :--- |
| **OCR Document Parsing** | PyMuPDF (`fitz`) / Local Upload | **Azure AI Document Intelligence** (Prebuilt Layout / High-Fidelity OCR) |
| **Extractor Agent** | `mistral-large-latest` via MAF Proxy | **Azure OpenAI Service** (`gpt-4o` / `gpt-5.4`) with JSON Schema Enforcement |
| **Validator Agent (Judge)** | `mistral-large-latest` + FastPath Matcher | **Azure AI Foundry Agent Service** with dynamic prompt caching |
| **Vector Knowledge Base** | Local `chromadb` (`all-MiniLM-L6-v2`) | **Azure Cosmos DB Vector Search** (Enterprise RAG with `text-embedding-3-small`) |
| **Tabular Knowledge Graph** | Local Neo4j Community Instance | **Neo4j Enterprise on Azure / Neo4j AuraDB** (Stays in Neo4j) |
| **Workflow Orchestration** | Local Python Finite State Machine | **Microsoft Agent Framework (MAF) SDK** on **Azure Container Apps** |
| **Secret Management** | Local `.env` File | **Azure Key Vault** (Runtime connection string & key retrieval via Managed Identity) |
| **PDF Blob Storage** | Local `data/uploads/` | **Azure Blob Storage** (Private container with temporary SAS URL delivery) |
| **Compliance & Telemetry** | Local JSON & JSONL in `insights/` | **Azure Monitor & Application Insights** (Log Analytics Workspace) |

---

## 8. Summary for Technical Presentations & Defense

When presenting this architecture to technical evaluators or stakeholders, highlight these **4 Key Architectural Innovations**:

1. **Why Graph + Vector + System Prompt instead of pure RAG?**
   * *Pure RAG fails on tabular constraints*: Text embeddings cannot reliably enforce negative mutual exclusions (`EXCLUDES1`) or bidirectional code dependencies. Neo4j handles structural rules deterministically, ChromaDB/Cosmos DB handles rich narrative prose guidelines, and cached System Prompts hold universal rules and citation mandates.
2. **Why Schema-Based Fact Extraction instead of RAG over Patient Charts?**
   * *Medical charts are noisy and semi-structured*: Querying a raw chart via vector similarity produces incomplete evidence. The Extractor creates an unambiguous JSON ground truth database with mandatory verbatim `source_quote` strings.
3. **Why Deterministic Rule Engine over LLM Decisioning for Reconciliation?**
   * *Medicolegal compliance*: Regulators require 100% mathematical consistency. By executing `EXCLUDES1`, `CODE_FIRST`, and `USE_ADDITIONAL_CODE` inside a deterministic Python rule engine (`rule_engine.py`), we eliminate non-deterministic hallucinations in final code sequencing.
4. **Zero-Trust Guardrails & Security**:
   * *Multi-pass verification*: Every code decision must survive numeric, fuzzy text, and guideline section validation before being saved. Credentials are securely fetched at runtime from **Azure Key Vault**.
