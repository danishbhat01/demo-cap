# DATA GENERATION ARCHITECTURE: Phase 1 Setup (Neo4j & Knowledge Base)

## 1. Overview
Before the **Microsoft Agent Framework (MAF) SDK** validation application can process a single claim, the system's "Brain" and "Rulebook" must be instantiated. This is a **one-time, offline data engineering process** that builds the two foundational databases:

> **Current Scope — Pilot:** The Neo4j Knowledge Graph is currently populated with **Chapter 1 only** (Certain Infectious and Parasitic Diseases, A00–B99). The architecture is designed to generalize to all 22 ICD-10-CM chapters. The Knowledge Base ETL is similarly scoped to the Chapter 1 guidelines in Section I.C.

| Database | Source File | Current Scope | Purpose |
| :--- | :--- | :--- | :--- |
| **Neo4j Graph Database** | `icd10cm_tabular_2026.xml` | Chapter 1 (A00–B99) Pilot | Stores the ICD-10-CM hierarchy, tabular coding instructions, synonyms, organisms, and clinical terms. |
| **Azure Knowledge Base** | CMS Guidelines PDF (Section I.C) | Chapter 1 Guidelines (Pilot) | Stores semantic guideline chunks for each disease category, enabling RAG retrieval at validation time. |

---

## 2. Neo4j Full Schema (Source of Truth: Agent API Reference)

The `parse_tabular-3.py` script reads `icd10cm_tabular_2026.xml` and creates the following complete graph schema.

### 2.1 Node Types

| Node Label | Key Property | Other Properties | Description |
| :--- | :--- | :--- | :--- |
| `Chapter` | `chapter_code` (String, unique) | `description` | Top-level ICD-10-CM chapter, e.g., Chapter "1" |
| `Block` | `block_code` (String, unique) | `description` | A code range within a chapter, e.g., "A00-A09" |
| `DiseaseCode` | `code` (String, unique) | `description`, `billable` (Boolean) | Individual ICD-10-CM code, e.g., "A41.9" |
| `ClinicalTerm` | `term` (String) | `type` (Include/Synonym/SearchTerm), `category` ("organism" or null) | Synonyms, inclusion terms, or organism agents linked to a code |
| `CodeRange` | `range` (String, unique) | `type` (wildcard/range) | Wildcard or span targets for coding instructions, e.g., "A05.-" |

> **Critical:** `DiseaseCode` uses `code` as its identifier. `CodeRange` uses `range`. Always use `coalesce(target.code, target.range)` when traversing edges that can point to either.

### 2.2 Relationship Types

#### Hierarchy Relationships
| Relationship | Source to Target | Meaning |
| :--- | :--- | :--- |
| `HAS_BLOCK` | Chapter to Block | A chapter contains code range blocks. |
| `CONTAINS` | Block to DiseaseCode | A block contains the top-level codes in its range. |
| `HAS_CHILD` | DiseaseCode to DiseaseCode | A parent code has more specific child codes. Traversable with * for full depth. |

#### Clinical Terminology Relationships
| Relationship | Source to Target | Meaning |
| :--- | :--- | :--- |
| `HAS_INCLUDE` | Chapter/Block/DiseaseCode to ClinicalTerm | Inclusion terms and synonyms (non-organism). `category` is NULL. |
| `HAS_SEARCH_TERM` | DiseaseCode to ClinicalTerm | Organism/causative agents only. `category = "organism"`. |

#### Coding Instruction Relationships (Tabular Rules)
| Relationship | Meaning | Validation Logic |
| :--- | :--- | :--- |
| `EXCLUDES1` | Hard mutual exclusion. Both codes must NEVER appear together on same claim. | Flag as violation if both codes present. |
| `EXCLUDES2` | Soft restriction. Both codes can be assigned if both conditions are clinically present. | Acceptable if both conditions are documented. |
| `CODE_FIRST` | Sequencing rule. The **target** code must be sequenced **BEFORE** the source code. | Flag if target does not appear earlier in the diagnostic sequence. |
| `CODE_ALSO` | Optional companion. May be needed for complete specificity. | Suggest, but do not mandate. |
| `USE_ADDITIONAL_CODE` | Mandatory companion. An additional code is required (e.g., organism specification). | Flag as incomplete if companion code is absent from the claim. |

> All Coding Instruction relationships point from `DiseaseCode` to either `DiseaseCode` or `CodeRange`.

### 2.3 Neo4j Ingestion Flow
```mermaid
flowchart LR
    XML[icd10cm_tabular_2026.xml] --> Script[parse_tabular-3.py]
    Script --> N1[Chapter Nodes]
    Script --> N2[Block Nodes]
    Script --> N3[DiseaseCode Nodes\ncode, description, billable]
    Script --> N4[ClinicalTerm Nodes\nSynonyms + Organisms]
    Script --> N5[CodeRange Nodes\nWildcard + Range targets]
    Script --> E1[Hierarchy Edges\nHAS_BLOCK, CONTAINS, HAS_CHILD]
    Script --> E2[Clinical Edges\nHAS_INCLUDE, HAS_SEARCH_TERM]
    Script --> E3[Tabular Instruction Edges\nEXCLUDES1, EXCLUDES2, CODE_FIRST\nCODE_ALSO, USE_ADDITIONAL_CODE]
    N1 & N2 & N3 & N4 & N5 --> N4J[(Neo4j Graph)]
    E1 & E2 & E3 --> N4J
```

### 2.4 Cypher Ingestion Example (Verified Against Agent API Reference)
```cypher
// 1. Create the Disease Node (DiseaseCode) with exact Tabular description
MERGE (c:DiseaseCode {code: 'A41.9'})
SET c.description = 'Sepsis, unspecified organism',
    c.billable = true

// 2. Attach Inclusion Synonym (ClinicalTerm, type=Include, category=NULL)
MERGE (t:ClinicalTerm {term: 'Septicemia NOS', type: 'Include'})
MERGE (c)-[:HAS_INCLUDE]->(t)

// 3. Attach Organism Search Term (ClinicalTerm, category='organism')
MERGE (org:ClinicalTerm {term: 'Staphylococcus aureus', type: 'SearchTerm', category: 'organism'})
MERGE (c)-[:HAS_SEARCH_TERM]->(org)

// 4. USE_ADDITIONAL_CODE: A41.9 REQUIRES an organism code (mandatory companion)
//    Points to CodeRange B95-B97 (organism codes range)
MERGE (organism_range:CodeRange {range: 'B95-B97', type: 'range'})
MERGE (c)-[:USE_ADDITIONAL_CODE]->(organism_range)

// 5. CODE_FIRST (correct direction per API Reference):
//    R65.20 must be preceded by a systemic infection code.
//    So R65.20 has CODE_FIRST pointing TO A41.9 (not the other way around).
MERGE (r:DiseaseCode {code: 'R65.20'})
SET r.description = 'Severe sepsis without septic shock', r.billable = true
MERGE (r)-[:CODE_FIRST]->(c)
```

---

## 3. Azure Knowledge Base Ingestion Flow (ETL)

### 3.1 The Semantic Chunking Strategy

**Naive approach:** Split the 120-page CMS PDF every 500 tokens. Result: a 6-paragraph Sepsis guideline gets sliced in half and RAG retrieval returns broken, incomplete context.

**Our approach (Semantic Chunking by Disease Entity):** The Python ETL script feeds entire PDF sections to GPT-4o. GPT-4o is prompted to extract one JSON object per **Disease Entity / Heading Boundary**, keeping all related paragraphs together in a single, coherent chunk.

```mermaid
flowchart LR
    PDF[CMS Guidelines PDF\nSection I.C] --> ETL[Python Semantic Chunking ETL]
    ETL --> |GPT-4o Entity Extraction| JSON["Metadata-Enriched JSON Chunks\n{chunk_id, disease_entity, chapter, content, source}"]
    JSON --> Embed[Azure OpenAI Embeddings]
    Embed --> KB[(Azure Knowledge Base)]
```

### 3.2 Metadata-Enriched JSON Chunk Format
Each chunk uploaded to the Knowledge Base is structured as follows:
```json
{
  "chunk_id": "guideline-IC-001",
  "disease_entity": "Sepsis",
  "chapter": "Chapter 1",
  "source": "CMS_ICD10CM_Guidelines_2026.pdf",
  "content": "Do not assign code R65.2, Severe sepsis, unless severe sepsis or an associated acute organ dysfunction is documented. A code from subcategory R65.2..."
}
```
The metadata fields enable **Hybrid Search**: the Agent can vector-search by semantic similarity while also filtering on chapter or source, making retrieval precise and auditable.

---

## 4. The Bridge: Mapping Tabular Names to Guidelines (Synonym-Enriched RAG)

**The Data Engineering Challenge:**
The Official Tabular XML (Neo4j) and the Official Guidelines PDF (Knowledge Base) do not always use identical terminology:
* Neo4j `DiseaseCode.description`: *"Human immunodeficiency virus [HIV] disease"*
* Guideline PDF heading: *"HIV Infections"*

**The Solution (Synonym-Enriched RAG):**
MAF SDK does not just extract the `DiseaseCode.description` from Neo4j. It also extracts all official **Synonyms and Inclusion Terms** via the `HAS_INCLUDE` relationship to `ClinicalTerm` nodes (where `category IS NULL`) and all **organism terms** via `HAS_SEARCH_TERM`.

This enriched payload (Primary Name + Synonyms + Organisms) is passed to the Azure Validation Agent. The Agent searches the Knowledge Base using this richer context. The underlying vector embeddings understand that "HIV disease" and "HIV Infections" are clinically identical, guaranteeing a precise semantic match every time.

---

## 5. Asset Consumption Mapping (Where Is It Used at Runtime?)

| Generated Asset | Consumed By | Purpose During Runtime Validation |
| :--- | :--- | :--- |
| **Neo4j Graph Database** | **MAF SDK Orchestrator** | Queried *before* the Agent is invoked. MAF extracts `EXCLUDES1`, `EXCLUDES2`, `CODE_FIRST`, `USE_ADDITIONAL_CODE` tabular rules, the `description`, and all `ClinicalTerm` synonyms for the Target Code. |
| **Azure Knowledge Base** | **Azure Validation Agent** | The Azure AI Foundry Agent performs native RAG *during* its reasoning loop, searching the Knowledge Base by Disease Name + Synonyms to fetch Code-Specific Guidelines (Section I.C). |
| **System Prompt (General Guidelines)** | **Azure Validation Agent** | The Agent uses the statically loaded Universal Guidelines (Sections I.A - IV) to enforce universal billing rules, principal diagnosis selection, and sequencing without any database lookup. |
| **JSON Evidence Database** | **Azure Validation Agent** | Generated upfront by the LLM Extractor from the medical chart, this is the Clinical Ground Truth against which all tabular rules and guidelines are evaluated. |
