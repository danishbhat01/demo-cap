# ICD-10-CM Knowledge Graph — Agent API Reference

## Overview
This document is the **contract** between the validation agent and the Neo4j knowledge graph. It specifies:
- What data exists in the graph
- How to query it (exact relationship types and property names)
- What each query returns
- When and how to use each query during validation

---

## Part 1: Node Types & Properties

### Chapter Node
**Label:** `Chapter`

**Properties:**
```
chapter_code : String (unique)  -- e.g., "1"
description  : String          -- e.g., "Certain infectious and parasitic diseases (A00-B99)"
```

**Example Query:**
```cypher
MATCH (c:Chapter {chapter_code: "1"})
RETURN c.chapter_code, c.description
```

---

### Block Node
**Label:** `Block`

**Properties:**
```
block_code  : String (unique)  -- e.g., "A00-A09"
description : String          -- e.g., "Intestinal infectious diseases (A00-A09)"
```

**Example Query:**
```cypher
MATCH (b:Block {block_code: "A00-A09"})
RETURN b.block_code, b.description
```

---

### DiseaseCode Node
**Label:** `DiseaseCode`

**Properties:**
```
code        : String (unique)  -- e.g., "A01.02", "B20"
description : String          -- Official ICD-10-CM description, e.g., "Typhoid fever with heart involvement"
billable    : Boolean         -- true if this is a leaf code (assignable), false if parent
```

**Important:** `code` is the ONLY identifier property for DiseaseCode nodes. Do NOT assume `range` or any other property.

**Example Query:**
```cypher
MATCH (d:DiseaseCode {code: "A01.02"})
RETURN d.code, d.description, d.billable
```

---

### ClinicalTerm Node
**Label:** `ClinicalTerm`

**Properties:**
```
term     : String           -- The clinical term/synonym/organism name, e.g., "Typhoid endocarditis"
type     : Enum             -- One of: "Include", "Synonym", "SearchTerm"
category : String (optional)-- If present and equals "organism", this is an organism term
```

**When `category = "organism"`:** This ClinicalTerm represents a causative organism or pathogen (e.g., "Vibrio cholerae", "Streptococcus", "Mycobacterium tuberculosis"). These are linked via `HAS_SEARCH_TERM`, not `HAS_INCLUDE`.

**Example Queries:**
```cypher
-- Get all non-organism clinical terms (synonyms/includes)
MATCH (d:DiseaseCode {code: "A01.02"})-[:HAS_INCLUDE]->(t:ClinicalTerm)
WHERE t.category IS NULL OR t.category <> "organism"
RETURN t.term, t.type

-- Get all organism terms ONLY
MATCH (d:DiseaseCode {code: "A01.02"})-[:HAS_SEARCH_TERM]->(t:ClinicalTerm {category: "organism"})
RETURN t.term, t.category
```

---

### CodeRange Node
**Label:** `CodeRange`

**Properties:**
```
range : String (unique)  -- e.g., "A05.-" (wildcard), "A04.0-A04.4" (range), "B95-B96" (range)
type  : Enum            -- One of: "single", "wildcard", "range"
                        -- "single" should never appear (use DiseaseCode instead)
                        -- "wildcard" = category placeholder ending in ".-"
                        -- "range" = span of codes like A04.0-A04.4
```

**CRITICAL:** CodeRange nodes use `range` as their identifier, NOT `code`. DiseaseCode uses `code`. Always use `coalesce(target.code, target.range)` when traversing relationships to targets that could be either.

**Example Query:**
```cypher
MATCH (d:DiseaseCode {code: "A04.7"})-[:EXCLUDES1]->(target)
RETURN coalesce(target.code, target.range) as target_id, 
       labels(target)[0] as target_type,
       target.type as range_type  -- only for CodeRange
```

---

## Part 2: Relationship Types & Usage

### Hierarchy Relationships

#### HAS_BLOCK
**Direction:** `Chapter → Block`
**Meaning:** A chapter contains blocks (code ranges).
**Cardinality:** One chapter has many blocks.

**Example:**
```cypher
MATCH (c:Chapter {chapter_code: "1"})-[:HAS_BLOCK]->(b:Block)
RETURN b.block_code, b.description
```

---

#### CONTAINS
**Direction:** `Block → DiseaseCode`
**Meaning:** A block contains the top-level disease codes in its range.
**Cardinality:** One block contains many codes; one code is in exactly one block.

**Example:**
```cypher
MATCH (b:Block {block_code: "A00-A09"})-[:CONTAINS]->(d:DiseaseCode)
RETURN d.code, d.description, d.billable
```

---

#### HAS_CHILD
**Direction:** `DiseaseCode → DiseaseCode`
**Meaning:** A code has child codes (more specific variants).
**Cardinality:** Parent code has many children; child has exactly one parent.
**Reverse Traversal:** Use `<-[:HAS_CHILD]-` to find parent from child.

**Example (Forward):**
```cypher
MATCH (parent:DiseaseCode {code: "A01"})-[:HAS_CHILD*]->(leaf:DiseaseCode)
WHERE NOT (leaf)-[:HAS_CHILD]->()  -- leaf has no children
RETURN parent.code, leaf.code, leaf.description
```

**Example (Reverse - find parent):**
```cypher
MATCH (child:DiseaseCode {code: "A01.02"})<-[:HAS_CHILD]-(parent:DiseaseCode)
RETURN parent.code, parent.description
```

---

### Clinical Terminology Relationships

#### HAS_INCLUDE
**Direction:** `DiseaseCode → ClinicalTerm` or `Chapter → ClinicalTerm` or `Block → ClinicalTerm`
**Meaning:** Inclusion terms or synonyms for the code/block/chapter.
**ClinicalTerm Properties:** `type` is "Include" or "Synonym"; `category` is NOT "organism"

**Example:**
```cypher
MATCH (d:DiseaseCode {code: "A01.02"})-[:HAS_INCLUDE]->(t:ClinicalTerm)
WHERE t.category IS NULL
RETURN t.term, t.type
```

---

#### HAS_SEARCH_TERM
**Direction:** `DiseaseCode → ClinicalTerm`
**Meaning:** Search terms, primarily organisms and causative agents. Always linked from DiseaseCode only.
**ClinicalTerm Properties:** When present, `category = "organism"`

**Important:** Only organisms, bacteria, viruses, and similar causative agents use `HAS_SEARCH_TERM`. Regular synonyms use `HAS_INCLUDE`.

**Example:**
```cypher
-- Get all organisms for a code
MATCH (d:DiseaseCode {code: "A01.0"})-[:HAS_SEARCH_TERM]->(org:ClinicalTerm {category: "organism"})
RETURN org.term as organism_name

-- Or with explicit filtering (redundant but clear)
MATCH (d:DiseaseCode {code: "A01.0"})-[:HAS_SEARCH_TERM]->(t:ClinicalTerm)
WHERE t.category = "organism"
RETURN t.term
```

---

### Coding Instruction Relationships
These represent tabular instructions from the Tabular List, NOT guidelines. They're code-to-code relationships.

#### EXCLUDES1
**Direction:** `DiseaseCode → (DiseaseCode | CodeRange)`
**Meaning:** Mutually exclusive. The two codes should NEVER both be assigned to the same patient/encounter.
**Target Types:** Can point to either a `DiseaseCode` or `CodeRange`.

**Example:**
```cypher
MATCH (d:DiseaseCode {code: "A04.7"})-[:EXCLUDES1]->(target)
RETURN coalesce(target.code, target.range) as excluded_code,
       labels(target)[0] as target_type
```

**Validation Logic:** If claimed code has an EXCLUDES1 edge to another code in the medical record, reject/flag as violation.

---

#### EXCLUDES2
**Direction:** `DiseaseCode → (DiseaseCode | CodeRange)`
**Meaning:** Not included here, but both codes CAN be assigned if both conditions are clinically present.
**Target Types:** Can point to either `DiseaseCode` or `CodeRange`.

**Example:**
```cypher
MATCH (d:DiseaseCode {code: "A04"})-[:EXCLUDES2]->(target)
RETURN coalesce(target.code, target.range) as related_code
```

**Validation Logic:** If both codes appear in the record, that's clinically appropriate (not a violation). If only one appears, that's also fine.

---

#### CODE_FIRST
**Direction:** `DiseaseCode → (DiseaseCode | CodeRange)`
**Meaning:** Sequencing rule. The target code must be sequenced BEFORE this code (as principal diagnosis or earlier in the sequence).
**Target Types:** Can point to either `DiseaseCode` or `CodeRange`.

**Example:**
```cypher
MATCH (d:DiseaseCode {code: "R65.20"})-[:CODE_FIRST]->(target)
RETURN coalesce(target.code, target.range) as must_sequence_first
```

**Validation Logic:** If claimed code has CODE_FIRST edge, verify the target appears earlier in the diagnostic sequence. If not, flag for sequencing correction.

---

#### CODE_ALSO
**Direction:** `DiseaseCode → (DiseaseCode | CodeRange)`
**Meaning:** Optional companion code. Both codes may be needed for complete specificity.
**Target Types:** Can point to either `DiseaseCode` or `CodeRange`.
**Difference from USE_ADDITIONAL_CODE:** CODE_ALSO is optional/discretionary; USE_ADDITIONAL_CODE is required/mandatory.

**Example:**
```cypher
MATCH (d:DiseaseCode {code: "B20"})-[:CODE_ALSO]->(target)
RETURN coalesce(target.code, target.range) as optional_companion
```

**Validation Logic:** Suggest but do not mandate the additional code.

---

#### USE_ADDITIONAL_CODE
**Direction:** `DiseaseCode → (DiseaseCode | CodeRange)`
**Meaning:** An additional code is REQUIRED. Typically used for organism specification or other mandatory detail codes.
**Target Types:** Can point to either `DiseaseCode` or `CodeRange`.
**Difference from CODE_ALSO:** USE_ADDITIONAL_CODE is mandatory; CODE_ALSO is optional.

**Example:**
```cypher
MATCH (d:DiseaseCode {code: "A41.9"})-[:USE_ADDITIONAL_CODE]->(target)
RETURN coalesce(target.code, target.range) as required_additional_code
```

**Validation Logic:** If claimed code has USE_ADDITIONAL_CODE edge but the target code is missing, flag as incomplete coding.

---

## Part 3: Query Patterns for Common Agent Tasks

### Task 1: Validate a Claimed Code Exists
```cypher
MATCH (d:DiseaseCode {code: "A01.02"})
RETURN d.code, d.description, d.billable
```

**Return:** DiseaseCode node or null. If null, code doesn't exist in graph.

---

### Task 2: Get Full Code Context (Hierarchy + Terms + Instructions)
```cypher
MATCH (c:Chapter)-[:HAS_BLOCK]->(b:Block)-[:CONTAINS]->(top:DiseaseCode {code: "A01"})
OPTIONAL MATCH (top)-[:HAS_CHILD*]->(d:DiseaseCode {code: "A01.02"})

OPTIONAL MATCH (d)-[:HAS_INCLUDE]->(inc:ClinicalTerm)
WHERE inc.category IS NULL

OPTIONAL MATCH (d)-[:HAS_SEARCH_TERM]->(org:ClinicalTerm {category: "organism"})

OPTIONAL MATCH (d)-[:EXCLUDES1|EXCLUDES2|CODE_FIRST|CODE_ALSO|USE_ADDITIONAL_CODE]->(target)

RETURN 
  c.chapter_code as chapter,
  b.block_code as block,
  d.code as code,
  d.description as description,
  d.billable as billable,
  collect(DISTINCT inc.term) as inclusion_terms,
  collect(DISTINCT org.term) as organisms,
  collect({rel_type: type(r), target: coalesce(target.code, target.range)}) as related_codes
```

---

### Task 3: Check for Mutually Exclusive Codes (EXCLUDES1)
```cypher
MATCH (d:DiseaseCode {code: "A04.7"})-[:EXCLUDES1]->(excluded)
RETURN coalesce(excluded.code, excluded.range) as mutually_exclusive_code,
       labels(excluded)[0] as target_type
```

**Usage:** If any of these codes appear in the medical record alongside A04.7, flag as violation.

---

### Task 4: Check for Required Additional Codes
```cypher
MATCH (d:DiseaseCode {code: "A41.9"})-[:USE_ADDITIONAL_CODE]->(required)
RETURN coalesce(required.code, required.range) as required_code,
       labels(required)[0] as target_type
```

**Usage:** If these codes don't appear in the claim, flag as missing/incomplete.

---

### Task 5: Check Sequencing Requirements (CODE_FIRST)
```cypher
MATCH (d:DiseaseCode {code: "R65.20"})-[:CODE_FIRST]->(must_come_first)
RETURN coalesce(must_come_first.code, must_come_first.range) as must_sequence_before
```

**Usage:** Verify the returned code(s) appear before d in the diagnostic sequence.

---

### Task 6: Find All Organisms for a Code
```cypher
MATCH (d:DiseaseCode {code: "A41.9"})-[:HAS_SEARCH_TERM]->(org:ClinicalTerm {category: "organism"})
RETURN org.term as organism_name
```

**Usage:** When clinical record mentions a specific organism (e.g., "Streptococcus pneumoniae"), validate it matches one of the expected organisms for the claimed code.

---

### Task 7: Verify Code is Billable (Leaf Code)
```cypher
MATCH (d:DiseaseCode {code: "A01.02"})
RETURN d.billable
```

**Usage:** If billable = false, the code is a category/parent and cannot be billed; agent should flag and suggest child codes instead.

---

### Task 8: Get Full Hierarchy Chain (Code → Parent → Grandparent → ... → Chapter)
```cypher
MATCH (c:Chapter)-[:HAS_BLOCK]->(b:Block)-[:CONTAINS]->(top:DiseaseCode)
  -[:HAS_CHILD*]->(d:DiseaseCode {code: "A01.02"})
RETURN c.chapter_code, b.block_code, 
       [p IN nodes(path) WHERE p:DiseaseCode | p.code] as hierarchy_chain
```

**Usage:** Understand the full classification context of the code.

---

### Task 9: Find Alternate/Related Codes
```cypher
MATCH (d:DiseaseCode {code: "A01.02"})-[:CODE_ALSO|EXCLUDES2]->(related)
RETURN type(r) as relationship, 
       coalesce(related.code, related.range) as related_code
```

**Usage:** When primary code is rejected, suggest alternative valid codes.

---

### Task 10: Validate Clinical Terms Match Expected Terms
```cypher
MATCH (d:DiseaseCode {code: "A01.02"})-[:HAS_INCLUDE]->(t:ClinicalTerm)
WHERE t.category IS NULL
RETURN t.term as expected_synonym
```

**Usage:** Cross-check clinical documentation against expected synonyms to confirm code is clinically accurate.

---

## Part 4: Critical Rules for Agent Implementation

### Rule 1: Always Use coalesce() for Code Identifiers
When traversing relationships where the target can be DiseaseCode OR CodeRange:
```cypher
-- CORRECT
RETURN coalesce(target.code, target.range) as identifier

-- WRONG - will return NULL for CodeRange targets
RETURN target.code

-- WRONG - will return NULL for DiseaseCode targets
RETURN target.range
```

### Rule 2: Organism Detection
Organisms are identified by:
- **Node Label:** `ClinicalTerm`
- **Property:** `category = "organism"`
- **Relationship:** Connected via `HAS_SEARCH_TERM` (NOT `HAS_INCLUDE`)

Do NOT assume organism detection based on keyword matching in the term text. Use the `category` property.

### Rule 3: Billable Code Check
Before accepting a code as a valid claim, verify:
```cypher
MATCH (d:DiseaseCode {code: "A01"})
WHERE d.billable = true
```

If billable = false, reject and suggest child codes.

### Rule 4: Relationship Type Semantics
- **EXCLUDES1** → Hard stop, never both codes together
- **EXCLUDES2** → Soft restriction, both okay if both present
- **CODE_FIRST** → Sequencing requirement
- **CODE_ALSO** → Optional companion
- **USE_ADDITIONAL_CODE** → Mandatory companion

Do NOT conflate these; each has different validation logic.

### Rule 5: Chapter/Block/Code Hierarchy
Always traverse via the explicit relationships:
```cypher
MATCH (c:Chapter)-[:HAS_BLOCK]->(b:Block)-[:CONTAINS]->(d:DiseaseCode)
  -[:HAS_CHILD*]->(leaf:DiseaseCode)
```

Do NOT assume hierarchy from code string prefixes (e.g., "A01" and "A01.02" aren't hierarchically linked just because of naming).

### Rule 6: Scope of Clinical Terms
- Chapter-level `HAS_INCLUDE`: Broad scope definitions
- Block-level `HAS_INCLUDE`: Block-specific notes
- Code-level `HAS_INCLUDE`: Specific synonyms and inclusion terms
- Code-level `HAS_SEARCH_TERM`: Organisms only

Use the appropriate scope for validation.

---

## Part 5: Example Validation Workflow

### Scenario: Validate Claimed Code A41.9 (Sepsis, unspecified)

**Step 1: Code Exists & Billable?**
```cypher
MATCH (d:DiseaseCode {code: "A41.9"})
RETURN d.billable
```
✅ Returns `billable: true` → proceed

**Step 2: Get All Coding Instructions**
```cypher
MATCH (d:DiseaseCode {code: "A41.9"})
OPTIONAL MATCH (d)-[:USE_ADDITIONAL_CODE]->(additional)
OPTIONAL MATCH (d)-[:CODE_FIRST]->(sequencing)
OPTIONAL MATCH (d)-[:EXCLUDES1]->(mutually_exclusive)
RETURN additional, sequencing, mutually_exclusive
```
✅ Returns: Must add organism code (sepsis-causing organism required)

**Step 3: Check Medical Record Against Instructions**
```
- Claimed code: A41.9
- Clinical facts: "Sepsis due to MRSA" → organism mentioned
- Required: HAS_SEARCH_TERM → organisms
```

**Step 4: Validate Organism**
```cypher
MATCH (d:DiseaseCode {code: "A41.9"})-[:HAS_SEARCH_TERM]->(org:ClinicalTerm {category: "organism"})
RETURN org.term
```
✅ Returns: Expected organisms including "Staphylococcus aureus" (MRSA variant)
✅ Clinical record mentions "MRSA" → matches "Staphylococcus aureus"

**Step 5: Check Missing Required Codes**
```cypher
MATCH (d:DiseaseCode {code: "A41.9"})-[:USE_ADDITIONAL_CODE]->(additional)
RETURN coalesce(additional.code, additional.range) as required_additional
```
✅ Returns: e.g., `B95.7` (Staphylococcus aureus, unspecified) or organism code
⚠️ If not in claim → Flag as missing

**Conclusion:** Code A41.9 is valid if organism specification code is added; otherwise flag incomplete.

---


## Part 5.5: Guideline Retrieval Pattern (GENERAL Sentinel)

**IMPORTANT — Not all guidelines are chapter-specific.** Only Section I.C of the Official
Coding Guidelines is chapter-specific. Sections I.A, I.B, II, III, and IV are general or
setting-based and apply to every claim regardless of chapter.

To keep retrieval uniform, non-chapter-specific GuidelineRule nodes attach via HAS_RULE
from a sentinel node: `Chapter {chapter_code: "GENERAL"}`. This is a schema convenience,
not a real ICD-10-CM chapter.

**Always retrieve guidelines using this three-source pattern:**
```cypher
MATCH (c:Chapter)-[:HAS_BLOCK]->(:Block)-[:CONTAINS]->(d:DiseaseCode {code: $claimed_code})
OPTIONAL MATCH (c)-[:HAS_RULE]->(chapter_rule:GuidelineRule)
OPTIONAL MATCH (general:Chapter {chapter_code: "GENERAL"})-[:HAS_RULE]->(general_rule:GuidelineRule)
OPTIONAL MATCH (d)-[:HAS_RULE]->(code_rule:GuidelineRule)
RETURN collect(DISTINCT chapter_rule) + collect(DISTINCT general_rule) + collect(DISTINCT code_rule) as applicable_rules
```

**Do NOT** query only `(c)-[:HAS_RULE]->(rule)` and assume that's complete — general rules
(like the Section I.B specificity requirement, which applies to every single code) will be
silently missed if the GENERAL sentinel branch is omitted.

## Part 6: Error Handling for Agent

### When Code Not Found
```cypher
MATCH (d:DiseaseCode {code: "INVALID"})
RETURN d
-- Returns: null
```
**Agent Action:** Log "code not found in knowledge graph" and reject claim.

### When Target Node Type Is Ambiguous
```cypher
-- Query returns target but agent doesn't know if it's DiseaseCode or CodeRange
MATCH (d:DiseaseCode {code: "A01"})-[:EXCLUDES1]->(target)
```
**Agent Action:** Always use `labels(target)[0]` to determine node type, then use appropriate identifier: `target.code` for DiseaseCode, `target.range` for CodeRange. Better: use `coalesce(target.code, target.range)`.

### When Relationship Not Found
```cypher
MATCH (d:DiseaseCode {code: "A01"})-[:NONEXISTENT_REL]->(x)
RETURN x
-- Returns: empty (no results)
```
**Agent Action:** This is normal. Not every code has every relationship type. An empty result means "no such relationship exists," not an error.

---

## Appendix: Complete Relationship Type Reference

| Relationship Type | Source | Target | Meaning | Multi-Target |
|---|---|---|---|---|
| HAS_BLOCK | Chapter | Block | Chapter contains blocks | Yes |
| CONTAINS | Block | DiseaseCode | Block contains top-level codes | Yes |
| HAS_CHILD | DiseaseCode | DiseaseCode | Code has child codes | Yes |
| HAS_INCLUDE | DiseaseCode/Block/Chapter | ClinicalTerm | Inclusion terms/synonyms | Yes |
| HAS_SEARCH_TERM | DiseaseCode | ClinicalTerm | Search terms, especially organisms | Yes |
| EXCLUDES1 | DiseaseCode | DiseaseCode\|CodeRange | Mutually exclusive | Yes |
| EXCLUDES2 | DiseaseCode | DiseaseCode\|CodeRange | Not included but coexistable | Yes |
| CODE_FIRST | DiseaseCode | DiseaseCode\|CodeRange | Sequencing requirement | Yes |
| CODE_ALSO | DiseaseCode | DiseaseCode\|CodeRange | Optional companion | Yes |
| USE_ADDITIONAL_CODE | DiseaseCode | DiseaseCode\|CodeRange | Mandatory companion | Yes |

---

## Appendix: Property Names Quick Reference

| Node Type | Property | Type | Example | Used In Queries |
|---|---|---|---|---|
| Chapter | chapter_code | String | "1" | MATCH, WHERE, RETURN |
| Chapter | description | String | "Certain infectious..." | RETURN |
| Block | block_code | String | "A00-A09" | MATCH, WHERE, RETURN |
| Block | description | String | "Intestinal infectious..." | RETURN |
| DiseaseCode | code | String | "A01.02" | MATCH, WHERE, RETURN |
| DiseaseCode | description | String | "Typhoid fever..." | RETURN |
| DiseaseCode | billable | Boolean | true/false | WHERE, RETURN |
| ClinicalTerm | term | String | "Typhoid endocarditis" | MATCH, RETURN |
| ClinicalTerm | type | String | "Include"/"Synonym"/"SearchTerm" | WHERE, RETURN |
| ClinicalTerm | category | String | "organism" | WHERE (optional check) |
| CodeRange | range | String | "A05.-" or "B95-B96" | MATCH, WHERE, RETURN |
| CodeRange | type | String | "wildcard"/"range" | RETURN |

---

## Document Version
- **Version:** 1.0
- **Created:** 2026-07-22
- **Scope:** ICD-10-CM Chapter 1 (pilot), generalized for all chapters
- **Audience:** Validation agent developers, inference pipeline engineers, integration testers
