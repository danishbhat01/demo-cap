# AGENT_SPEC.md
## AI Medical Coder & Claim Validation Pipeline
### Complete Agent Specification — For Planning Agents and Developers
### Scope: ICD-10-CM Chapter 1 (A00-B99) Pilot

---

## 0. How to Read This Document

This is the single source of truth for implementing the validation pipeline. It specifies every agent, every MAF graph node, every edge condition, the state schema, the rule hierarchy, and the exact decision logic for all Chapter 1 edge cases. A planning agent reading this document should be able to implement the full pipeline without any other context.

---

## 1. Agent Roster

### 1.1 Extractor Agent

| Property | Value |
|---|---|
| Role | Converts raw OCR text into a structured JSON Evidence Database |
| Model | GPT-5.4 via Azure OpenAI |
| Validation | Pydantic (strict schema enforcement) |
| Invocation | Once per claim, before the MAF loop starts (Node 0) |
| Input | Raw OCR text from Azure Document Intelligence |
| Output | JSON Evidence Database (schema below) |

**System Prompt Rules (What It MUST Do):**
- Extract ONLY conditions explicitly written by a clinician
- For every diagnosis, include a source_quote: the exact verbatim sentence from the chart
- Extract ALL diagnosed conditions in the chart, not just the ones the doctor claimed
- Extract the clinical setting (Inpatient, Outpatient, Emergency)
- Extract organism names if explicitly mentioned by the clinician
- Extract severity qualifiers (e.g., "severe sepsis", "mild", "acute")

**System Prompt Rules (What It MUST NOT Do):**
- DO NOT infer diagnoses from lab values, vitals, or symptoms
- DO NOT add a diagnosis unless a clinician explicitly named it
- DO NOT perform medical reasoning or clinical interpretation
- DO NOT suggest or map to ICD codes
- DO NOT query Neo4j or the Knowledge Base

**Evidence Database Schema:**
```json
{
  "setting": "Inpatient | Outpatient | Emergency",
  "diagnoses": {
    "<disease_name_as_written_by_clinician>": {
      "confirmed": true | false,
      "severity": "string or null",
      "status": "Active | History of | Suspected | Ruled out | null",
      "source_quote": "exact verbatim sentence from the chart"
    }
  },
  "organism": "string or null (e.g., MRSA, Klebsiella, Streptococcus)",
  "organ_dysfunction": ["list of documented organ failures, e.g., acute kidney failure, respiratory failure"],
  "medical_history": ["list of past medical conditions, family history, or old surgeries"],
  "lab_values": {"key": "value"},
  "medications": ["list of explicitly mentioned medications"],
  "procedures": ["list of explicitly mentioned procedures"]
}
```

> IMPORTANT: The Evidence DB schema includes organ_dysfunction as a top-level array. This is required for Severe Sepsis validation (R65.20/R65.21), where the Validation Agent must confirm documented organ failure.

---

### 1.2 Validation Agent

| Property | Value |
|---|---|
| Role | Validates a single ICD code against all three knowledge layers and the Evidence DB |
| Platform | MAF `agent_framework.Agent` + `get_llm_client()` (Azure AI Foundry Agent Service in production) |
| Model | Configured via `llm_provider.py` — priority order: Azure OpenAI → Gemini → Mistral → Novita → Groq → NVIDIA → OpenRouter → HuggingFace |
| Invocation | Once per code, at Node 5 inside the MAF loop |
| Input | Structured payload assembled by the MAF orchestrator |
| Output | Structured verdict JSON |

**Layer 1 — System Prompt (Always-On, Cached Server-Side)**
Contains CMS ICD-10-CM Official Guidelines Sections I.A, I.B, II, III, and IV. These are universal rules the agent always knows. Key rules relevant to Chapter 1:
- I.A.3: Code to the highest level of specificity
- I.B.4: Report chronic conditions affecting patient care
- I.B.8: Report all documented conditions affecting management
- Section II (Inpatient): Sequence the principal diagnosis first
- Section IV (Outpatient): Do not code suspected conditions as confirmed

**Layer 2 — RAG on Azure Knowledge Base (On-Demand per Code)**
The agent searches the Knowledge Base using the disease name + synonyms from the payload. This retrieves Section I.C chapter-specific guidelines. Chapter 1 examples:
- I.C.1.a: HIV coding rules (B20 vs Z21 distinction)
- I.C.1.d: Sepsis coding rules (sequencing, severe sepsis, septic shock)
- I.C.1.e: MRSA coding rules

**Layer 3 — Neo4j Tabular Rules (In Payload, Pre-Fetched)**
The MAF orchestrator queries Neo4j BEFORE calling this agent. Results are in the payload. The agent does NOT query Neo4j directly.

**Input Payload Schema:**
```json
{
  "target_code": "A41.9",
  "target_code_type": "claimed | suggested | companion",
  "disease_name": "Sepsis, unspecified organism",
  "synonyms": ["Septicemia NOS"],
  "organisms": ["Staphylococcus aureus"],
  "all_claimed_codes": ["A41.9", "B20", "J18.9", "I10"],
  "full_code_queue_snapshot": ["B20", "J18.9", "I10"],
  "tabular_rules": {
    "EXCLUDES1": [{"target": "P36.9", "target_type": "DiseaseCode"}],
    "EXCLUDES2": [],
    "CODE_FIRST": [],
    "CODE_ALSO": [],
    "USE_ADDITIONAL_CODE": [{"target": "B95-B97", "target_type": "CodeRange"}]
  },
  "evidence_db": {}
}
```

> IMPORTANT additions vs previous version:
> - target_code_type tells the agent whether this code was claimed by the doctor, suggested by under-coding detection, or added as a companion code
> - organisms array from Neo4j HAS_SEARCH_TERM nodes
> - full_code_queue_snapshot so the agent can see what other codes remain to be processed

**Output Verdict Schema:**
```json
{
  "code": "A41.9",
  "decision": "VALID | INVALID | SWAP | ADD_COMPANION",
  "rationale": "Plain language reason citing the specific rule and evidence",
  "chart_evidence": "Exact verbatim quote from the Evidence DB",
  "coding_rule": "The specific Neo4j Tabular Rule or RAG Guideline applied",
  "swap_to": "code string or null",
  "companion_codes_required": ["B96.1"],
  "sequencing_position": "principal | secondary | null",
  "warnings": ["list of non-blocking advisory notes"]
}
```

> IMPORTANT additions vs previous version:
> - companion_codes_required is now an array (a single code can require multiple companions)
> - sequencing_position: the agent must declare whether this code should be principal or secondary
> - warnings: non-blocking notes (e.g., "Consider querying physician for specificity")

**Runtime Anti-Fabrication & Relevance Guards (Orchestrator Enforcement):**
Upon receiving the Validator's output, the MAF Orchestrator enforces a **4-Stage Guard** (`backend/orchestrator.py` + `backend/guardrails.py`):
1. **Numeric Verbatim Guard (Guard 1):** Extracts `<>=` and numbers from `chart_evidence`. Ensures exact match in the Evidence DB to prevent hallucinated mathematical logic (e.g., "CD4 < 50" passing when chart says "CD4 50").
2. **Clinical Fuzzy Guard (Guard 2):** Ensures the non-numeric text is a verbatim substring or >70% fuzzy match against the Evidence DB corpus. Combined with Guard 1 inside `verify_clinical_grounding()`.
3. **Semantic Alignment Guard (Guard 3):** An LLM-as-a-judge call (`verify_evidence_alignment()` in `guardrails.py`) checks if the `chart_evidence` clinically supports the target diagnosis and decision, preventing the "evidence-relevance gap". AMBIGUOUS outcomes skip the retry and route directly to Manual Review.
4. **Guideline Citation Guard (Guard 4):** Extracts the cited guideline section from `coding_rule` (e.g., `I.C.1.a.2`) and verifies it exists in the retrieved RAG text or Universal System Prompt (`verify_guideline_grounding()`).
*Any guard failure triggers a 1-time retry with corrective feedback injected into the system prompt. Failure on retry routes to Manual Review and logs to `insights/telemetry_logs.jsonl`.*

---

## 2. MAF Graph State Schema

```python
class ClaimValidationState(TypedDict):
    # IMMUTABLE INPUT (set at Node 0, never mutated afterward)
    raw_claimed_codes: list[str]
    evidence_db: dict

    # MUTABLE QUEUE STATE
    code_queue: list[dict]          # {"code": str, "type": "claimed|suggested|companion|swap"}
    processed_codes: list[str]      # Loop guard: codes already evaluated
    iteration_count: int            # Hard cap counter (max 20)

    # MUTABLE OUTPUT STATE
    validated_sequence: list[dict]  # Accepted codes with sequencing_position
    dropped_codes: list[dict]       # Dropped codes with justification
    suggested_additions: list[dict] # Codes added by under-coding or USE_ADDITIONAL_CODE
    audit_report: list[dict]        # Full justification table rows (all codes, all decisions)
    tabular_rules_by_code: dict[str, dict]  # Stores Neo4j rules per code for Rule Engine (Node 7)

    # LIVE ORCHESTRATION FIELDS (per-node working state — set/read by individual nodes)
    current_node: str               # Name of the next node to execute
    current_target_code: str | None # Code currently being validated
    current_target_type: str | None # Type of current code: claimed|suggested|companion|swap
    current_tabular_rules: dict | None  # Neo4j result for current_target_code
    current_rag_guidelines: str | None  # ChromaDB RAG result for current_target_code
    current_verdict: Any | None     # Raw ValidatedCode from Validator Agent
    current_retries: int            # Guard retry counter for current code (max 1)
```

---

## 3. MAF Graph: Nodes, Edges, and Loop Conditions

### Node 0: INITIALIZE
**Purpose:** Set up initial state.
**Actions:**
1. Accept doctor's submitted codes and medical chart
2. Call Azure Document Intelligence for OCR
3. Call Extractor Agent to produce evidence_db
4. Populate code_queue with all claimed codes (type = "claimed")
5. Set processed_codes = [], iteration_count = 0

**Edge:** Always go to Node 1

---

### Node 1: UNDER_CODING_CHECK
**Purpose:** Find conditions documented in the chart that the doctor forgot to code.
**Actions:**
1. Extract all diagnosis keys from evidence_db.diagnoses where confirmed = true OR status = "History of"
2. For each diagnosis name, check if it already matches a code in raw_claimed_codes by:
   a. First: check if the diagnosis name appears as a disease_name or synonym for any already-claimed code (avoid false positives)
   b. **Family Masking Boundary Guard**: Check if a claimed code shares the same 3-character family prefix (e.g. `A41`). If so, SKIP this term. The Specificity Engine (Node 3) will handle intra-family upgrades.
   c. If no match found and no family collision: query Neo4j ClinicalTerm nodes:
      ```cypher
      MATCH (d:DiseaseCode)-[:HAS_INCLUDE]->(t:ClinicalTerm)
      WHERE toLower(t.term) CONTAINS toLower($diagnosis_name)
      AND d.billable = true
      RETURN d.code, d.description
      LIMIT 5
      ```
   d. If Neo4j returns a matching billable code AND that code is not already in raw_claimed_codes: push to code_queue with type = "suggested"
   e. If Neo4j returns NO match: do NOT push anything. The AI must never guess an ICD code.

**HARD RULE:** A clinical term is only pushed to the queue if Neo4j confirms a matching billable DiseaseCode exists AND it belongs to a completely un-claimed 3-character family. No exceptions.

**Edge:** Always go to Node 2

---

### Node 2: QUEUE_ROUTER
**Purpose:** Decide whether to continue looping or finish.
**Checks (in order):**
1. If iteration_count >= 20: go to Node 7 (emergency stop, flag claim for manual review)
2. If code_queue is empty: go to Node 7 (normal completion)
3. If code_queue has items: go to Node 3

---

### Node 3: NEO4J_QUERY
**Purpose:** Fetch all tabular rules and clinical terms for the next code.
**Actions:**
1. Pop the next item from code_queue (preserving its type: claimed/suggested/companion)
2. Add its code to processed_codes
3. Increment iteration_count by 1
4. Query Neo4j:
   a. Verify code exists: MATCH (d:DiseaseCode {code: $code}) RETURN d
   b. If code not found in Neo4j: immediately add to dropped_codes with reason "Code not found in knowledge graph", go to Node 2
   c. If billable = false: immediately add to dropped_codes with reason "Non-billable parent code — requires more specific child code", go to Node 2
   d. Fetch description (disease_name)
   e. Fetch HAS_INCLUDE synonyms (where category IS NULL)
   f. Fetch HAS_SEARCH_TERM organisms (where category = "organism")
   g. Fetch all tabular rule relationships: EXCLUDES1, EXCLUDES2, CODE_FIRST, CODE_ALSO, USE_ADDITIONAL_CODE
   h. Use coalesce(target.code, target.range) for ALL relationship targets

**Edge (normal):** Go to Node 4
**Edge (code not found / not billable):** Go to Node 2

---

### Node 4: PAYLOAD_ASSEMBLER
**Purpose:** Build the structured payload for the Validation Agent.
**Actions:**
1. Package: target_code + target_code_type + disease_name + synonyms + organisms + all_claimed_codes + full_code_queue_snapshot + tabular_rules + evidence_db

**Edge:** Always go to Node 5

---

### Node 5: VALIDATION_AGENT_CALL
**Purpose:** Call the Azure AI Foundry Validation Agent.
**Actions:**
1. Send the payload to the pre-configured Azure AI Foundry Agent
2. The agent internally uses: System Prompt (Layer 1) + RAG search on Knowledge Base (Layer 2) + tabular_rules from payload (Layer 3)
3. Receive the structured verdict JSON
4. Validate that the verdict contains all mandatory fields (decision, justification, evidence_used, guideline_basis). If any are missing, reject the verdict and flag for manual review.

**Edge:** Always go to Node 6

---

### Node 6: DECISION_ROUTER
**Purpose:** Route the verdict to the correct MAF state update.

**Decision: VALID**
- Append code to validated_sequence with sequencing_position
- Append full verdict to audit_report
- Go to Node 2

**Decision: INVALID**
- Append code to dropped_codes with justification
- Append full verdict to audit_report
- Go to Node 2

**Decision: SWAP**
- Append original code to dropped_codes with justification
- If verdict.swap_to is NOT in processed_codes: push it to code_queue with type = "companion"
- Append full verdict to audit_report
- Go to Node 2

**Decision: ADD_COMPANION**
- Append current code to validated_sequence (it is VALID, just incomplete)
- For each code in verdict.companion_codes_required:
  - RESOLVING CodeRange TARGETS (CRITICAL):
    If the companion is a CodeRange (e.g., "B95-B97"), do NOT push the range string.
    Instead, the MAF code must resolve the range to a specific billable code by:
    a. Check the evidence_db.organism field
    b. Query Neo4j: find the specific DiseaseCode within that range whose ClinicalTerms match the documented organism
       ```cypher
       MATCH (d:DiseaseCode)-[:HAS_INCLUDE|HAS_SEARCH_TERM]->(t:ClinicalTerm)
       WHERE d.code >= $range_start AND d.code <= $range_end
       AND d.billable = true
       AND toLower(t.term) CONTAINS toLower($organism_from_evidence)
       RETURN d.code, d.description
       LIMIT 1
       ```
    c. If a specific code is found: push THAT code to code_queue (e.g., B96.1 instead of B95-B97)
    d. If no specific code found: push the range start as a general code, add a warning to audit_report
  - If the companion code is NOT in processed_codes: push to code_queue with type = "companion"
- Append full verdict to audit_report
- Go to Node 2

**LOOP GUARD:** Before pushing ANY code to code_queue, check processed_codes. If already processed, skip silently.

---

### Node 7: COMPILE_OUTPUT (Tabular Rule Engine)
**Purpose:** Execute deterministic tabular reconciliation and assemble the final audit report.
**Module:** `backend/rule_engine.py` (`reconcile_claim_rules`)
**Actions:**
1. **EXCLUDES1 Enforcement:** Cross-evaluate all candidate codes pairwise against Neo4j `EXCLUDES1` rules. If mutually exclusive (e.g. active HIV `B20` vs asymptomatic HIV `Z21`), drop the secondary/unsupported code and log violation.
2. **CODE_FIRST Dependency & Sequencing:** Verify required etiology/underlying condition codes are present in the claim. Promote underlying condition to `principal` and sequence manifestation codes as `secondary`. If mandatory dependency is missing, mark code `INVALID`.
3. **USE_ADDITIONAL_CODE Companion Audit:** Evaluate if required companion codes/ranges (e.g. `B95-B97` organism codes) are present. If missing, mark supported codes as `INCOMPLETE` with mandatory companion warnings.
4. **Advisory Notes:** Compile `EXCLUDES2` and `CODE_ALSO` notes into audit trail.
5. **Output Generation:** Merge `validated_sequence`, `dropped_codes`, and `audit_report`. Save audit reports to `insights/audit_reports/` and log telemetry to `insights/telemetry_logs.jsonl`.

---

## 4. Rule Hierarchy (What Overrides What)

When the three layers produce conflicting signals, apply this priority:

```
Priority 1 (HIGHEST): EXCLUDES1 (Neo4j Tabular Rule)
  Hard veto. If BOTH codes appear in validated_sequence, one MUST be dropped.
  IMPORTANT: The check is against validated_sequence (what the system has accepted so far),
  NOT against evidence_db (what the chart says). Two diseases can coexist
  clinically but still be mutually exclusive for CODING purposes.
  No guideline can override an EXCLUDES1 violation.

Priority 2: CODE_FIRST (Neo4j Tabular Rule)
  Sequencing mandate. The target code must appear BEFORE the source code
  in the final validated sequence. If the target code is missing entirely,
  flag the current code as incomplete.
  Example: R65.20 has CODE_FIRST pointing to A41.9. So A41.9 MUST appear
  before R65.20 in the output.

Priority 3: USE_ADDITIONAL_CODE (Neo4j Tabular Rule)
  Mandatory companion. If the companion code (or a code within the
  specified CodeRange) is absent from the claim, the system must
  attempt to add it. If it cannot be resolved, flag as incomplete.

Priority 4: Section I.C Chapter-Specific Guidelines (RAG / Knowledge Base)
  Disease-specific narrative rules. CAN override a code's validity
  even if Neo4j has no objection.
  Example: B20 is valid per Neo4j (no EXCLUDES1 triggered), but the
  I.C.1.a.2 guideline says "use Z21 for asymptomatic HIV" — so
  the guideline causes a SWAP.

Priority 5: Sections I.A-IV Universal Guidelines (System Prompt)
  Always-on rules. Covers specificity, sequencing, outpatient vs inpatient.
  Applied as a baseline to every code.

Priority 6 (LOWEST): Evidence (Evidence DB)
  The final ground truth. A code that passes all 5 layers above but
  has NO supporting evidence in the Evidence DB (no source_quote) is
  still DROPPED. Evidence is not "lowest priority" in importance —
  it is the last check that catches everything else.
```

---

## 5. Chapter 1 Test Cases (Traced Through the Pipeline)

These test cases were used to validate this spec. They expose edge cases in EXCLUDES1, CODE_FIRST, SWAP, CodeRange resolution, and under-coding.

---

### Test Case 1: Sepsis with Severe Sepsis and Missing Organism
**Claimed Codes:** A41.9, R65.20
**Evidence DB:** Sepsis confirmed, severity = "Severe", organism = "MRSA", organ_dysfunction = ["Acute kidney failure"]

**Trace:**
- Node 1 (Under-coding): No extra diagnoses found beyond what is claimed.
- Node 3 (A41.9): Neo4j returns USE_ADDITIONAL_CODE pointing to CodeRange B95-B97.
- Node 5 (Agent validates A41.9): VALID. Decision = ADD_COMPANION. companion_codes_required = ["B95-B97"]. sequencing_position = "principal".
- Node 6: CodeRange "B95-B97" must be resolved. Evidence says organism = "MRSA". Neo4j query finds B95.62 (MRSA) as a billable match. Push B95.62 to queue.
- Node 3 (R65.20): Neo4j returns CODE_FIRST pointing to A41.9. A41.9 is already in validated_sequence. Sequencing check passes.
- Node 5 (Agent validates R65.20): VALID. sequencing_position = "secondary" (must come after A41.9).
- Node 3 (B95.62): Validated as companion. VALID.
- Final sequence: A41.9 -> R65.20 -> B95.62

**Gaps this exposed:**
- CodeRange resolution logic was completely missing from the previous spec
- organ_dysfunction field was missing from Evidence DB schema
- CODE_FIRST validation must check validated_sequence, not just all_claimed_codes

---

### Test Case 2: B20 (HIV) When Patient Is Asymptomatic
**Claimed Codes:** B20
**Evidence DB:** HIV confirmed = true, status = "Asymptomatic", source_quote = "Known HIV positive, CD4 620, asymptomatic."

**Trace:**
- Node 3 (B20): Neo4j returns EXCLUDES1 pointing to Z21. But Z21 is NOT in all_claimed_codes. No EXCLUDES1 violation.
- Node 5 (Agent validates B20): Agent RAGs Knowledge Base for "HIV Disease". Retrieves guideline I.C.1.a.2: "Do not assign B20 if patient is asymptomatic. Assign Z21." Evidence says asymptomatic. Decision = SWAP. swap_to = "Z21".
- Node 6: B20 dropped. Z21 pushed to queue.
- Node 3 (Z21): Neo4j returns EXCLUDES1 pointing to B20. B20 is in all_claimed_codes BUT it was already dropped. The EXCLUDES1 check must look at validated_sequence (current accepted codes), NOT all_claimed_codes. B20 is in dropped_codes, not validated_sequence. No conflict.
- Node 5 (Agent validates Z21): VALID.
- Final sequence: Z21

**Gaps this exposed:**
- EXCLUDES1 must check against validated_sequence (currently accepted codes), NOT raw_claimed_codes. A dropped code no longer counts.
- Updating Priority 1 definition in Rule Hierarchy to reflect this.

---

### Test Case 3: Both B20 AND Z21 Claimed (EXCLUDES1 Mutual Exclusion)
**Claimed Codes:** B20, Z21
**Evidence DB:** HIV confirmed, status = "Active, symptomatic, history of AIDS."

**Trace:**
- Node 3 (B20): Neo4j returns EXCLUDES1 pointing to Z21. Z21 IS in all_claimed_codes. EXCLUDES1 fires.
- Node 5 (Agent): Detects EXCLUDES1 conflict. Evidence says symptomatic + history of AIDS. Per guideline I.C.1.a.2: once a patient has had an HIV-related illness, always assign B20. Decision = VALID for B20. But agent must also flag Z21 for removal.
  Actually: the agent only validates the TARGET code (B20). It reports the EXCLUDES1 conflict in its verdict. The MAF code (Node 6) handles the consequence:
  - B20 is VALID.
  - Z21 is flagged: when Node 3 later processes Z21, the EXCLUDES1 check against validated_sequence (which now contains B20) will trigger. The agent will return INVALID for Z21.
- Final sequence: B20

**Gaps this exposed:**
- The EXCLUDES1 check happens at two points: (1) when the agent receives the payload (it sees the conflict), and (2) when the conflicting code is later processed (its own EXCLUDES1 check catches the accepted code). The spec must clarify this is a TWO-PASS safety net, not a one-shot check.

---

### Test Case 4: Tuberculosis with CODE_FIRST (Manifestation Sequencing)
**Claimed Codes:** A18.01 (Tuberculosis of spine), M49.82 (TB spondylitis, cervical)
**Evidence DB:** TB spine confirmed, source_quote = "MRI confirms spinal TB at C4-C5 level."

**Trace:**
- Node 3 (A18.01): Neo4j returns CODE_ALSO or relationship data.
- Node 5 (Agent validates A18.01): VALID. This is the underlying TB infection.
- Node 3 (M49.82): Neo4j returns CODE_FIRST pointing to A18.01. A18.01 is already in validated_sequence. Sequencing check passes. Agent validates: VALID, sequencing_position = "secondary" (must come after A18.01).
- But what if M49.82 was processed BEFORE A18.01? The CODE_FIRST target (A18.01) is not yet in validated_sequence. The agent cannot confirm sequencing.
  SOLUTION: The agent returns VALID but sets sequencing_position = "secondary (pending: requires A18.01 before it)". Node 7 (COMPILE_OUTPUT) enforces the final sort order.
- Final sequence: A18.01 -> M49.82

**Gaps this exposed:**
- CODE_FIRST enforcement cannot happen fully at Node 5/6 because the target code may not have been processed yet. Node 7 must do a FINAL sequencing pass.
- Node 7 must verify all CODE_FIRST dependencies are satisfied in the final sorted sequence.

---

### Test Case 5: Under-Coding Detection — Diabetes in Medical History
**Claimed Codes:** A41.9 (Sepsis)
**Evidence DB:** Sepsis confirmed. Additionally: diagnoses includes "Type 2 Diabetes" with status = "History of", source_quote = "PMH: Type 2 Diabetes, diagnosed 2018, diet-controlled."

**Trace:**
- Node 1 (Under-coding check): Evidence DB has "Type 2 Diabetes" (confirmed, history of). No Diabetes code in raw_claimed_codes.
- Neo4j ClinicalTerm lookup: MATCH (d:DiseaseCode)-[:HAS_INCLUDE]->(t:ClinicalTerm) WHERE toLower(t.term) CONTAINS 'diabetes' AND d.billable = true RETURN d.code
- Neo4j returns E11.9 (Type 2 diabetes mellitus without complications). E11.9 is NOT in Chapter 1 (A00-B99).

**CRITICAL ISSUE:** Our Neo4j pilot only has Chapter 1 (A00-B99). E11.9 is in Chapter 4 (E00-E89). The ClinicalTerm lookup WILL FAIL because E11.9 does not exist in our graph yet.

**SOLUTION:** Under-coding detection is limited to the scope of the Neo4j graph. For the pilot, it can only catch missing Chapter 1 codes. This is expected and acceptable for a proof of concept. The AGENT_SPEC must document this limitation explicitly.

**For the pilot demo: use a Chapter 1 under-coding example instead.** For example: doctor claims A41.9 (Sepsis) but the chart also documents "Patient has chronic Hepatitis B" — which maps to B18.1 (a Chapter 1 code that WOULD exist in our graph).

---

## 6. Hard Constraints (Medicolegal Rules — Never Violate)

1. **The AI does not practice medicine.** The Extractor Agent must never add a diagnosis inferred from lab values, vitals, or symptom patterns. Only clinician-documented conditions are valid.

2. **Under-coding only catches clerical omissions.** A missing code is only suggested if (a) a clinician explicitly documented the condition AND (b) Neo4j confirms a matching billable code in the current graph scope. The AI never creates a diagnosis.

3. **Under-coding is limited to Neo4j scope.** In the pilot (Chapter 1 only), under-coding detection can only find missing A00-B99 codes. Conditions outside this range (e.g., Diabetes E11, Hypertension I10) will not be caught until those chapters are added to Neo4j.

4. **No RAG on the medical chart.** Raw patient chart text is never vectorized. The Evidence DB (Pydantic JSON with source_quotes) is the only searchable representation of the chart.

5. **Every decision must be explainable.** The justification, evidence_used, and guideline_basis fields in the verdict are mandatory. Any verdict missing these is rejected.

6. **The code must exist in Neo4j.** A code not found in Neo4j or with billable = false is rejected immediately at Node 3.

7. **EXCLUDES1 is checked against validated_sequence (accepted codes), not raw_claimed_codes.** A code that has been dropped or swapped no longer triggers EXCLUDES1 conflicts.

8. **CodeRange targets must be resolved to specific billable codes.** The MAF code must never push a CodeRange string (like "B95-B97") into the queue. It must resolve it to a specific code (like B95.62) using the organism from the Evidence DB.

9. **CODE_FIRST sequencing is enforced at Node 7 (final output), not just at validation time.** Because codes may be processed out of order, the final COMPILE_OUTPUT step must verify all CODE_FIRST dependencies are satisfied in the output sequence.

---

## 7. Technology Stack (Runtime)

| Component | Technology | Node in MAF Graph |
|---|---|---|
| OCR | Azure Document Intelligence | Node 0 |
| Evidence Extraction | GPT-5.4 + Pydantic | Node 0 |
| Orchestrator | Microsoft Agent Framework (MAF) SDK v1.0 | All nodes |
| Tabular Rules | Neo4j (Cypher queries) | Node 1 + Node 3 |
| Agent Reasoning | Azure AI Foundry Validation Agent | Node 5 |
| Universal Guidelines | System Prompt (Prompt Caching) | Node 5 via Agent |
| Chapter Guidelines | Azure Knowledge Base (Vector RAG) | Node 5 via Agent |
| API Layer | FastAPI on Azure Container Apps | Post Node 7 |

---

## 8. Cross-References

| Topic | File |
|---|---|
| Neo4j full schema and ingestion | agent_docs/DATA_GENERATION_ARCHITECTURE.md |
| Cypher query patterns | agent_docs/Agent_API_Reference.md |
| Defense Q and A for presentations | agent_docs/Architecture_QA_Guide.md |
| Project context for new sessions | PROJECT_CONTEXT.md |
| End-to-end architecture diagrams & sequence diagrams | agent_docs/FINAL_ARCHITECTURE.md |
| Core architecture overview | agent_docs/FINAL_ARCHITECTURE.md |
