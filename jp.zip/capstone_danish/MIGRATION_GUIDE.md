# 🚀 Project Migration & Handoff Guide

**Target Audience:** The AI Agent and Developer resuming work on the new office laptop.
**Purpose:** This document provides absolute context on what was recently completed, how the architecture is currently configured, and the exact steps required to spin up the project on the new machine.

---

## 1. Current Project State (What is Done)

The application is in a highly polished, cloud-ready state. The core functional loop (PDF Upload -> Extraction -> LLM Validation -> SME Human Review -> PDF Export) is fully operational.

### Recent Major Implementations:
- **SME Human-in-the-Loop Dashboard:** 
  - Located at `frontend/app/audit/[jobId]/page.tsx`.
  - Supports overriding, swapping, and rejecting AI decisions. 
  - Gracefully handles overrides with unknown codes (falls back gracefully instead of crashing).
  - Remembers unmodified rows when the user clicks "Save SME Overrides" without wiping historical decisions.
- **Formal PDF Export:** 
  - Added `@media print` CSS to `frontend/app/globals.css` to format the audit table as a pristine, printable medical report. 
  - Dynamically grabs the original patient chart filename for the exported PDF.
- **API & Orchestration Cleanup:** 
  - The local `proxy_server.py` was strictly refactored to ONLY route to Mistral AI (`mistral-large-latest`). All other legacy providers (Groq, Gemini, NVIDIA) were permanently removed to prevent hallucinated routing.
  - Azure OpenAI (GPT-4o) remains natively supported for production.
- **Dual-Mode Cloud Fallbacks:** 
  - Storage (`api/blob_service.py`) and Cosmos ETL (`etl_pipeline_cosmos.py`) check for Azure Key Vault (`AZURE_KEY_VAULT_URL`). If inaccessible or unconfigured, they gracefully degrade to pulling credentials directly from the local `.env`.
  - If no Azure Storage string is found, blob storage defaults to the local `api/sessions/` directory.
- **Azure Cosmos DB Vector Ingestion:** 
  - Built a dedicated Azure ETL script (`data/guideline_data/vector_db_creator/etl_pipeline_cosmos.py`) utilizing `pymongo` and Azure OpenAI Embeddings to natively populate Cosmos DB for MongoDB (vCore).

---

## 2. What to Migrate (And What Stays Behind)

The repository is configured with a strict `.gitignore`. You do **not** need to manually filter files when transferring the codebase via Git.

- **Migrated via Git:** 
  - Full `frontend/` and `api/` source code.
  - `requirements.txt` and `package.json`.
  - Context files (`PROJECT_CONTEXT.md`, `DATA_ARCHITECTURE.md`, `MIGRATION_GUIDE.md`).
- **Ignored (Will NOT migrate):**
  - `.env` (You must recreate this on the office laptop).
  - `api/sessions/` (Local PDFs and JSON reports are left behind to preserve data privacy).
  - `__pycache__`, `venv`, `node_modules`.

---

## 3. How to Spin Up on the Office Laptop

To the AI Agent spinning this up on the new machine: follow these exact steps.

### Step 1: Environment Variables
Create a new `.env` file in the root directory. Because the system supports dual-mode fallbacks, you can securely run the app without Azure Key Vault access for now.

Populate the `.env` with:
```env
# 1. Neo4j Credentials (Required for Knowledge Graph)
NEO4J_URI=neo4j+s://...
NEO4J_USERNAME=...
NEO4J_PASSWORD=...

# 2. Azure Storage & Cosmos DB Fallback (Optional - Key Vault is preferred)
AZURE_STORAGE_CONNECTION_STRING=...
COSMOS_DB_CONNECTION_STRING=...

# 3. LLM & Embeddings Credentials
MISTRAL_API_KEY=...             # For local proxy testing
AZURE_OPENAI_KEY=...            # For production
AZURE_OPENAI_ENDPOINT=...
AZURE_OPENAI_DEPLOYMENT=gpt-4o
AZURE_OPENAI_EMBEDDING_DEPLOYMENT=text-embedding-3-small

# 4. Azure Document Intelligence (OCR)
AZURE_DOCUMENT_INTELLIGENCE_ENDPOINT=...
AZURE_DOCUMENT_INTELLIGENCE_KEY=...
```

### Step 2: Install Backend Dependencies
The Python environment is completely defined.
```bash
python -m venv venv
source venv/Scripts/activate   # On Windows
pip install -r requirements.txt
```

### Step 3: Install Frontend Dependencies
The Next.js environment requires a clean install.
```bash
cd frontend
npm install
```

### Step 4: Run the Services
You need to start three distinct services:
1. **The Backend API:** `uvicorn api.main:app --reload --port 8000`
2. **The LLM Proxy:** `python proxy_server.py` (Runs on port 8001)
3. **The Frontend UI:** `cd frontend && npm run dev` (Runs on port 3000)

---

## 4. Next Steps & Agent Directives

**To the AI Agent:** When you read this on the new machine, your immediate priorities are:
1. Verify the `.env` file is populated.
2. Confirm the Neo4j instance is accessible from the office network.
3. Validate that `api/sessions/` is created upon the first PDF upload (if not using Azure Blob).
4. To populate the Azure Cosmos DB vector store, run `python data/guideline_data/vector_db_creator/etl_pipeline_cosmos.py`.
5. The user may ask you to implement **Optimistic Concurrency Control** (checking `last_modified` timestamps) on the `PATCH /jobs/{jobId}/report` endpoint to prevent simultaneous SMEs from overwriting each other's work. This was flagged as a highly recommended next step.
