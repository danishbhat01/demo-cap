"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import styles from "./page.module.css";

export default function LoginPage() {
  const router = useRouter();
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setLoading(true);

    // Dummy validation
    if (username === "admin" && password === "admin") {
      // Set a cookie (document.cookie works fine here for a dummy auth)
      document.cookie = "auth-token=true; path=/; max-age=86400"; // 1 day expiry
      router.push("/");
    } else {
      setError("Invalid credentials. Try admin / admin.");
      setLoading(false);
    }
  };

  return (
    <div className={styles.wrapper}>
      <div className={`glass-card ${styles["login-card"]}`}>
        <div className={styles.header}>
          <div className={styles["logo-icon"]}>⚕</div>
          <h1 className={styles.title}>ClinAudit AI</h1>
          <p className={styles.subtitle}>Administrative Portal Login</p>
        </div>

        <form className={styles.form} onSubmit={handleLogin}>
          {error && <div className={styles["error-msg"]}>{error}</div>}

          <div className={styles["input-group"]}>
            <label className={styles.label} htmlFor="username">Admin ID</label>
            <input
              id="username"
              type="text"
              className={styles.input}
              placeholder="Enter admin ID"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              required
            />
          </div>

          <div className={styles["input-group"]}>
            <label className={styles.label} htmlFor="password">Password</label>
            <input
              id="password"
              type="password"
              className={styles.input}
              placeholder="Enter password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
            />
          </div>

          <button
            type="submit"
            className={`btn-primary ${styles["submit-btn"]}`}
            disabled={loading}
          >
            {loading ? "Authenticating..." : "Secure Login"}
          </button>
        </form>
      </div>
    </div>
  );
}
