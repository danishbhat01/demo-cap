"use client";
import { useState, useEffect, useRef, useCallback } from "react";
import Link from "next/link";
import { useParams, useRouter } from "next/navigation";
import dynamic from "next/dynamic";
import styles from "./page.module.css";

const PdfViewer = dynamic(() => import('./PdfViewer'), {
  ssr: false,
  loading: () => (
    <div className={styles["center-state"]}>
      <div className={styles.spinner} />
      <span>Loading viewer engine…</span>
    </div>
  )
});

const API = process.env.NEXT_PUBLIC_API_URL ?? "http://localhost:8000";

/* ─── Types ─────────────────────────────────────────────────────────────── */
interface Stage { name: string; label: string; status: string; elapsed_seconds?: number; }
interface StatusPayload {
  status: string; progress: number; stage: string | null;
  current_agent: string | null; elapsed_seconds: number | null;
  stages: Stage[]; error_message: string | null;
}
interface AuditEntry {
  code: string; decision: string; final_status?: string; rationale: string;
  chart_evidence: string; coding_rule: string;
  description?: string; disease_name?: string;
  swap_to?: string; companion_codes_required?: string[];
  sequencing_position?: string; warnings?: string[];
  reconciliation_notes?: string[];
  clinical_evaluation?: {
    code?: string;
    decision?: string;
    description?: string;
    disease_name?: string;
    rationale?: string;
    chart_evidence?: string;
    coding_rule?: string;
    swap_to?: string;
    companion_codes_required?: string[];
  };
  sme_reviewed?: boolean;
  sme_decision?: string;
  sme_override_code?: string;
  sme_notes?: string;
}
interface Report {
  job_id: string; claimed_codes: string[];
  validated_sequence: { code: string; sequencing_position: string; status?: string }[];
  audit_entries: AuditEntry[];
  dropped_codes: { code: string; reason: string; status?: string }[];
  suggested_additions: { code: string; reason: string }[];
  generated_at: string;
}

interface TableRowItem {
  code: string;
  description: string;
  clinical_decision: string;
  final_status: string;
  action_taken: string;
  coding_rule: string;
  rationale: string;
  chart_evidence: string;
  sme_reviewed?: boolean;
  sme_decision?: string;
  sme_override_code?: string;
  sme_notes?: string;
}

/* ─── Known Code Descriptions Dictionary for Fallback ─────────────────── */
const CODE_DESCRIPTIONS: Record<string, string> = {
  "A41.9": "Sepsis, unspecified organism",
  "A41.02": "Sepsis due to Methicillin-resistant Staphylococcus aureus",
  "B95.62": "Methicillin-resistant Staphylococcus aureus as cause of diseases",
  "B20": "Human immunodeficiency virus [HIV] disease",
  "Z21": "Asymptomatic human immunodeficiency virus [HIV] infection status",
  "B59": "Pneumocystosis (Pneumocystis jirovecii pneumonia)",
  "J96.01": "Acute respiratory failure with hypoxia",
  "N17.9": "Acute kidney failure, unspecified",
  "A18.01": "Tuberculosis of spine (Pott's disease)",
  "M49.82": "Tuberculosis of spine, cervical region",
  "B18.2": "Chronic viral hepatitis C",
  "B18.1": "Chronic viral hepatitis B without delta-agent",
  "R65.20": "Severe sepsis without septic shock",
};

/* ─── Stage Icon ─────────────────────────────────────────────────────────── */
function stageIcon(status: string) {
  if (status === "completed") return "✓";
  if (status === "running")   return "⟳";
  if (status === "failed")    return "✗";
  return "○";
}

/* ─── Decision chip ──────────────────────────────────────────────────────── */
function DecisionChip({ decision }: { decision: string }) {
  const norm = decision.toUpperCase();
  let cls = "chip-queued";
  if (norm.includes("VALID") && !norm.includes("INVALID")) {
    cls = "chip-valid";
  } else if (norm.includes("INVALID") || norm.includes("DROPPED")) {
    cls = "chip-invalid";
  } else if (norm.includes("SWAP")) {
    cls = "chip-swap";
  } else if (norm.includes("INCOMPLETE")) {
    cls = "chip-incomplete";
  } else if (norm.includes("COMPANION")) {
    cls = "chip-companion";
  } else if (norm.includes("MANUAL") || norm.includes("SCOPE")) {
    cls = "chip-manual";
  }
  return <span className={`chip ${cls}`}>{decision}</span>;
}

/* ─── Build unified table rows ───────────────────────────────────────────── */
function buildTableRows(report: Report): TableRowItem[] {
  const rows: TableRowItem[] = [];
  const processedCodes = new Set<string>();

  for (const entry of report.audit_entries || []) {
    processedCodes.add(entry.code);

    const clinDec = entry.clinical_evaluation?.decision || entry.decision || "VALID";
    
    let finalStatus = entry.final_status || entry.decision || "VALID";
    if (finalStatus === "VALID") finalStatus = "VALID (Kept)";
    else if (finalStatus === "INVALID") finalStatus = "INVALID (Dropped)";
    else if (finalStatus === "SWAP") finalStatus = "SWAP";
    else if (finalStatus === "INCOMPLETE") finalStatus = "INCOMPLETE (Missing Companion)";
    else if (finalStatus.toUpperCase().includes("MANUAL")) finalStatus = "Manual Review Required";

    let actionTaken = "Keep in sequence";
    if (entry.swap_to) {
      const targetDesc = CODE_DESCRIPTIONS[entry.swap_to] ? ` (${CODE_DESCRIPTIONS[entry.swap_to]})` : "";
      actionTaken = `Swap to ${entry.swap_to}${targetDesc}`;
    } else if (entry.final_status === "SWAP" || clinDec === "SWAP") {
      actionTaken = "Route to Manual Review (Unverified Specificity Swap)";
    } else if (entry.final_status === "INVALID" || clinDec === "INVALID" || finalStatus.includes("INVALID")) {
      actionTaken = entry.reconciliation_notes?.[0] || "Dropped (Redundant / Excluded)";
    } else if (finalStatus.includes("Manual") || entry.final_status === "MANUAL_REVIEW") {
      actionTaken = "Route to Manual Review";
    } else if (entry.final_status === "INCOMPLETE") {
      actionTaken = entry.reconciliation_notes?.[0] || "Missing Mandatory Companion Code";
    } else if (entry.sequencing_position === "principal") {
      actionTaken = "Keep as Principal Diagnosis";
    } else if (entry.sequencing_position === "secondary") {
      actionTaken = "Keep as Secondary Diagnosis";
    } else if (entry.companion_codes_required && entry.companion_codes_required.length > 0) {
      actionTaken = `Add Companion: ${entry.companion_codes_required.join(", ")}`;
    }

    const desc = entry.description || entry.disease_name || entry.clinical_evaluation?.disease_name || CODE_DESCRIPTIONS[entry.code] || "—";

    rows.push({
      code: entry.code,
      description: desc,
      clinical_decision: clinDec,
      final_status: finalStatus,
      action_taken: actionTaken,
      coding_rule: entry.coding_rule || entry.clinical_evaluation?.coding_rule || "Official Coding Guideline",
      rationale: entry.rationale || entry.clinical_evaluation?.rationale || "",
      chart_evidence: entry.chart_evidence || entry.clinical_evaluation?.chart_evidence || "",
      sme_reviewed: entry.sme_reviewed,
      sme_decision: entry.sme_decision,
      sme_override_code: entry.sme_override_code,
      sme_notes: entry.sme_notes,
    });
  }

  for (const d of report.dropped_codes || []) {
    if (!processedCodes.has(d.code)) {
      processedCodes.add(d.code);
      const reasonLower = (d.reason || "").toLowerCase();
      const isScope = reasonLower.includes("scope") || reasonLower.includes("knowledge graph");
      const isAmbiguous = reasonLower.includes("ambiguous") || reasonLower.includes("fabrication") || reasonLower.includes("guard");
      const isManual = isScope || isAmbiguous || reasonLower.includes("manual") || d.status === "MANUAL_REVIEW";
      
      let rule = "Coding Rule Conflict";
      let action = "Dropped";
      if (isScope) {
        rule = "Out of Pilot Scope";
        action = "Route to Chapter Specialist Auditor";
      } else if (isAmbiguous) {
        rule = "Evidence Grounding / Guardrails";
        action = "Route to Auditor (Guardrail Review)";
      } else if (reasonLower.includes("excludes")) {
        rule = "Neo4j EXCLUDES Conflict";
        action = "Dropped (Exclusion Rule)";
      }

      rows.push({
        code: d.code,
        description: CODE_DESCRIPTIONS[d.code] || "—",
        clinical_decision: isScope ? "Out of Scope (Skipped)" : (isManual ? "Manual Review" : "INVALID"),
        final_status: isManual ? "Manual Review Required" : "INVALID (Dropped)",
        action_taken: action,
        coding_rule: rule,
        rationale: d.reason,
        chart_evidence: "",
      });
    }
  }

  return rows;
}



/* ─── Main Page ──────────────────────────────────────────────────────────── */
export default function AuditPage() {
  const { jobId } = useParams<{ jobId: string }>();
  const router = useRouter();

  const handleLogout = () => {
    document.cookie = "auth-token=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;";
    router.push("/login");
  };

  // ── SME Review Mode ────────────────────────────────────────────────────────
  const [reviewMode, setReviewMode] = useState(false);
  const [savingReview, setSavingReview] = useState(false);
  const [smeDecisions, setSmeDecisions] = useState<Record<string, { sme_decision: string; sme_override_code: string; sme_notes: string }>>({});

  const handleSmeChange = (code: string, field: string, value: string) => {
    setSmeDecisions(prev => ({
      ...prev,
      [code]: { ...(prev[code] ?? { sme_decision: 'APPROVE', sme_override_code: '', sme_notes: '' }), [field]: value }
    }));
  };

  const handleFinalizeReview = async () => {
    if (!report) return;
    setSavingReview(true);
    try {
      const entries = tableRows.map(row => {
        const sme = smeDecisions[row.code];
        return {
          code: row.code,
          sme_decision: sme?.sme_decision ?? row.sme_decision ?? 'APPROVE',
          sme_override_code: sme?.sme_override_code ?? row.sme_override_code ?? '',
          sme_notes: sme?.sme_notes ?? row.sme_notes ?? '',
        };
      });
      const res = await fetch(`${API}/jobs/${jobId}/report`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ entries, approved_at: new Date().toISOString() }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.detail ?? 'Failed to save review.');
      
      // Re-fetch report to update table UI immediately
      const rRes = await fetch(`${API}/jobs/${jobId}/report`);
      const rData = await rRes.json();
      setReport(rData);
      setReviewMode(false);
    } catch (err: unknown) {
      alert(err instanceof Error ? err.message : String(err));
    } finally {
      setSavingReview(false);
    }
  };

  const handleExportPdf = () => {
    if (!report) return;
    const originalTitle = document.title;
    const chartName = jobMeta?.chart_filename ?? jobId;
    document.title = `Audit_Report_${chartName}`;
    window.print();
    document.title = originalTitle;
  };
  // ──────────────────────────────────────────────────────────────────────────

  const [status, setStatus]   = useState<StatusPayload | null>(null);
  const [report, setReport]   = useState<Report | null>(null);
  const [jobMeta, setJobMeta] = useState<{ chart_filename?: string; claim_filename?: string } | null>(null);
  const [highlight, setHighlight] = useState<string>("");
  const [docView, setDocView] = useState<"chart" | "claim">("chart");
  const [error, setError]     = useState<string | null>(null);
  const pollingRef = useRef<NodeJS.Timeout | null>(null);

  const chartPdfUrl = `${API}/jobs/${jobId}/pdf/chart`;
  const claimPdfUrl = `${API}/jobs/${jobId}/pdf/claim`;
  const activePdfUrl = docView === "chart" ? chartPdfUrl : claimPdfUrl;

  /* Poll status */
  const pollStatus = useCallback(async () => {
    try {
      const res = await fetch(`${API}/jobs/${jobId}/status`);
      if (!res.ok) { setError("Job not found."); return; }
      const data: StatusPayload = await res.json();
      setStatus(data);
      if (data.status === "COMPLETED") {
        if (pollingRef.current) clearInterval(pollingRef.current);
        const rRes = await fetch(`${API}/jobs/${jobId}/report`);
        const rData: Report = await rRes.json();
        setReport(rData);
      } else if (data.status === "FAILED") {
        if (pollingRef.current) clearInterval(pollingRef.current);
      }
    } catch { setError("Failed to connect to API."); }
  }, [jobId]);

  useEffect(() => {
    fetch(`${API}/jobs/${jobId}`)
      .then(r => r.ok ? r.json() : null)
      .then(data => setJobMeta(data))
      .catch(console.error);

    pollStatus();
    pollingRef.current = setInterval(pollStatus, 3000);
    return () => { if (pollingRef.current) clearInterval(pollingRef.current); };
  }, [pollStatus]);

  /* Derived stats */
  const validCount    = report?.audit_entries.filter(e => e.decision === "VALID").length ?? 0;
  const invalidCount  = report?.audit_entries.filter(e => e.decision === "INVALID").length ?? 0;
  const swapCount     = report?.audit_entries.filter(e => e.decision === "SWAP").length ?? 0;

  const tableRows = report ? buildTableRows(report) : [];

  /* ─── Render ─── */
  if (error) return (
    <div className={styles.wrapper}>
      <div className={styles["center-state"]}><span>⚠️ {error}</span><Link href="/">← Go Back</Link></div>
    </div>
  );

  return (
    <div className={styles.wrapper}>
      {/* ── Header ── */}
      <header className={styles.header}>
        <div className={styles["header-left"]}>
          <Link href="/" className={styles["back-btn"]}>← Back</Link>
          <span className={styles["job-id"]}>JOB: {jobId}</span>
          {status && <DecisionChip decision={status.status} />}
        </div>
        <div className={styles["header-right"]}>
          {status && (
            <div className={styles["progress-bar-row"]}>
              <span className={styles["progress-label"]}>{status.current_agent ?? status.stage ?? "Queued"}</span>
              <div className="progress-track" style={{ flex: 1 }}>
                <div className="progress-fill" style={{ width: `${status.progress}%` }} />
              </div>
              <span className={styles["progress-pct"]}>{status.progress}%</span>
            </div>
          )}
          <button onClick={handleLogout} style={{marginLeft: '16px', background: 'transparent', border: 'none', cursor: 'pointer', fontFamily: 'inherit', fontSize: '14px', fontWeight: 600, color: 'var(--invalid)'}}>Logout</button>
        </div>
      </header>

      {/* ── Split Pane ── */}
      <div className={styles.split}>
        {/* LEFT: Real PDF Viewer */}
        <div className={styles["pdf-pane"]}>
          <div className={styles["pane-header"]}>
            <span>📄 Document Viewer</span>
            <div className={styles["doc-toggle"]}>
              <button
                className={`${styles["toggle-btn"]} ${docView === "chart" ? styles.active : ""}`}
                onClick={() => { setDocView("chart"); setHighlight(""); }}
              >
                Medical Chart
              </button>
              <button
                className={`${styles["toggle-btn"]} ${docView === "claim" ? styles.active : ""}`}
                onClick={() => { setDocView("claim"); setHighlight(""); }}
              >
                Claim Record
              </button>
            </div>
          </div>
          <div className={styles["pdf-scroll"]}>
            {status?.status === "COMPLETED" || status?.status === "RUNNING" ? (
              <PdfViewer
                key={activePdfUrl}
                pdfUrl={activePdfUrl}
                searchText={highlight}
                onClearSearch={() => setHighlight("")}
              />
            ) : (
              <div className={styles["center-state"]}>
                {status?.status === "RUNNING" ? (
                  <><div className={styles.spinner} /><span>Analyzing clinical records…</span></>
                ) : (
                  <span style={{ color: "var(--text-secondary)" }}>Document will appear here once the job starts.</span>
                )}
              </div>
            )}
          </div>
        </div>

        {/* RIGHT: Audit Summary Table Panel */}
        <div className={styles["report-pane"]}>
          {/* Pipeline Progress */}
          {status && status.status !== "COMPLETED" && (
            <div className={styles["pipeline-panel"]}>
              <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
                <span style={{ fontSize: 13, fontWeight: 600 }}>Pipeline Progress</span>
                <span style={{ fontSize: 12, fontFamily: "var(--font-mono)", color: "var(--text-secondary)" }}>
                  {status.elapsed_seconds != null ? `${status.elapsed_seconds}s` : "—"}
                </span>
              </div>
              <div className={styles["pipeline-stages"]}>
                {(status.stages ?? []).map(s => (
                  <div key={s.name} className={styles["stage-row"]}>
                    <span className={styles["stage-icon"]} style={{ color: s.status === "completed" ? "var(--valid)" : s.status === "running" ? "var(--primary)" : s.status === "failed" ? "var(--invalid)" : "var(--text-secondary)" }}>
                      {stageIcon(s.status)}
                    </span>
                    <span className={`${styles["stage-name"]} ${styles[s.status] ?? ""}`}>{s.label}</span>
                    {s.elapsed_seconds != null && (
                      <span className={styles["stage-time"]}>{s.elapsed_seconds}s</span>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}

          <div className={styles["report-scroll"]}>
            {status?.status === "RUNNING" && !report && (
              <div className={styles["center-state"]}>
                <div className={styles.spinner} />
                <span>Auditing ICD-10 coding guidelines &amp; graph rules…</span>
              </div>
            )}
            {report && (
              <>
                {/* Summary Metrics */}
                <div className={styles["summary-cards"]}>
                  <div className={styles["summary-card"]}>
                    <div className={styles["summary-card-label"]}>Valid (Kept)</div>
                    <div className={`${styles["summary-card-value"]} ${styles.green}`}>{validCount}</div>
                  </div>
                  <div className={styles["summary-card"]}>
                    <div className={styles["summary-card-label"]}>Invalid / Dropped</div>
                    <div className={`${styles["summary-card-value"]} ${styles.red}`}>{invalidCount + report.dropped_codes.length}</div>
                  </div>
                  <div className={styles["summary-card"]}>
                    <div className={styles["summary-card-label"]}>Swaps / Manual Reviews</div>
                    <div className={`${styles["summary-card-value"]} ${styles.yellow}`}>{swapCount}</div>
                  </div>
                </div>

                {/* Audit Summary Table — with SME Review Mode */}
                <div className={styles["table-header-row"]}>
                  <div style={{display:'flex', flexDirection:'column', gap:4}}>
                    <p className={styles["report-title"]}>Audit Summary Table</p>
                    {jobMeta?.chart_filename && (
                      <span className={styles["table-subtitle"]} style={{fontSize: 13, color:'var(--text-main)'}}>
                        📄 <strong>Chart:</strong> {jobMeta.chart_filename}
                      </span>
                    )}
                  </div>
                  <div style={{display:'flex',gap:10,alignItems:'center',flexWrap:'wrap'}}>
                    <span className={styles["table-subtitle"]} style={{marginRight:8}}>
                      {reviewMode ? '👆 Override any AI decision below, then Finalize.' : 'Click evidence to highlight in PDF.'}
                    </span>
                    {!reviewMode && (
                      <>
                        <button className="btn-primary" style={{fontSize:12,padding:'7px 16px'}}
                          onClick={() => setReviewMode(true)}>
                          👩‍⚕️ Enter SME Review Mode
                        </button>
                        <button className="btn-primary" style={{fontSize:12,padding:'7px 16px',background:'#0ea5e9'}}
                          onClick={handleExportPdf}>
                          🖨️ Export PDF
                        </button>
                      </>
                    )}
                    {reviewMode && (
                      <>
                        <button style={{fontSize:12,padding:'7px 14px',background:'#f1f5f9',border:'1px solid var(--border-medium)',borderRadius:6,cursor:'pointer',color:'var(--text-secondary)'}}
                          onClick={() => setReviewMode(false)}>Cancel</button>
                        <button className="btn-primary" style={{fontSize:12,padding:'7px 16px',background:'var(--valid)'}}
                          onClick={handleFinalizeReview} disabled={savingReview}>
                          {savingReview ? '⏳ Saving…' : '✅ Save SME Overrides'}
                        </button>
                      </>
                    )}
                  </div>
                </div>

                <div className={styles["table-container"]}>
                  <table className={styles["audit-table"]}>
                    <thead>
                      <tr>
                        <th style={{ width: "8%" }}>Code</th>
                        <th style={{ width: "14%" }}>Description</th>
                        <th style={{ width: "11%" }}>AI Decision</th>
                        {reviewMode && <th style={{ width: "20%" }}>SME Override</th>}
                        <th style={{ width: reviewMode ? "25%" : "35%" }}>Coding Rule / Rationale</th>
                        <th style={{ width: "22%" }}>Chart Evidence</th>
                      </tr>
                    </thead>
                    <tbody>
                      {tableRows.map((row, i) => {
                        const sme = smeDecisions[row.code] ?? { 
                          sme_decision: row.sme_decision ?? 'APPROVE', 
                          sme_override_code: row.sme_override_code ?? '', 
                          sme_notes: row.sme_notes ?? '' 
                        };
                        
                        const isSmeOverride = row.sme_reviewed && row.sme_decision === 'OVERRIDE' && row.sme_override_code;
                        const displayCode = isSmeOverride ? row.sme_override_code : row.code;
                        const displayDesc = isSmeOverride && !CODE_DESCRIPTIONS[row.sme_override_code!]
                          ? <span style={{color:'var(--primary)', fontStyle:'italic'}}>Description unavailable (SME override)</span>
                          : (isSmeOverride ? CODE_DESCRIPTIONS[row.sme_override_code!] : row.description);

                        return (
                        <tr key={`${row.code}-${i}`} className={highlight && row.chart_evidence === highlight ? styles["row-active"] : ""}>
                          {/* 1. Code */}
                          <td>
                            <span className={styles["code-badge"]}>{displayCode}</span>
                          </td>

                          {/* 2. Description */}
                          <td className={styles["desc-cell"]}>
                            {displayDesc}
                          </td>

                          {/* 3. Final Audit Status */}
                          <td>
                            <span className={`${styles["status-badge"]} ${
                              row.final_status.includes("VALID") && !row.final_status.includes("INVALID") ? styles["status-valid"] :
                              row.final_status.includes("SWAP") ? styles["status-swap"] :
                              row.final_status.includes("INCOMPLETE") ? styles["status-incomplete"] :
                              row.final_status.includes("Manual") || row.final_status.includes("Scope") ? styles["status-manual"] :
                              styles["status-invalid"]
                            }`} style={(row.sme_reviewed && row.sme_decision !== 'APPROVE') ? { opacity: 0.5, textDecoration: 'line-through' } : {}}>
                              {row.final_status}
                            </span>
                            {!(row.sme_reviewed && row.sme_decision !== 'APPROVE') && row.action_taken && (
                              <div className={styles["action-sub"]}>{row.action_taken}</div>
                            )}
                            
                            {/* SME Professional Badge */}
                            {row.sme_reviewed && (
                              <div style={{marginTop:8}}>
                                <span className={styles["status-badge"]} style={{background:'var(--primary)', color:'#fff'}}>
                                  SME {row.sme_decision === 'APPROVE' ? 'Approved' : row.sme_decision === 'REJECT' ? 'Rejected' : 'Swapped'}
                                </span>
                                {row.sme_decision === 'OVERRIDE' && row.sme_override_code && (
                                  <div className={styles["action-sub"]} style={{color:'var(--primary)', fontWeight:600, marginTop:4}}>
                                    → {row.sme_override_code}
                                  </div>
                                )}
                                {row.sme_notes && (
                                  <div style={{fontSize:10, fontStyle:'italic', color:'var(--text-secondary)', marginTop:4}}>
                                    "{row.sme_notes}"
                                  </div>
                                )}
                              </div>
                            )}
                          </td>

                          {/* 4. SME Override Column (only in Review Mode) */}
                          {reviewMode && (
                            <td style={{verticalAlign:'top',padding:'8px 6px'}}>
                              <select
                                value={sme.sme_decision}
                                onChange={e => handleSmeChange(row.code, 'sme_decision', e.target.value)}
                                style={{width:'100%',padding:'5px 8px',border:'1px solid var(--border-medium)',borderRadius:6,fontSize:12,marginBottom:6,fontFamily:'var(--font-body)'}}
                              >
                                <option value="APPROVE">✅ Approve AI</option>
                                <option value="REJECT">❌ Reject Code</option>
                                <option value="OVERRIDE">✏️ Override / Swap</option>
                              </select>
                              {sme.sme_decision === 'OVERRIDE' && (
                                <input
                                  type="text"
                                  placeholder="Enter replacement code"
                                  value={sme.sme_override_code}
                                  onChange={e => handleSmeChange(row.code, 'sme_override_code', e.target.value)}
                                  style={{width:'100%',padding:'4px 8px',border:'1px solid var(--primary)',borderRadius:6,fontSize:12,marginBottom:4,fontFamily:'var(--font-mono)'}}
                                />
                              )}
                              <input
                                type="text"
                                placeholder="Notes (optional)"
                                value={sme.sme_notes}
                                onChange={e => handleSmeChange(row.code, 'sme_notes', e.target.value)}
                                style={{width:'100%',padding:'4px 8px',border:'1px solid var(--border-subtle)',borderRadius:6,fontSize:11,fontFamily:'var(--font-body)',color:'var(--text-secondary)'}}
                              />
                            </td>
                          )}

                          {/* 5. Coding Rule / Rationale */}
                          <td className={styles["rationale-cell"]}>
                            {row.coding_rule && (
                              <div className={styles["rule-tag"]}>{row.coding_rule}</div>
                            )}
                            <div className={styles["rationale-text"]}>{row.rationale}</div>
                          </td>

                          {/* 7. Medical Chart Evidence (Interactive — triggers PDF highlight) */}
                          <td className={styles["evidence-cell"]}>
                            {row.chart_evidence ? (
                              (row.chart_evidence.includes("NO_SUPPORTING_EVIDENCE_FOUND") || row.chart_evidence.toUpperCase().includes("NO EVIDENCE FOUND")) ? (
                                <span className={styles["no-evidence"]} style={{ fontStyle: "normal", color: "var(--invalid)" }}>
                                  No Supporting Evidence Found
                                </span>
                              ) : (
                                <button
                                  className={`${styles["evidence-btn"]} ${highlight === row.chart_evidence ? styles["evidence-btn-active"] : ""}`}
                                  onClick={() => {
                                    setHighlight(row.chart_evidence);
                                    setDocView("chart");
                                  }}
                                  title="Click to highlight in original Medical Chart PDF"
                                >
                                  <span className={styles["evidence-icon"]}>🔍</span>
                                  <span className={styles["evidence-quote"]}>
                                    &ldquo;{row.chart_evidence.length > 70 ? row.chart_evidence.slice(0, 70) + "…" : row.chart_evidence}&rdquo;
                                  </span>
                                </button>
                              )
                            ) : (
                              <span className={styles["no-evidence"]}>—</span>
                            )}
                          </td>
                        </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              </>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
