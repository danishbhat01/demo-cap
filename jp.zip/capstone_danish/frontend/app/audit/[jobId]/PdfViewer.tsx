"use client";
import { useState, useEffect, useRef, useCallback } from "react";
import { Document, Page, pdfjs } from "react-pdf";
import "react-pdf/dist/Page/TextLayer.css";
import "react-pdf/dist/Page/AnnotationLayer.css";
import styles from "./page.module.css";

// Configure pdfjs worker (Next.js compatible)
pdfjs.GlobalWorkerOptions.workerSrc = `//unpkg.com/pdfjs-dist@${pdfjs.version}/build/pdf.worker.min.mjs`;

export default function PdfViewer({
  pdfUrl,
  searchText,
  onClearSearch,
}: {
  pdfUrl: string;
  searchText: string;
  onClearSearch: () => void;
}) {
  const [numPages, setNumPages] = useState<number>(0);
  const [pdfError, setPdfError] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);

  // Custom text renderer — wraps matched text in a highlight span
  const customTextRenderer = useCallback(
    ({ str }: { str: string }) => {
      if (!searchText || searchText.length < 4) return str;

      const query = searchText.trim().replace(/^["']|["']$/g, "");
      
      // Split into words, keep significant ones (length >= 4)
      const keywords = query.split(/\s+/).filter(w => w.replace(/[^a-zA-Z0-9]/g, '').length >= 4);
      if (keywords.length === 0) return str;

      // Create a safe regex for all keywords
      const escapedKeywords = keywords.map(w => w.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'));
      const regex = new RegExp(`(${escapedKeywords.join('|')})`, 'gi');

      // Replace and wrap with mark tag
      if (regex.test(str)) {
        return str.replace(regex, '<mark class="pdf-text-highlight">$1</mark>');
      }
      return str;
    },
    [searchText]
  );

  // Scroll to first highlight after render
  useEffect(() => {
    if (!searchText) return;
    const timer = setTimeout(() => {
      const el = containerRef.current?.querySelector(".pdf-text-highlight");
      el?.scrollIntoView({ behavior: "smooth", block: "center" });
    }, 400);
    return () => clearTimeout(timer);
  }, [searchText, numPages]);

  if (pdfError) {
    return (
      <div className={styles["center-state"]}>
        <span style={{ fontSize: 28 }}>📄</span>
        <span>Could not render PDF. The document may not be available yet.</span>
      </div>
    );
  }

  return (
    <div className={styles["pdf-viewer-wrap"]} ref={containerRef}>
      <div style={{ display: 'flex', flexDirection: 'column', width: '100%', height: '100%', gap: '12px' }}>
        {searchText && (
          <div className={styles["highlight-bar"]}>
            <span>🔍 Highlighting: <em>&ldquo;{searchText.slice(0, 60)}{searchText.length > 60 ? "…" : ""}&rdquo;</em></span>
            <button className={styles["clear-highlight-btn"]} onClick={onClearSearch}>
              Clear ✕
            </button>
          </div>
        )}

        <div style={{ flex: 1, position: 'relative', overflow: 'auto', borderRadius: '8px' }}>
          <Document
            file={pdfUrl}
            onLoadSuccess={({ numPages }) => setNumPages(numPages)}
            onLoadError={() => setPdfError(true)}
            loading={
              <div className={styles["center-state"]}>
                <div className={styles.spinner} />
                <span>Loading document…</span>
              </div>
            }
          >
            {Array.from({ length: numPages }, (_, i) => (
              <div key={i} className={styles["pdf-page-wrap"]}>
                <Page
                  pageNumber={i + 1}
                  width={containerRef.current?.clientWidth
                    ? (containerRef.current.clientWidth - 32)
                    : 560}
                  devicePixelRatio={typeof window !== 'undefined' ? Math.max(window.devicePixelRatio, 2) : 2}
                  renderTextLayer={true}
                  renderAnnotationLayer={false}
                  customTextRenderer={customTextRenderer}
                />
                <div className={styles["page-number"]}>Page {i + 1} / {numPages}</div>
              </div>
            ))}
          </Document>
        </div>
      </div>
    </div>
  );
}
