"use client";
import Link from "next/link";
import { useRouter } from "next/navigation";
import styles from "./page.module.css";

const LAYERS = [
  {
    id: "pdf_parse",
    label: "Preprocessing — PDF Parsing",
    icon: "📄",
    color: "var(--text-secondary)",
    description: "Extracts raw text from uploaded Claim and Medical Chart scanned PDFs, applying basic OCR or text scraping.",
    outputs: ["Raw Clinical Text", "Raw Claimed Codes"],
    tech: "PyMuPDF / OCR",
  },
  {
    id: "extraction",
    label: "Layer 1 — Clinical Extractor",
    icon: "🔍",
    color: "var(--companion)",
    description: "Reads the medical chart PDF and produces a structured Evidence DB (JSON) with verbatim source quotes for every extracted diagnosis, organism, and organ dysfunction. Zero clinical inference — strictly evidence-bound.",
    outputs: ["Evidence DB (JSON)", "Verbatim Source Quotes"],
    tech: "Pydantic + LLM",
  },
  {
    id: "under_coding",
    label: "Layer 2 — Under-Coding Detection",
    icon: "🔎",
    color: "var(--primary-dim)",
    description: "Scans the extracted Clinical Evidence against the Neo4j Knowledge Graph to identify potential diagnoses that were documented in the chart but missing from the submitted claim.",
    outputs: ["Suggested Codes", "Missing Documentation"],
    tech: "Neo4j Graph Traversal",
  },
  {
    id: "kg_retrieval",
    label: "Layer 3A — Neo4j Tabular Rules",
    icon: "🕸️",
    color: "var(--primary)",
    description: "Queries the ICD-10-CM Knowledge Graph for each code: EXCLUDES1, EXCLUDES2, CODE_FIRST, USE_ADDITIONAL_CODE, synonyms, and organisms. Enforced deterministically — not by the LLM.",
    outputs: ["Tabular Rules Payload", "Disease Name & Synonyms", "Organism List"],
    tech: "Neo4j Graph DB",
  },
  {
    id: "rag_retrieval",
    label: "Layer 3B — RAG Guideline Retrieval",
    icon: "📚",
    color: "var(--swap)",
    description: "Performs semantic search against the ChromaDB vector database (populated from official CMS ICD-10-CM PDF). Retrieves complete, unbroken disease-entity paragraphs — not arbitrary text chunks.",
    outputs: ["Section I.C Chapter Guidelines", "Disease-Specific Rules"],
    tech: "ChromaDB + Sentence Transformers",
  },
  {
    id: "validation",
    label: "Layer 4 — ICD Validator Agent",
    icon: "⚖️",
    color: "var(--valid)",
    description: "Receives the full payload (Evidence DB + Tabular Rules + RAG Guidelines + all claimed codes) and evaluates the single target code. Enforces a strict rule hierarchy and produces a structured JSON verdict.",
    outputs: ["VALID / INVALID / SWAP / ADD_COMPANION", "Chart Evidence Quote", "Coding Rule Cited"],
    tech: "LLM + Pydantic Schema",
  },
  {
    id: "guards",
    label: "Anti-Fabrication Guards",
    icon: "🛡️",
    color: "var(--invalid)",
    description: "4-tier runtime verification: Numeric Grounding (exact number match), Clinical Text Grounding (fuzzy match), Semantic Relevance (LLM-as-judge), and Guideline Citation Grounding. Failed verdicts trigger a retry, then Manual Review routing.",
    outputs: ["Grounded Verdict or Retry", "Telemetry Log (JSONL)"],
    tech: "Python + LLM Judge",
  },
  {
    id: "compile",
    label: "Report Compilation",
    icon: "📋",
    color: "var(--manual)",
    description: "Assembles the final audit report. Sorts validated codes by sequencing position (principal first), checks for missing companion code dependencies, and flags out-of-scope codes for Manual Review.",
    outputs: ["Structured Audit Report (JSON)", "Manual Review Flags"],
    tech: "Deterministic Python",
  },
];

export default function PipelinePage() {
  const router = useRouter();

  const handleLogout = () => {
    document.cookie = "auth-token=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;";
    router.push("/login");
  };

  return (
    <div className={styles.wrapper}>
      <header className={styles.header}>
        <div className={styles.logo}>
          <span className={styles["logo-icon"]}>⚕</span>
          <div>
            <div className={styles["logo-text"]}>ClinAudit AI</div>
            <div className={styles["logo-sub"]}>ICD-10-CM Validation Platform</div>
          </div>
        </div>
        <nav className={styles["nav-links"]}>
          <Link href="/" className={styles["nav-link"]}>Upload</Link>
          <Link href="/pipeline" className={`${styles["nav-link"]} ${styles.active}`}>Pipeline</Link>
          <button onClick={handleLogout} className={styles["nav-link"]} style={{background: 'transparent', border: 'none', cursor: 'pointer', fontFamily: 'inherit', fontSize: 'inherit', color: 'var(--invalid)'}}>Logout</button>
        </nav>
      </header>

      <main className={styles.main}>
        <div className={styles["page-hero"]}>
          <div className={styles["hero-badge"]}>⚙ System Architecture</div>
          <h1 className={styles["page-title"]}>The Tri-Layer Brain</h1>
          <p className={styles["page-subtitle"]}>
            A deterministic, graph-based validation pipeline that cross-references three independent
            knowledge layers before emitting a single verdict.
          </p>
        </div>

        <div className={styles.pipeline}>
          {/* Top Row: Layer 1 -> Layer 2 */}
          <div className={styles["flow-row"]}>
            <div className={styles["flow-node"]}>
              <div className={`glass-card ${styles["step-card"]}`}>
                <div className={styles["step-header"]}>
                  <span className={styles["step-icon"]}>{LAYERS[0].icon}</span>
                  <span className={styles["step-label"]} style={{ color: LAYERS[0].color }}>{LAYERS[0].label}</span>
                  <span className={styles["step-tech"]}>{LAYERS[0].tech}</span>
                </div>
                <p className={styles["step-desc"]}>{LAYERS[0].description}</p>
                <div className={styles["step-outputs"]}>
                  {LAYERS[0].outputs.map(o => (
                    <span key={o} className={styles["output-tag"]} style={{ borderColor: LAYERS[0].color + "40", color: LAYERS[0].color }}>{o}</span>
                  ))}
                </div>
              </div>
            </div>

            <div className={styles["flow-connector-horizontal"]}>
              <div className={styles["arrow-right"]}></div>
            </div>

            <div className={styles["flow-node"]}>
              <div className={`glass-card ${styles["step-card"]}`}>
                <div className={styles["step-header"]}>
                  <span className={styles["step-icon"]}>{LAYERS[1].icon}</span>
                  <span className={styles["step-label"]} style={{ color: LAYERS[1].color }}>{LAYERS[1].label}</span>
                  <span className={styles["step-tech"]}>{LAYERS[1].tech}</span>
                </div>
                <p className={styles["step-desc"]}>{LAYERS[1].description}</p>
                <div className={styles["step-outputs"]}>
                  {LAYERS[1].outputs.map(o => (
                    <span key={o} className={styles["output-tag"]} style={{ borderColor: LAYERS[1].color + "40", color: LAYERS[1].color }}>{o}</span>
                  ))}
                </div>
              </div>
            </div>

            <div className={styles["flow-connector-horizontal"]}>
              <div className={styles["arrow-right"]}></div>
            </div>

            <div className={styles["flow-node"]}>
              <div className={`glass-card ${styles["step-card"]}`}>
                <div className={styles["step-header"]}>
                  <span className={styles["step-icon"]}>{LAYERS[2].icon}</span>
                  <span className={styles["step-label"]} style={{ color: LAYERS[2].color }}>{LAYERS[2].label}</span>
                  <span className={styles["step-tech"]}>{LAYERS[2].tech}</span>
                </div>
                <p className={styles["step-desc"]}>{LAYERS[2].description}</p>
                <div className={styles["step-outputs"]}>
                  {LAYERS[2].outputs.map(o => (
                    <span key={o} className={styles["output-tag"]} style={{ borderColor: LAYERS[2].color + "40", color: LAYERS[2].color }}>{o}</span>
                  ))}
                </div>
              </div>
            </div>
          </div>

          <div className={styles["flow-connector-vertical"]}>
            <div className={styles["arrow-down"]}></div>
          </div>

          {/* Middle Row: Layer 3A / 3B -> Layer 4 Validator */}
          <div className={styles["flow-row-3"]}>
            <div className={styles["flow-column"]}>
              <div className={`glass-card ${styles["step-card"]}`}>
                <div className={styles["step-header"]}>
                  <span className={styles["step-icon"]}>{LAYERS[3].icon}</span>
                  <span className={styles["step-label"]} style={{ color: LAYERS[3].color }}>{LAYERS[3].label}</span>
                  <span className={styles["step-tech"]}>{LAYERS[3].tech}</span>
                </div>
                <p className={styles["step-desc"]}>{LAYERS[3].description}</p>
                <div className={styles["step-outputs"]}>
                  {LAYERS[3].outputs.map(o => (
                    <span key={o} className={styles["output-tag"]} style={{ borderColor: LAYERS[3].color + "40", color: LAYERS[3].color }}>{o}</span>
                  ))}
                </div>
              </div>

              <div className={`glass-card ${styles["step-card"]}`}>
                <div className={styles["step-header"]}>
                  <span className={styles["step-icon"]}>{LAYERS[4].icon}</span>
                  <span className={styles["step-label"]} style={{ color: LAYERS[4].color }}>{LAYERS[4].label}</span>
                  <span className={styles["step-tech"]}>{LAYERS[4].tech}</span>
                </div>
                <p className={styles["step-desc"]}>{LAYERS[4].description}</p>
                <div className={styles["step-outputs"]}>
                  {LAYERS[4].outputs.map(o => (
                    <span key={o} className={styles["output-tag"]} style={{ borderColor: LAYERS[4].color + "40", color: LAYERS[4].color }}>{o}</span>
                  ))}
                </div>
              </div>
            </div>

            <div className={styles["flow-connector-horizontal"]}>
              <div className={styles["arrow-right"]}></div>
            </div>

            <div className={styles["flow-node"]}>
              <div className={`glass-card ${styles["step-card"]}`}>
                <div className={styles["step-header"]}>
                  <span className={styles["step-icon"]}>{LAYERS[5].icon}</span>
                  <span className={styles["step-label"]} style={{ color: LAYERS[5].color }}>{LAYERS[5].label}</span>
                  <span className={styles["step-tech"]}>{LAYERS[5].tech}</span>
                </div>
                <p className={styles["step-desc"]}>{LAYERS[5].description}</p>
                <div className={styles["step-outputs"]} style={{ justifyContent: "center" }}>
                  {LAYERS[5].outputs.map(o => (
                    <span key={o} className={styles["output-tag"]} style={{ borderColor: LAYERS[5].color + "40", color: LAYERS[5].color }}>{o}</span>
                  ))}
                </div>
              </div>
            </div>
          </div>

          <div className={styles["flow-connector-vertical"]}>
            <div className={styles["arrow-down"]}></div>
          </div>

          {/* Bottom Row: Guards & Compilation */}
          <div className={styles["flow-row-3"]}>
            <div className={styles["flow-node"]}>
              <div className={`glass-card ${styles["step-card"]}`}>
                <div className={styles["step-header"]}>
                  <span className={styles["step-icon"]}>{LAYERS[6].icon}</span>
                  <span className={styles["step-label"]} style={{ color: LAYERS[6].color }}>{LAYERS[6].label}</span>
                  <span className={styles["step-tech"]}>{LAYERS[6].tech}</span>
                </div>
                <p className={styles["step-desc"]}>{LAYERS[6].description}</p>
                <div className={styles["step-outputs"]}>
                  {LAYERS[6].outputs.map(o => (
                    <span key={o} className={styles["output-tag"]} style={{ borderColor: LAYERS[6].color + "40", color: LAYERS[6].color }}>{o}</span>
                  ))}
                </div>
              </div>
            </div>

            <div className={styles["flow-connector-horizontal"]}>
              <div className={styles["arrow-right"]}></div>
            </div>

            <div className={styles["flow-node"]}>
              <div className={`glass-card ${styles["step-card"]}`}>
                <div className={styles["step-header"]}>
                  <span className={styles["step-icon"]}>{LAYERS[7].icon}</span>
                  <span className={styles["step-label"]} style={{ color: LAYERS[7].color }}>{LAYERS[7].label}</span>
                  <span className={styles["step-tech"]}>{LAYERS[7].tech}</span>
                </div>
                <p className={styles["step-desc"]}>{LAYERS[7].description}</p>
                <div className={styles["step-outputs"]}>
                  {LAYERS[7].outputs.map(o => (
                    <span key={o} className={styles["output-tag"]} style={{ borderColor: LAYERS[7].color + "40", color: LAYERS[7].color }}>{o}</span>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
