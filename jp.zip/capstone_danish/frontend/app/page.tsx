"use client";
import { useState, useRef, DragEvent, useEffect } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import styles from "./page.module.css";

const API = process.env.NEXT_PUBLIC_API_URL ?? "http://localhost:8000";

interface TestCase {
  id: string;
  name: string;
  description: string;
  claimed_codes: string[];
}

interface JobSummary {
  job_id: string;
  status: string;
  progress: number;
  chart_filename: string | null;
  claim_filename: string | null;
  created_at: string | null;
  completed_at: string | null;
}

interface DropZoneProps {
  label: string; hint: string; icon: string;
  file: File | null; onFile: (f: File) => void;
}

function DropZone({ label, hint, icon, file, onFile }: DropZoneProps) {
  const [dragging, setDragging] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);
  const handle = (f: File) => { if (f.type === "application/pdf") onFile(f); };
  const onDrop = (e: DragEvent<HTMLDivElement>) => {
    e.preventDefault(); setDragging(false);
    const f = e.dataTransfer.files[0]; if (f) handle(f);
  };
  return (
    <div
      className={[styles["drop-zone"], dragging ? styles["drag-over"] : "", file ? styles["filled"] : ""].join(" ")}
      onDragOver={(e) => { e.preventDefault(); setDragging(true); }}
      onDragLeave={() => setDragging(false)}
      onDrop={onDrop}
      onClick={() => inputRef.current?.click()}
    >
      <input ref={inputRef} type="file" accept="application/pdf" className={styles["hidden-input"]}
        onChange={(e) => { const f = e.target.files?.[0]; if (f) handle(f); }} />
      <div className={styles["drop-icon"]}>{file ? "✅" : icon}</div>
      <div className={styles["drop-label"]}>{label}</div>
      <div className={styles["drop-hint"]}>{file ? "Click to replace" : hint}</div>
      {file && <div className={styles["drop-filename"]}>{file.name}</div>}
    </div>
  );
}

export default function HomePage() {
  const router = useRouter();

  const handleLogout = () => {
    document.cookie = "auth-token=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;";
    router.push("/login");
  };

  const [tab, setTab] = useState<"upload" | "testcase" | "inbox">("upload");
  const [files, setFiles] = useState<File[]>([]);
  const [uploading, setUploading] = useState(false);
  const [testCases, setTestCases] = useState<TestCase[]>([]);
  const [selectedTc, setSelectedTc] = useState<string | null>(null);
  const [tcLoading, setTcLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [jobs, setJobs] = useState<JobSummary[]>([]);

  useEffect(() => {
    fetch(`${API}/testcases`)
      .then(r => r.json())
      .then(setTestCases)
      .catch(() => {});
    fetch(`${API}/jobs`)
      .then(r => r.json())
      .then(setJobs)
      .catch(() => {});
  }, []);

  const submitPdf = async () => {
    if (files.length !== 2) {
      setError("Please select exactly two files (one Claim PDF and one Medical Chart PDF).");
      return;
    }
    
    // Auto-detect claim vs chart based on filename
    let claimFile = files[0];
    let chartFile = files[1];
    
    const file0IsChart = files[0].name.toLowerCase().includes("chart");
    const file1IsClaim = files[1].name.toLowerCase().includes("claim");
    
    if (file0IsChart || file1IsClaim) {
      claimFile = files[1];
      chartFile = files[0];
    }

    setError(null); setUploading(true);
    try {
      const form = new FormData();
      form.append("claim_pdf", claimFile);
      form.append("chart_pdf", chartFile);
      const res = await fetch(`${API}/jobs`, { method: "POST", body: form });
      const data = await res.json();
      if (!res.ok) throw new Error(data.detail ?? "Upload failed.");
      router.push(`/audit/${data.job_id}`);
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : String(err));
      setUploading(false);
    }
  };

  const runTestCase = async () => {
    if (!selectedTc) return;
    setError(null); setTcLoading(true);
    try {
      const res = await fetch(`${API}/testcases/${selectedTc}/run`, { method: "POST" });
      const data = await res.json();
      if (!res.ok) throw new Error(data.detail ?? "Failed to start test case.");
      router.push(`/audit/${data.job_id}`);
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : String(err));
      setTcLoading(false);
    }
  };

  return (
    <div className={styles.wrapper}>
      <header className={styles.header}>
        <div className={styles.logo}>
          <span className={styles["logo-icon"]}>⚕</span>
          <div>
            <div className={styles["logo-text"]}>ClinAudit AI</div>
            <div className={styles["logo-sub"]}>ICD-10-CM Validation Platform</div>
          </div>
        </div>
        <nav className={styles["nav-links"]}>
          <Link href="/" className={`${styles["nav-link"]} ${styles.active}`}>Upload</Link>
          <Link href="/pipeline" className={styles["nav-link"]}>Pipeline</Link>
          <button onClick={handleLogout} className={styles["nav-link"]} style={{background: 'transparent', border: 'none', cursor: 'pointer', fontFamily: 'inherit', fontSize: 'inherit', color: 'var(--invalid)'}}>Logout</button>
        </nav>
      </header>

      <main className={styles.hero}>
        <div className={styles["hero-badge"]}>● AI-Powered Clinical Auditing</div>
        <h1 className={styles["hero-title"]}>
          Validate ICD-10 Claims<br />with <span>Precision</span>
        </h1>
        <p className={styles["hero-subtitle"]}>
          Upload a claim and chart PDF, or run a pre-built test case to see the pipeline in action.
        </p>

        <div className={`glass-card ${styles["upload-panel"]}`}>
          {/* Tab Switcher */}
        <div className={styles["tab-row"]}>
            <button
              className={`${styles["tab-btn"]} ${tab === "upload" ? styles["tab-active"] : ""}`}
              onClick={() => { setTab("upload"); setError(null); }}
            >
              📤 PDF Upload
            </button>
            <button
              className={`${styles["tab-btn"]} ${tab === "testcase" ? styles["tab-active"] : ""}`}
              onClick={() => { setTab("testcase"); setError(null); }}
            >
              🧪 Test Cases
            </button>
            <button
              className={`${styles["tab-btn"]} ${tab === "inbox" ? styles["tab-active"] : ""}`}
              onClick={() => { setTab("inbox"); setError(null); fetch(`${API}/jobs`).then(r=>r.json()).then(setJobs).catch(()=>{}); }}
            >
              👩‍⚕️ SME Review Inbox {jobs.filter(j=>j.status==="COMPLETED").length > 0 && <span style={{marginLeft:6,background:'var(--primary)',color:'#fff',borderRadius:9999,padding:'1px 6px',fontSize:10}}>{jobs.filter(j=>j.status==="COMPLETED").length}</span>}
            </button>
          </div>

          {/* PDF Upload Tab */}
          {tab === "upload" && (
            <>
              <div className={styles["upload-grid"]}>
                <div className={`${styles["drop-zone"]} ${files.length === 2 ? styles.filled : ""}`}>
                  <input
                    type="file"
                    accept="application/pdf"
                    multiple
                    className={styles["file-input"]}
                    onChange={(e) => {
                      if (e.target.files) {
                        const selected = Array.from(e.target.files);
                        if (selected.length > 2) {
                          setError("Please select exactly two PDF files.");
                        } else {
                          setFiles(selected);
                        }
                      }
                    }}
                  />
                  <div className={styles["drop-content"]}>
                    <div className={styles["drop-icon"]}>📄</div>
                    <div className={styles["drop-label"]}>Upload Claim & Chart PDFs</div>
                    <div className={styles["drop-hint"]}>Select both PDFs simultaneously</div>
                    {files.length > 0 && (
                      <div className={styles["drop-filename"]}>
                        {files.map(f => f.name).join(" & ")}
                      </div>
                    )}
                  </div>
                </div>
              </div>
              <div className={styles["submit-row"]}>
                <button
                  className="btn-primary"
                  onClick={submitPdf}
                  disabled={uploading || files.length !== 2}
                >
                  {uploading ? "⏳ Submitting…" : "🚀 Start Validation"}
                </button>
              </div>
            </>
          )}

          {/* Test Case Tab */}
          {tab === "testcase" && (
            <div className={styles["tc-panel"]}>
              <p className={styles["tc-hint"]}>
                Select a pre-built clinical scenario to run the full pipeline without uploading PDFs.
              </p>
              <div className={styles["tc-list"]}>
                {testCases.length === 0 && (
                  <p style={{ color: "var(--text-secondary)", fontSize: 13, textAlign: "center", padding: "20px 0" }}>
                    Loading test cases… (ensure the API server is running)
                  </p>
                )}
                {testCases.map(tc => (
                  <div
                    key={tc.id}
                    className={`${styles["tc-card"]} ${selectedTc === tc.id ? styles["tc-selected"] : ""}`}
                    onClick={() => setSelectedTc(tc.id)}
                  >
                    <div className={styles["tc-card-header"]}>
                      <span className={styles["tc-name"]}>{tc.name}</span>
                      <div className={styles["tc-codes"]}>
                        {tc.claimed_codes.map(c => (
                          <span key={c} className={styles["tc-code-tag"]}>{c}</span>
                        ))}
                      </div>
                    </div>
                    <p className={styles["tc-desc"]}>{tc.description}</p>
                  </div>
                ))}
              </div>
              <div className={styles["submit-row"]}>
                <button className="btn-primary" disabled={!selectedTc || tcLoading} onClick={runTestCase}>
                  {tcLoading ? "⏳ Launching…" : "▶ Run Test Case"}
                </button>
              </div>
            </div>
          )}

          {/* SME Review Inbox Tab */}
          {tab === "inbox" && (
            <div className={styles["tc-panel"]}>
              <p className={styles["tc-hint"]}>
                All completed audit jobs are listed here. Click any job to enter SME Review Mode.
              </p>
              <div style={{display:'flex',flexDirection:'column',gap:10,marginBottom:24}}>
                {jobs.length === 0 && (
                  <p style={{color:'var(--text-secondary)',fontSize:13,textAlign:'center',padding:'20px 0'}}>
                    No jobs found. Run a test case or upload a PDF first.
                  </p>
                )}
                {jobs.map(j => (
                  <div
                    key={j.job_id}
                    onClick={() => router.push(`/audit/${j.job_id}`)}
                    style={{
                      padding:'14px 18px',border:'1px solid var(--border-medium)',borderRadius:8,
                      background:'#fff',cursor:'pointer',transition:'all 0.18s',
                      display:'flex',alignItems:'center',justifyContent:'space-between'
                    }}
                    onMouseEnter={e=>(e.currentTarget.style.borderColor='var(--primary)')}
                    onMouseLeave={e=>(e.currentTarget.style.borderColor='var(--border-medium)')}
                  >
                    <div>
                      <div style={{fontWeight:600,fontSize:14,color:'var(--text-primary)',marginBottom:2}}>
                        {j.chart_filename ?? j.job_id.slice(0,8)+'...'}
                      </div>
                      <div style={{fontFamily:'var(--font-mono)',fontSize:10,color:'var(--text-secondary)'}}>
                        {j.job_id}
                      </div>
                    </div>
                    <div style={{display:'flex',alignItems:'center',gap:10}}>
                      <span className={`chip chip-${j.status.toLowerCase()}`}>{j.status}</span>
                      <span style={{color:'var(--primary)',fontSize:13,fontWeight:600}}>Review →</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {error && <div className={styles["error-msg"]}>⚠️ {error}</div>}
        </div>
      </main>
    </div>
  );
}
