import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "ICD-10 Clinical Auditing Platform",
  description: "AI-powered ICD-10-CM medical claim validation pipeline.",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
