# Project Context: AI Medical Coder & Claim Validation

**Purpose of this file:** Persistent context file. On a new machine or new session, read this file first to instantly understand the architecture without re-reading the entire codebase.

---

## 1. Project Overview
An automated AI pipeline for validating ICD-10-CM medical claims. Ingests medical charts and claimed codes, validates them against official CMS guidelines and tabular rules, and outputs a structured, audit-ready report with verbatim clinical justifications.

## 2. Orchestration Framework
**Switched from LangGraph to Microsoft Agent Framework (MAF) SDK v1.0**
MAF supports native graph-based workflows (code-first, deterministic), checkpointing, streaming, and human-in-the-loop. It is the stable successor to AutoGen and Semantic Kernel, and integrates natively with Azure AI Foundry. The same queue-based deterministic loop is preserved — just using MAF's graph API instead of LangGraph's.

## 3. Core Architecture (The Tri-Layer Brain)
The MAF orchestrator processes claimed codes one-by-one against three layers of knowledge:

1. **Layer 1: System Prompt (Always-On Knowledge)**
   - Holds universal CMS guidelines (Sections I.A, I.B, II, III, IV).
   - Stored server-side in Azure AI Foundry (prompt caching). Cost: ~$0.02/call.
2. **Layer 2: Azure Knowledge Base (Vector RAG)**
   - Holds chapter-specific CMS guidelines (Section I.C) chunked by disease entity using GPT-4o semantic chunking.
   - Design Decision: Prose guidelines belong in a Vector DB, not Neo4j.
3. **Layer 3: Neo4j (Tabular Graph Database)**
   - Stores rigid ICD-10-CM hierarchy and tabular rules: EXCLUDES1, EXCLUDES2, CODE_FIRST, CODE_ALSO, USE_ADDITIONAL_CODE.
   - Current Scope: Pilot restricted to Chapter 1 (A00-B99).

## 4. Evidence Extraction (Pydantic Schema + Source Quotes)
The Extractor Agent (GPT-5.4 + Pydantic) reads the chart and produces a JSON Evidence Database. 

**IMPORTANT DESIGN DECISION (updated):** The schema now MUST include `source_quote` alongside every extracted fact. Example:
```json
{
  "diagnoses": {
    "Sepsis": {
      "confirmed": true,
      "severity": "Severe",
      "source_quote": "Blood cultures positive for MRSA; SIRS criteria met on Day 2."
    }
  }
}
```
This provides the verbatim audit trail that regulators require — without RAG on the medical chart.

## 5. The Validation Loop
- Step 1: Azure Document Intelligence (OCR) extracts chart text.
- Step 2: Extractor Agent (GPT-5.4 + Pydantic + source_quote fields) creates the JSON Evidence Database.
  - Extracts ALL explicitly documented conditions, not just claimed ones (enables under-coding detection).
- Step 3: MAF initializes the code queue. Runs an under-coding gap check: compares Evidence DB diagnoses vs Claimed Codes. Pushes any documented-but-unclaimed conditions onto the queue as "Suggested Missing Code." **Boundary Guard**: Under-coding strictly handles cross-family missing codes, while the Specificity Engine (Node 3) exclusively handles intra-family specificity upgrades (e.g., A41.9 → A41.02) to prevent duplicate queuing.
- Step 4: MAF processes codes **sequentially** (FIFO queue). For each code, it queries Neo4j for tabular rules + disease name + synonyms. Sequential processing is intentional — EXCLUDES1 checks depend on `validated_sequence` growing incrementally; parallel processing would break this invariant.
- Step 5: MAF assembles payload (Evidence DB + Neo4j rules + disease name + ALL CLAIMED CODES) and calls the Validation Agent via the MAF `agent_framework.Agent` (Azure AI Foundry Agent Service in production).
- Step 6: Validation Agent uses System Prompt (Layer 1) + RAG on Knowledge Base / ChromaDB (Layer 2) + Tabular Rules from payload (Layer 3) to cross-reference against Evidence DB and the other claimed codes.
- Step 7: Agent outputs a verdict with source_quote as justification.
- Step 8: **Reconciliation Node (Node 7):** Once the queue is exhausted, the deterministic `reconcile_claim_rules()` engine runs EXCLUDES1, CODE_FIRST, USE_ADDITIONAL_CODE, and advisory passes over the full validated set to produce the final output.

## 6. Critical Medicolegal Constraints & Project Scope
- **The AI does not practice medicine.** Cannot diagnose from lab values or symptoms.
- **Under-coding Logic:** Can only suggest a missing code if the condition is explicitly documented by a clinician in the chart — not inferred.
- **No RAG on patient charts.** Medical charts are too noisy for reliable vector retrieval; schema-based extraction with source quotes is the correct approach.
- **Alphabetic Index is Out of Scope:** Per project instructions, the pipeline is strictly restricted to using ONLY the ICD-10-CM Tabular Data (XML -> Neo4j) and Official Guidelines (PDF -> ChromaDB). The Alphabetic Index (and its associated "With" assumed causality conventions) is explicitly excluded from the architecture.

## 7. Justifications (For Capstone Defense)
- **Why MAF over Azure Prompt Flow?** Prompt Flow is a DAG (no loops) and retiring in 2027.
- **Why MAF over Azure AI Agent Service alone?** Our pipeline has typed, structured Pydantic state (code queue + Evidence DB) that requires explicit, testable graph-edge control. Azure Agent Service manages state as unstructured Thread messages, optimized for conversational agents.
- **Why MAF over LangGraph?** MAF is the production-ready, Microsoft-native graph SDK with built-in checkpointing, telemetry, and Azure AI Foundry integration. LangGraph requires LangSmith as a separate observability layer.
- **Why Dockerize?** Python code is the boss, not the AI. Deploy to Azure Container Apps for horizontal auto-scaling.
- **Cost & ROI:** ~$0.25-$0.35 per claim. Validates in seconds. Human coders: $5-$10/claim, 15 minutes.

## 8. Key Files & Structure in Workspace
- `backend/orchestrator.py`: State machine executing the validation loop across Extractor, Under-coding, Neo4j lookup, Validator Agent, and Rule Engine.
- `backend/extractor_agent.py`: Pydantic schema-driven clinical entity extractor.
- `backend/validator_agent.py`: Clinical Judge / LLM validation agent evaluating evidence against retrieved guidelines and tabular rules.
- `backend/rule_engine.py`: Deterministic Tabular Rule Engine enforcing hard ICD-10 constraints (`EXCLUDES1`, `CODE_FIRST`, `USE_ADDITIONAL_CODE`, range matching).
- `backend/data_agent.py`: Neo4j driver and ChromaDB vector retrieval functions.
- `backend/guardrails.py`: Numeric grounding, fuzzy string matching, and hallucination telemetry.
- `PRODUCTION.md`: Enterprise production guide for direct Azure OpenAI (GPT-5/GPT-4o) and Microsoft Agent Framework (MAF) native integration.
- `proxy_server.py`: Local MAF Responses API Proxy, refactored to securely route local testing requests exclusively to Mistral AI (`mistral-large-latest`), while production relies natively on Azure OpenAI.
- `insights/`: Centralized folder for all output artifacts:
  - `insights/audit_reports/`: Timestamped JSON audit reports with complete decision rationales.
  - `insights/telemetry_logs.jsonl`: Guardrail interventions, retries, and compliance telemetry.
- `tests/`: Organized test suites:
  - `run_testcase1.py` - `run_testcase4.py`: End-to-end integration tests for MRSA sepsis combination swap, asymptomatic HIV, Excludes1 conflicts, and scope boundaries.
  - `run_custom_test.py`: Interactive runner for custom claims and raw medical notes.
  - `test_runner.py`: Shared test harness used by the integration test cases.
  - `test_layer1_extractor.py`: Unit test for Layer 1 (Extractor Agent).
  - `test_layer2_undercoding.py`: Unit test for Layer 2 (Under-coding Graph Retrieval).
  - `test_layer3_validator.py`: Unit test for Layer 3 validation path (Validator Agent / Clinical Judge).
  - `test_layer4_rule_engine.py`: Unit test for Layer 4 (Tabular Rule Engine).
  - `test_blob_service.py`: Unit test for the dual-mode Azure / Local filesystem blob storage manager.
- `agent_docs/`: Architectural specifications and defense documentation (`AGENT_SPEC.md`, `FINAL_ARCHITECTURE.md`, `Architecture_QA_Guide.md`).
- `prompts/`: Markdown prompts for agents (`extractor_agent_prompt.md`, `validator_agent_prompt.md`).

## 9. Files Safe to Delete (Obsolete)
- `Guideline_Ingestion_Implementation_Plan.docx`: Superseded by the RAG + System Prompt architecture.

## 10. Runtime Grounding & Anti-Fabrication Guards
To prevent the agent from confidently hallucinating clinical evidence (e.g. inventing lab values to justify a code) or citing guideline sections that were never retrieved, the Orchestrator enforces a strict 3-pass runtime check for every validated code:

1. **Numeric Grounding (Hard Check):** Extracts all numbers from the agent's `chart_evidence` citation. The exact number must exist in the flattened Evidence DB text. No fuzzy leniency.
2. **Clinical Text Grounding (Fuzzy Check):** Verifies the rest of the text via exact substring or >85% fuzzy match against the Evidence DB text.
3. **Semantic Relevance Guard (LLM-as-a-Judge):** Fast alignment judge ensuring the cited string clinically supports the target diagnosis.
4. **Guideline Citation Grounding:** Extracts cited sections (e.g., `I.C.1.a.2`, `Section II`) and ensures they actually exist in the retrieved RAG text or the Universal System Prompt.

**Retry & Telemetry:** If a guard triggers, the orchestrator retries the agent once with corrective feedback containing the exact violation. If it fails again, the code is flagged for `manual_review`, and the event is permanently logged to `insights/telemetry_logs.jsonl` for compliance auditing and prompt tuning.

## 11. Demo vs Azure Production Mapping
While the local `backend/` scripts use standard Python logic (Regex, substring matching, ChromaDB, Mistral Large / MAF Proxy), the final production architecture maps directly to native Azure services:

| Demo Implementation | Azure Production Equivalent |
| :--- | :--- |
| `chromadb` local vector store (`all-MiniLM-L6-v2`) | **Azure Cosmos DB vCore `$vectorSearch`** (`text-embedding-3-small`) |
| Local Proxy / Mistral AI (`mistral-large-latest`) | **Azure OpenAI Service** (GPT-4o) directly via Native SDK |
| `verify_clinical_grounding` (Python Substring Check) | **Azure AI Content Safety (Groundedness API)** or Python within Azure Functions |
| Local `.env` Secrets | **Azure Key Vault** (Resolved via `DefaultAzureCredential`) |
| Local `data/uploads` Directory | **Azure Blob Storage** (Private Blobs with SAS Token Generation) |
| `orchestrator.py` | **Azure Container Apps** running the MAF SDK |
| `insights/telemetry_logs.jsonl` | **Azure Application Insights** (Log Analytics Workspace) |
| Extractor Agent | **Azure Document Intelligence** (Pre-built + Custom Neural) -> GPT-4o Pydantic Extractor |

## 12. Recent Modifications & Refinements (Current Milestone)
- **Rule Engine Refactor**: Renamed `reconciler.py` to `rule_engine.py` across the codebase to accurately reflect deterministic tabular rule enforcement.
- **Queue Tag Accuracy**: Fixed the orchestrator queue router so that swapped codes (`SWAP`) are tagged with `"type": "swap"`, reserving `"type": "companion"` strictly for mandatory secondary additions (`USE_ADDITIONAL_CODE` / `ADD_COMPANION`).
- **Centralized Insights Repository**: Created the `insights/` directory with dedicated subfolders (`audit_reports/` and `telemetry_logs.jsonl`), completely removing scattered logs and old reports.
- **Layer-by-Layer Test Suite**: Reorganized the `tests/` directory into 4 end-to-end integration test cases (`run_testcase1-4.py`) and 4 dedicated layer unit tests (`test_layer1_extractor.py`, `test_layer2_undercoding.py`, `test_layer3_validator.py`, `test_layer4_rule_engine.py`).
- **Mistral Large Clinical Engine**: Integrated `mistral-large-latest` across all agents, achieving strict guideline compliance on complex swap, exclusion, and under-coding logic.
- **Extractor Schema Update**: Nested `organism` explicitly under the `diagnoses` object via a `DiagnosisDetails` model to tightly couple pathogens to diseases.
- **Neo4j Under-Coding Engine**: Token deduplication implemented in Python before Cypher execution to prevent word-noise looping.
- **Orchestrator Scope Safeguards**: Out-of-scope codes (non-Chapter 1 pilot codes like `I33.0` or `R65.20`) are explicitly routed to "Manual Review Required: Outside the current Chapter 1 pilot scope".
- **Dynamic PDF Rendering & Mocks**: Upgraded `testcase_runner.py` to support multi-page mock PDF generation for complex clinical charts.
- **SME Human-in-the-Loop Review**: Implemented a comprehensive Dashboard and Audit View (`frontend/app/audit/[jobId]/page.tsx`) with a split-pane PDF viewer and interactive summary table. The SME can definitively Override, Swap, or Reject AI decisions.
- **SME Override Memory & Tracking**: State persistence accurately handles unmodified rows across sessions. Full metadata traceability ensures the final PDF exports dynamically adopt the original medical chart filename.
- **API & Cloud Optimization**: Cleaned `.env` and `proxy_server.py` to exclusively support Mistral AI (Local Proxy) and Azure OpenAI (Native). Azure storage mechanisms (e.g., `blob_service.py`) seamlessly fall back to local `.env` variables if Azure Key Vault is unavailable.

## 13. Project Roadmap (Next Phases)
- **Phase 2 (Knowledge Graph Expansion)**:
  - **Full ICD-10 Chapter Ingestion**: Expanding Neo4j beyond Chapter 1 to ingest Chapters 2 through 22 (e.g. Chapter 9 for circulatory, Chapter 18 for signs/symptoms).
  - **Hybrid Search (Lexical + Semantic)**: Adding Lucene full-text indexes and vector embeddings to Neo4j nodes for higher-precision under-coding candidate retrieval.
  - **Local OCR Ingestion**: Adding Tesseract / PDF parsing directly to the upload pipeline.
- **Phase 2 (UI — Completed)**: An interactive Next.js 16 + React 19 web dashboard for full PDF upload and interactive claim verification (SME Dashboard) is built and available in `frontend/`. Connects to the FastAPI backend in `api/`.
