"""
ICD-10-CM Tabular List XML -> Neo4j ingestion script (Chapter 1 scope, reusable for all chapters)

REWRITE addressing three production issues in the original version:

  1. QUERY PARAMETERIZATION
     Old: f-strings built literal Cypher text, e.g. MERGE (c:Chapter {{chapter_code: '{code}'}})
     New: fixed query TEMPLATES with $named parameters, executed via the Neo4j driver's
          session.run(query, **params). The query text itself never changes between rows;
          only the parameter values do. This is how Neo4j expects write-heavy ingestion to
          run - it also lets the driver cache query plans instead of re-parsing near-identical
          Cypher text on every MERGE.

  2. STRING ESCAPING
     Old: a hand-rolled esc() function escaped single quotes before interpolating into
          f-strings. Any missed edge case (e.g. embedded ", unicode quote variants, null
          bytes) could still break the query or, worse, allow a note's text to alter the
          query structure.
     New: parameters are sent as driver-level bound values, never concatenated into query
          text at all. Escaping is no longer this script's problem - it's the driver/
          protocol's job, the same way parameterized SQL avoids injection. No esc() function
          exists in this version because none is needed.

  3. XML MEMORY USAGE
     Old: ET.parse(xml_path) loads the entire XML DOM tree into memory before processing
          anything. Fine for a single chapter, but the full multi-chapter Tabular List file
          is large, and holding the whole tree while chapter_filter discards everything but
          one chapter is wasted memory.
     New: ET.iterparse() streams the file as a sequence of (event, element) pairs - a
          "conveyor belt" that processes each <chapter> as it completes, then calls
          elem.clear() to free that chapter's memory before moving to the next one. Peak
          memory is roughly "one chapter", not "the whole file", regardless of how large the
          full Tabular List is.

Usage:
    pip install neo4j --break-system-packages
    python parse_tabular.py icd10cm_tabular.xml \\
        --uri bolt://localhost:7687 --user neo4j --password <pw> \\
        --chapter 1

    Or dry-run to inspect the generated (query, params) pairs without touching Neo4j:
    python parse_tabular.py icd10cm_tabular.xml --dry-run --chapter 1
"""

import argparse
import re
import xml.etree.ElementTree as ET
from dataclasses import dataclass, field
from typing import Optional

CODE_REF_RE = re.compile(
    r"([A-Z]\d{2}(?:\.[\d\-]{1,4})?(?:-[A-Z]\d{2}(?:\.[\d\-]{1,4})?)?)"
)
SINGLE_CODE_RE = re.compile(r"^[A-Z]\d{2}(\.\d{1,4})?$")
ORGANISM_HINTS = re.compile(
    r"\b(bacteri|virus|viral|coccus|coccal|bacillus|organism|spirochete|"
    r"vibrio|salmonella|shigella|streptococc|staphylococc|clostrid|"
    r"mycobacter|candida|fungus|fungal|parasit|protozoa)\w*", re.IGNORECASE
)

# Keywords that indicate a CODE_FIRST / USE_ADDITIONAL_CODE rule is conditional
# (i.e. only activated when the described clinical context is present)
CONDITIONAL_KEYWORDS = re.compile(
    r"\b(if applicable|associated|such as|due to|following|during|complicating|"
    r"related to|when applicable|where applicable|in the case of|caused by)\b",
    re.IGNORECASE
)


def extract_condition_clause(note_text: str, ref_code: str) -> tuple:
    """
    Given a raw note such as 'associated AIDS (B20)', extract:
      - condition: the qualifying phrase before the parenthesised code
                   e.g. 'associated AIDS'
      - is_conditional: True if a conditional keyword was found in the note

    The ref_code is stripped from the note so the condition clause contains
    only the human-readable activation context, not the code itself.
    """
    # Remove the trailing parenthesised code reference(s)
    stripped = re.sub(r'\s*\([^)]*\)\s*$', '', note_text.strip())
    # Also strip leading punctuation artefacts like ', '
    condition = stripped.strip(', ').strip()
    is_conditional = bool(CONDITIONAL_KEYWORDS.search(note_text))
    return condition, is_conditional


def classify_code_ref(ref: str) -> str:
    """single -> DiseaseCode, wildcard/range -> CodeRange."""
    if SINGLE_CODE_RE.match(ref):
        return "single"
    if ref.endswith(".-"):
        return "wildcard"
    return "range"


def extract_code_refs(note_text: str) -> list[str]:
    m = re.search(r"\(([^)]+)\)\s*$", note_text.strip())
    if not m:
        return []
    return CODE_REF_RE.findall(m.group(1))


# ---------------------------------------------------------------------------
# Statement collection: each entry is a (query_template, params) pair.
# The query_template is FIXED text with $placeholders - it is identical across
# every row of the same kind, which is what makes it parameterized rather than
# string-built. No f-string ever builds Cypher text containing data values.
# ---------------------------------------------------------------------------

@dataclass
class Statement:
    query: str
    params: dict = field(default_factory=dict)


class StatementCollector:
    def __init__(self):
        self.statements: list[Statement] = []

    def add(self, query: str, **params):
        self.statements.append(Statement(query.strip(), params))

    def __len__(self):
        return len(self.statements)


# ---------------------------------------------------------------------------
# Fixed query templates (constants, not built per-row). Reused by every call
# via bound parameters - this is the actual parameterization fix.
# ---------------------------------------------------------------------------

Q_CONSTRAINTS_AND_INDEXES = [
    "CREATE CONSTRAINT chapter_code_unique IF NOT EXISTS FOR (c:Chapter) REQUIRE c.chapter_code IS UNIQUE",
    "CREATE CONSTRAINT block_code_unique IF NOT EXISTS FOR (b:Block) REQUIRE b.block_code IS UNIQUE",
    "CREATE CONSTRAINT disease_code_unique IF NOT EXISTS FOR (d:DiseaseCode) REQUIRE d.code IS UNIQUE",
    "CREATE CONSTRAINT code_range_unique IF NOT EXISTS FOR (r:CodeRange) REQUIRE r.range IS UNIQUE",
    "CREATE INDEX clinical_term_text IF NOT EXISTS FOR (t:ClinicalTerm) ON (t.term)",
    "CREATE INDEX clinical_term_type IF NOT EXISTS FOR (t:ClinicalTerm) ON (t.type)",
]

Q_MERGE_CHAPTER = """
MERGE (c:Chapter {chapter_code: $chapter_code})
SET c.description = $desc
"""

Q_MERGE_CHAPTER_INCLUDE = """
MERGE (t:ClinicalTerm {term: $term, type: 'Include'})
WITH t
MATCH (c:Chapter {chapter_code: $chapter_code})
MERGE (c)-[:HAS_INCLUDE]->(t)
"""

Q_MERGE_BLOCK = """
MERGE (b:Block {block_code: $block_code})
SET b.description = $desc
WITH b
MATCH (c:Chapter {chapter_code: $chapter_code})
MERGE (c)-[:HAS_BLOCK]->(b)
"""

Q_MERGE_BLOCK_INCLUDE = """
MERGE (t:ClinicalTerm {term: $term, type: 'Include'})
WITH t
MATCH (b:Block {block_code: $block_code})
MERGE (b)-[:HAS_INCLUDE]->(t)
"""

Q_MERGE_DISEASE_CODE = """
MERGE (d:DiseaseCode {code: $code})
SET d.description = $desc, d.billable = $billable
"""

Q_LINK_BLOCK_CONTAINS = """
MATCH (b:Block {block_code: $block_code})
MATCH (d:DiseaseCode {code: $code})
MERGE (b)-[:CONTAINS]->(d)
"""

Q_LINK_HAS_CHILD = """
MATCH (p:DiseaseCode {code: $parent_code})
MATCH (d:DiseaseCode {code: $code})
MERGE (p)-[:HAS_CHILD]->(d)
"""

Q_MERGE_TERM = """
MERGE (t:ClinicalTerm {term: $term, type: $term_type})
SET t.category = CASE WHEN $is_organism THEN 'organism' ELSE t.category END
WITH t
MATCH (d:DiseaseCode {code: $code})
MERGE (d)-[:HAS_INCLUDE]->(t)
"""

Q_MERGE_SEARCH_TERM = """
MERGE (t:ClinicalTerm {term: $term, type: 'SearchTerm'})
SET t.category = 'organism'
WITH t
MATCH (d:DiseaseCode {code: $code})
MERGE (d)-[:HAS_SEARCH_TERM]->(t)
"""

# rel_type is safe to interpolate into the template STRUCTURE (not as a data
# value) because it only ever comes from a fixed, code-controlled list
# (EXCLUDES1/EXCLUDES2/CODE_FIRST/CODE_ALSO/USE_ADDITIONAL_CODE) - never from
# XML content. Neo4j does not support parameterizing relationship types, so
# this is the standard, safe way to vary them: build the query template once
# per known relationship type, not once per row.
def q_link_disease_target(rel_type: str) -> str:
    # Sets note/condition/is_conditional on the relationship so the Rule Engine
    # can do three-state (NOT_APPLICABLE / SATISFIED / UNSATISFIED) evaluation.
    return f"""
MERGE (target:DiseaseCode {{code: $target_code}})
WITH target
MATCH (d:DiseaseCode {{code: $code}})
MERGE (d)-[r:{rel_type}]->(target)
SET r.note = $note, r.condition = $condition, r.is_conditional = $is_conditional
"""

def q_link_range_target(rel_type: str) -> str:
    return f"""
MERGE (target:CodeRange {{range: $target_range}})
SET target.type = $range_type
WITH target
MATCH (d:DiseaseCode {{code: $code}})
MERGE (d)-[r:{rel_type}]->(target)
SET r.note = $note, r.condition = $condition, r.is_conditional = $is_conditional
"""

def q_unlinked_note(xml_tag: str) -> str:
    # xml_tag also comes only from the fixed set of tag names we call
    # emit_code_refs with, never from XML content.
    return f"""
MATCH (d:DiseaseCode {{code: $code}})
SET d.{xml_tag}_unlinked_notes = coalesce(d.{xml_tag}_unlinked_notes, []) + $note_text
"""


# ---------------------------------------------------------------------------
# Emission functions - build Statement objects, never raw query strings
# ---------------------------------------------------------------------------

def emit_chapter_scalar(chapter_code: str, desc: str, collector: StatementCollector):
    collector.add(Q_MERGE_CHAPTER, chapter_code=chapter_code, desc=desc)


def emit_chapter_includes(chapter_el, chapter_code: str, collector: StatementCollector):
    includes = chapter_el.find("includes")
    if includes is None:
        return
    for note in includes.findall("note"):
        text = (note.text or "").strip()
        if text:
            collector.add(Q_MERGE_CHAPTER_INCLUDE, chapter_code=chapter_code, term=text)


def emit_block(section_el, chapter_code: str, collector: StatementCollector) -> str:
    block_code = section_el.get("id", "").strip()
    block_desc = section_el.findtext("desc", "").strip()
    collector.add(Q_MERGE_BLOCK, block_code=block_code, desc=block_desc, chapter_code=chapter_code)

    section_includes = section_el.find("includes")
    if section_includes is not None:
        for note in section_includes.findall("note"):
            text = (note.text or "").strip()
            if text:
                collector.add(Q_MERGE_BLOCK_INCLUDE, block_code=block_code, term=text)

    return block_code


def emit_diag(diag_el, block_code: str, parent_code: Optional[str], collector: StatementCollector):
    code = diag_el.findtext("name", "").strip()
    desc = diag_el.findtext("desc", "").strip()
    children = diag_el.findall("diag")
    billable = len(children) == 0

    collector.add(Q_MERGE_DISEASE_CODE, code=code, desc=desc, billable=billable)

    if parent_code is None:
        collector.add(Q_LINK_BLOCK_CONTAINS, block_code=block_code, code=code)
    else:
        collector.add(Q_LINK_HAS_CHILD, parent_code=parent_code, code=code)

    emit_terms(diag_el, code, "includes", "Include", collector)
    emit_terms(diag_el, code, "inclusionTerm", "Synonym", collector)

    emit_code_refs(diag_el, code, "excludes1", "EXCLUDES1", collector)
    emit_code_refs(diag_el, code, "excludes2", "EXCLUDES2", collector)
    emit_code_refs(diag_el, code, "useAdditionalCode", "USE_ADDITIONAL_CODE", collector)
    emit_code_refs(diag_el, code, "codeFirst", "CODE_FIRST", collector)
    emit_code_refs(diag_el, code, "codeAlso", "CODE_ALSO", collector)

    for child in children:
        emit_diag(child, block_code, parent_code=code, collector=collector)


def emit_terms(diag_el, code: str, xml_tag: str, term_type: str, collector: StatementCollector):
    container = diag_el.find(xml_tag)
    if container is None:
        return
    for note in container.findall("note"):
        text = (note.text or "").strip()
        if not text:
            continue
        is_organism = bool(ORGANISM_HINTS.search(text))
        if is_organism:
            collector.add(Q_MERGE_SEARCH_TERM, term=text, code=code)
        else:
            collector.add(Q_MERGE_TERM, term=text, term_type=term_type, code=code, is_organism=False)


def emit_code_refs(diag_el, code: str, xml_tag: str, rel_type: str, collector: StatementCollector):
    container = diag_el.find(xml_tag)
    if container is None:
        return
    for note in container.findall("note"):
        text = (note.text or "").strip()
        if not text:
            continue
        ref_codes = extract_code_refs(text)
        if ref_codes:
            for ref_code in ref_codes:
                condition, is_conditional = extract_condition_clause(text, ref_code)
                kind = classify_code_ref(ref_code)
                if kind == "single":
                    collector.add(
                        q_link_disease_target(rel_type),
                        target_code=ref_code,
                        code=code,
                        note=text,
                        condition=condition,
                        is_conditional=is_conditional
                    )
                else:
                    collector.add(
                        q_link_range_target(rel_type),
                        target_range=ref_code,
                        range_type=kind,
                        code=code,
                        note=text,
                        condition=condition,
                        is_conditional=is_conditional
                    )
        else:
            collector.add(q_unlinked_note(xml_tag), code=code, note_text=text)


# ---------------------------------------------------------------------------
# Streaming XML walk via iterparse - the memory fix.
#
# ET.parse() would build the ENTIRE document tree in memory before any
# processing starts. iterparse() instead yields (event, element) pairs as the
# parser reads through the file, so we can act on each <chapter> the moment
# its closing tag is seen, then elem.clear() it to release that subtree's
# memory. The file is read once, front to back, like a conveyor belt - the
# next <chapter> isn't held in memory until the previous one is cleared.
# ---------------------------------------------------------------------------

def stream_chapters(xml_path: str, chapter_filter: Optional[str] = None):
    """
    Yields fully-populated <chapter> elements one at a time, without ever
    holding the full document tree in memory.
    """
    context = ET.iterparse(xml_path, events=("end",))
    for event, elem in context:
        if elem.tag != "chapter":
            continue
        chapter_num = elem.findtext("name", "").strip()
        if chapter_filter and chapter_num != chapter_filter:
            elem.clear()
            continue
        yield elem
        # Free this chapter's memory now that the caller is done with it.
        # This is the step that keeps peak memory to "one chapter" instead
        # of "the whole file" - without it, iterparse still builds up the
        # full tree in the background even though we're only ever inspecting
        # <chapter> elements.
        elem.clear()


def collect_statements(xml_path: str, chapter_filter: Optional[str] = None) -> StatementCollector:
    collector = StatementCollector()

    for query in Q_CONSTRAINTS_AND_INDEXES:
        collector.add(query)

    for chapter_el in stream_chapters(xml_path, chapter_filter):
        chapter_code = chapter_el.findtext("name", "").strip()
        chapter_desc = chapter_el.findtext("desc", "").strip()

        emit_chapter_scalar(chapter_code, chapter_desc, collector)
        emit_chapter_includes(chapter_el, chapter_code, collector)

        for section_el in chapter_el.findall("section"):
            block_code = emit_block(section_el, chapter_code, collector)
            for diag_el in section_el.findall("diag"):
                emit_diag(diag_el, block_code, parent_code=None, collector=collector)

    return collector


# ---------------------------------------------------------------------------
# Execution against Neo4j - uses the driver's parameter binding directly.
# No Cypher text is ever built from data values; query strings are the fixed
# templates above, params are passed separately per the driver API.
# ---------------------------------------------------------------------------

def run_against_neo4j(collector: StatementCollector, uri: str, user: str, password: str, batch_size: int = 100):
    from neo4j import GraphDatabase
    from neo4j.exceptions import SessionExpired, ServiceUnavailable
    import time

    driver = GraphDatabase.driver(uri, auth=(user, password))
    total = len(collector.statements)
    executed = 0

    try:
        i = 0
        while i < total:
            batch = collector.statements[i:i + batch_size]
            attempt = 0
            while attempt < 5:
                try:
                    with driver.session() as session:
                        for stmt in batch:
                            session.run(stmt.query, **stmt.params)
                    i += len(batch)
                    executed += len(batch)
                    if executed % (batch_size * 5) == 0 or executed == total:
                        print(f"  {executed}/{total} statements executed")
                    break  # batch succeeded
                except (SessionExpired, ServiceUnavailable) as conn_err:
                    attempt += 1
                    wait = 2 ** attempt
                    print(f"  [WARN] Connection dropped at stmt {executed}: {conn_err}. Reconnecting (attempt {attempt}/5), wait {wait}s...")
                    time.sleep(wait)
                    try:
                        driver.close()
                    except Exception:
                        pass
                    driver = GraphDatabase.driver(uri, auth=(user, password))
    finally:
        driver.close()

    print(f"Done: {executed}/{total} statements executed against {uri}")


def dry_run_preview(collector: StatementCollector, limit: int = 20):
    print(f"Total statements: {len(collector)}\n")
    for stmt in collector.statements[:limit]:
        print("QUERY:", " ".join(stmt.query.split()))
        print("PARAMS:", stmt.params)
        print("-" * 60)
    if len(collector) > limit:
        print(f"... ({len(collector) - limit} more statements not shown)")


def main():
    parser = argparse.ArgumentParser(description="ICD-10-CM_Tabular_2026 XML -> Neo4j ingestion")
    parser.add_argument("xml_path", help="Path to the Tabular List XML file")
    parser.add_argument("--chapter", default="1", help="Chapter number to ingest (default: 1). Use 'all' for every chapter.")
    parser.add_argument("--dry-run", action="store_true", help="Print statements instead of executing them")
    parser.add_argument("--uri", default="bolt://localhost:7687")
    parser.add_argument("--user", default="neo4j")
    parser.add_argument("--password", default=None)
    parser.add_argument("--batch-size", type=int, default=200)
    args = parser.parse_args()

    chapter_filter = None if args.chapter == "all" else args.chapter

    print(f"Streaming {args.xml_path} (chapter filter: {args.chapter}) ...")
    collector = collect_statements(args.xml_path, chapter_filter)
    print(f"Collected {len(collector)} parameterized statements.\n")

    if args.dry_run:
        dry_run_preview(collector)
        return

    if not args.password:
        raise SystemExit("--password is required unless --dry-run is set")

    run_against_neo4j(collector, args.uri, args.user, args.password, args.batch_size)


if __name__ == "__main__":
    main()
