-- ============================================================================
-- ICD-10-CM Knowledge Graph Validation Test Queries
-- ============================================================================
-- These queries validate the Neo4j ingestion against the locked schema.
-- Run each query and verify the expected output patterns.
--
-- Schema nodes: Chapter, Block, DiseaseCode, ClinicalTerm, CodeRange
-- Relationships: HAS_BLOCK, CONTAINS, HAS_CHILD, HAS_INCLUDE, HAS_SEARCH_TERM,
--                EXCLUDES1, EXCLUDES2, CODE_FIRST, CODE_ALSO, USE_ADDITIONAL_CODE
-- ============================================================================


-- TEST 1: Node Type Counts
-- Expected: Chapter=1, Blocks≥1, DiseaseCodes≥10, ClinicalTerms≥10, CodeRanges≥1
MATCH (n)
RETURN labels(n)[0] as node_type, count(*) as count
ORDER BY count DESC;


-- TEST 2: Chapter Integrity
-- Expected: Chapter 1 exists with correct description
MATCH (c:Chapter {chapter_code: "1"})
RETURN c.chapter_code, c.description;


-- TEST 3: Chapter-to-Block Hierarchy
-- Expected: Chapter 1 should have ≥1 blocks (A00-A09, A15-A19, A20-A28, A30-A39, etc.)
MATCH (c:Chapter {chapter_code: "1"})-[:HAS_BLOCK]->(b:Block)
RETURN b.block_code, b.description
ORDER BY b.block_code;


-- TEST 4: Block-to-DiseaseCode Containment
-- Expected: Blocks should contain top-level codes (e.g., A00-A09 contains A00, A01, A02, etc.)
MATCH (b:Block)-[:CONTAINS]->(d:DiseaseCode)
RETURN b.block_code, d.code, d.description, d.billable
LIMIT 20;


-- TEST 5: Parent-Child Hierarchy (Nested Codes)
-- Expected: Parent codes should link to child codes (e.g., A01 -> A01.0 -> A01.00, A01.01, A01.02)
MATCH (parent:DiseaseCode)-[:HAS_CHILD]->(child:DiseaseCode)
RETURN parent.code as parent_code, parent.description as parent_description,
       child.code as child_code, child.description as child_description, child.billable
LIMIT 30;


-- TEST 6: Billable Flag Correctness
-- Expected: Leaf codes (no children) should be billable=true, parent codes should be billable=false
MATCH (d:DiseaseCode)
WHERE NOT (d)-[:HAS_CHILD]->()
RETURN d.code, d.description, d.billable, "LEAF" as type
LIMIT 10
UNION
MATCH (d:DiseaseCode)
WHERE (d)-[:HAS_CHILD]->()
RETURN d.code, d.description, d.billable, "PARENT" as type
LIMIT 10;


-- TEST 7: Clinical Terms (Includes)
-- Expected: DiseaseCodes should link to Include-type ClinicalTerms
MATCH (d:DiseaseCode)-[:HAS_INCLUDE]->(t:ClinicalTerm {type: "Include"})
RETURN d.code, d.description, t.term
LIMIT 20;


-- TEST 8: Organism Detection in Clinical Terms
-- Expected: Organism-tagged ClinicalTerms should exist (category='organism')
MATCH (d:DiseaseCode)-[:HAS_SEARCH_TERM]->(t:ClinicalTerm {category: "organism"})
RETURN d.code, d.description, t.term, t.category
LIMIT 15;


-- TEST 9: Search Terms and Synonyms
-- Expected: DiseaseCodes should link to Synonym-type ClinicalTerms
MATCH (d:DiseaseCode)-[:HAS_INCLUDE]->(t:ClinicalTerm {type: "Synonym"})
RETURN d.code, t.term, t.type
LIMIT 15;


-- TEST 10: Chapter-Level Includes
-- Expected: Chapter 1 should have HAS_INCLUDE edges to ClinicalTerms
--           (e.g., "diseases generally recognized as communicable or transmissible")
MATCH (c:Chapter {chapter_code: "1"})-[:HAS_INCLUDE]->(t:ClinicalTerm)
RETURN c.chapter_code, t.term, t.type;


-- TEST 11: Block-Level Includes
-- Expected: Blocks with scope-specific notes should have HAS_INCLUDE edges
MATCH (b:Block)-[:HAS_INCLUDE]->(t:ClinicalTerm)
RETURN b.block_code, t.term, t.type
LIMIT 10;


-- TEST 12: EXCLUDES1 Relationships (Mutually Exclusive)
-- Expected: DiseaseCodes linked via EXCLUDES1 to real DiseaseCode or CodeRange nodes
-- NOTE: DiseaseCode nodes use .code property, CodeRange nodes use .range property
--       Use coalesce(target.code, target.range) to handle both types uniformly
MATCH (d:DiseaseCode)-[:EXCLUDES1]->(target)
RETURN d.code, d.description, coalesce(target.code, target.range) as target_identifier, labels(target)[0] as target_type
LIMIT 15;


-- TEST 13: EXCLUDES2 Relationships (Not Included But Can Coexist)
-- Expected: DiseaseCodes linked via EXCLUDES2 to DiseaseCode or CodeRange
MATCH (d:DiseaseCode)-[:EXCLUDES2]->(target)
RETURN d.code, d.description, coalesce(target.code, target.range) as target_identifier, labels(target)[0] as target_type
LIMIT 15;


-- TEST 14: CODE_FIRST Relationships (Sequencing Rule)
-- Expected: DiseaseCodes that require a target code to be sequenced first
MATCH (d:DiseaseCode)-[:CODE_FIRST]->(target)
RETURN d.code, d.description, coalesce(target.code, target.range) as target_identifier, labels(target)[0] as target_type
LIMIT 15;


-- TEST 15: CODE_ALSO Relationships (Optional Companion Code)
-- Expected: DiseaseCodes that may also need a companion code
MATCH (d:DiseaseCode)-[:CODE_ALSO]->(target)
RETURN d.code, d.description, coalesce(target.code, target.range) as target_identifier, labels(target)[0] as target_type
LIMIT 10;


-- TEST 16: USE_ADDITIONAL_CODE Relationships (Organism/Specificity Codes)
-- Expected: DiseaseCodes requiring an additional code (e.g., organism specification)
MATCH (d:DiseaseCode)-[:USE_ADDITIONAL_CODE]->(target)
RETURN d.code, d.description, coalesce(target.code, target.range) as target_identifier, labels(target)[0] as target_type
LIMIT 15;


-- TEST 17: CodeRange Nodes Exist
-- Expected: CodeRange nodes for ranges (A04.0-A04.4, B95-B96) and wildcards (A05.-, A00.-)
MATCH (cr:CodeRange)
RETURN cr.range, cr.type
ORDER BY cr.range;


-- TEST 18: CodeRange Relationships (No DiseaseCode Pollution)
-- Expected: Verify that code ranges are linked via relationships but are NOT DiseaseCode nodes
-- Pattern: Only DiseaseCode -> CodeRange (no DiseaseCode -> DiseaseCode with hyphens)
MATCH (d:DiseaseCode)-[rel]->(cr:CodeRange)
RETURN d.code as source_code, type(rel) as relationship_type, cr.range as target_range, cr.type as range_type
LIMIT 15;


-- TEST 19: No Fake DiseaseCode Nodes Created for Ranges/Wildcards
-- Expected: DiseaseCode nodes should only contain valid single codes (no ranges like "A04.0-A04.4")
MATCH (d:DiseaseCode)
WHERE d.code CONTAINS "-" OR d.code ENDS WITH ".-"
RETURN d.code as INVALID_DISEASE_CODE
LIMIT 10;
-- If this query returns any rows, the parser failed to separate ranges from real codes.


-- TEST 20: Full Code Chain Example (Drill Down)
-- Expected: Trace a complete chain from Chapter → Block → Parent Code → Child Code → Terms
MATCH (c:Chapter {chapter_code: "1"})
      -[:HAS_BLOCK]->(b:Block {block_code: "A00-A09"})
      -[:CONTAINS]->(top:DiseaseCode)
      -[:HAS_CHILD]->(mid:DiseaseCode)
      -[:HAS_CHILD]->(leaf:DiseaseCode)
OPTIONAL MATCH (leaf)-[:HAS_INCLUDE]->(term:ClinicalTerm)
RETURN c.chapter_code, b.block_code, top.code, mid.code, leaf.code, leaf.billable, term.term
LIMIT 20;


-- TEST 21: Unlinked Notes Fallback (Prose-Only Instructions)
-- Expected: If any codes have prose-only excludes/instructions without extractable code refs,
--           they should appear as properties like "excludes1_unlinked_notes", "codeFirst_unlinked_notes"
MATCH (d:DiseaseCode)
WHERE d.excludes1_unlinked_notes IS NOT NULL
   OR d.excludes2_unlinked_notes IS NOT NULL
   OR d.codeFirst_unlinked_notes IS NOT NULL
   OR d.useAdditionalCode_unlinked_notes IS NOT NULL
RETURN d.code, d.description, d.excludes1_unlinked_notes, d.excludes2_unlinked_notes,
       d.codeFirst_unlinked_notes, d.useAdditionalCode_unlinked_notes
LIMIT 10;


-- TEST 22: All Relationship Types Present
-- Expected: Verify that all expected relationship types exist in the graph
CALL db.relationshipTypes() YIELD relationshipType
WHERE relationshipType IN ["HAS_BLOCK", "CONTAINS", "HAS_CHILD", "HAS_INCLUDE", 
                            "HAS_SEARCH_TERM", "EXCLUDES1", "EXCLUDES2", "CODE_FIRST", 
                            "CODE_ALSO", "USE_ADDITIONAL_CODE"]
RETURN relationshipType;


-- TEST 23: Relationship Count by Type
-- Expected: Get counts for each relationship type to validate distribution
MATCH ()-[r]->()
RETURN type(r) as relationship_type, count(*) as count
ORDER BY count DESC;


-- TEST 24: Index and Constraint Check
-- Expected: Verify that unique constraints and indexes are in place
SHOW CONSTRAINTS;


-- TEST 25: Sample Validation Chain (Real-World Example: Typhoid)
-- Expected: Retrieve all info needed for validating a claimed code A01.02
--           (Typhoid fever with heart involvement)
MATCH (c:Chapter)-[:HAS_BLOCK]->(b:Block)-[:CONTAINS]->(d:DiseaseCode {code: "A01"})
      -[:HAS_CHILD]->(sub:DiseaseCode {code: "A01.0"})
      -[:HAS_CHILD]->(leaf:DiseaseCode {code: "A01.02"})
OPTIONAL MATCH (leaf)-[:HAS_INCLUDE]->(inc:ClinicalTerm)
OPTIONAL MATCH (leaf)-[:EXCLUDES1]->(ex1)
OPTIONAL MATCH (leaf)-[:EXCLUDES2]->(ex2)
OPTIONAL MATCH (leaf)-[:USE_ADDITIONAL_CODE]->(uac)
RETURN 
  c.chapter_code as chapter,
  b.block_code as block,
  d.code as category, d.description as category_description,
  sub.code as subcategory, sub.description as subcategory_description,
  leaf.code as code, leaf.description as code_description, leaf.billable,
  collect(DISTINCT inc.term) as inclusion_terms,
  collect(DISTINCT coalesce(ex1.code, ex1.range)) as excludes1_codes,
  collect(DISTINCT coalesce(ex2.code, ex2.range)) as excludes2_codes,
  collect(DISTINCT coalesce(uac.code, uac.range)) as use_additional_codes;


-- TEST 26: Count Nodes by Label
-- Expected: Summary of node counts to confirm ingestion completeness
MATCH (n:Chapter) RETURN "Chapter" as node_label, count(*) as count
UNION
MATCH (n:Block) RETURN "Block", count(*)
UNION
MATCH (n:DiseaseCode) RETURN "DiseaseCode", count(*)
UNION
MATCH (n:ClinicalTerm) RETURN "ClinicalTerm", count(*)
UNION
MATCH (n:CodeRange) RETURN "CodeRange", count(*);


-- TEST 27: Orphaned Nodes Check
-- Expected: Verify there are no disconnected nodes (every node should have at least one relationship)
--           For DiseaseCode, this is expected to catch ingestion errors
MATCH (d:DiseaseCode)
WHERE NOT (d)-[]-()
RETURN d.code, d.description as POTENTIALLY_ORPHANED_CODE;
-- If results appear here, those codes may not have been properly linked to blocks or hierarchy.


-- TEST 28: Circular Dependency Check
-- Expected: Ensure no code is its own ancestor via HAS_CHILD traversal
--           (sanity check that hierarchy is acyclic)
MATCH (d:DiseaseCode)
WHERE (d)-[:HAS_CHILD*]->(d)
RETURN d.code as CIRCULAR_CODE;
-- This should return no results for a valid tree.


-- TEST 29: Multi-Level Hierarchy Depth
-- Expected: Verify that codes reach the expected hierarchy depth (3-4 levels for ICD-10-CM)
MATCH path = (top:DiseaseCode)-[:HAS_CHILD*]->(leaf:DiseaseCode)
WHERE NOT ()-[:HAS_CHILD]->(top) AND NOT (leaf)-[:HAS_CHILD]->()
RETURN length(path) as depth, count(*) as code_chains
ORDER BY depth DESC;


-- TEST 30: Validation Readiness Check
-- Expected: Summarize the graph state to confirm it's ready for the validation agent
CALL { MATCH (c:Chapter) RETURN count(c) as chapters }
CALL { MATCH (b:Block) RETURN count(b) as blocks }
CALL { MATCH (d:DiseaseCode) RETURN count(d) as disease_codes }
CALL { MATCH (t:ClinicalTerm) RETURN count(t) as clinical_terms }
CALL { MATCH (cr:CodeRange) RETURN count(cr) as code_ranges }
CALL { MATCH ()-[r]->() RETURN count(r) as total_relationships }
RETURN chapters, blocks, disease_codes, clinical_terms, code_ranges, total_relationships;
