import fitz  # PyMuPDF
import re
import os
import json
from pydantic import BaseModel, Field
from dotenv import load_dotenv
import logging

# Set up logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Load .env from the parent directory
dotenv_path = os.path.join(os.path.dirname(__file__), '..', '..', '..', '.env')
load_dotenv(dotenv_path)

# --- CONFIGURATION ---
PDF_PATH = os.path.join(os.path.dirname(__file__), '..', 'chapter-1.pdf')
COLLECTION_NAME = "icd10_guidelines"

# --- DUAL-MODE SECRET RESOLUTION ---
_azure_openai_key: str | None = None
_azure_openai_endpoint: str | None = None
_cosmos_connection_string: str | None = None
_azure_openai_deployment: str = os.environ.get("AZURE_OPENAI_EMBEDDING_DEPLOYMENT", "text-embedding-3-small")

def _resolve_secrets():
    global _azure_openai_key, _azure_openai_endpoint, _cosmos_connection_string
    
    keyvault_url = os.environ.get("AZURE_KEY_VAULT_URL")
    
    if keyvault_url:
        try:
            from azure.identity import DefaultAzureCredential
            from azure.keyvault.secrets import SecretClient
            
            credential = DefaultAzureCredential()
            client = SecretClient(vault_url=keyvault_url, credential=credential)
            
            _azure_openai_key = client.get_secret("AZURE-OPENAI-KEY").value
            _azure_openai_endpoint = client.get_secret("AZURE-OPENAI-ENDPOINT").value
            _cosmos_connection_string = client.get_secret("COSMOS-DB-CONNECTION-STRING").value
            
            logger.info("Successfully resolved secrets from Azure Key Vault.")
            return
        except ImportError:
            logger.warning("azure-identity SDK not installed. Falling back to .env")
        except Exception as e:
            logger.warning(f"Key Vault lookup failed ({e}). Falling back to .env")
            
    # Fallback: Read directly from environment / .env
    _azure_openai_key = os.environ.get("AZURE_OPENAI_KEY")
    _azure_openai_endpoint = os.environ.get("AZURE_OPENAI_ENDPOINT")
    _cosmos_connection_string = os.environ.get("COSMOS_DB_CONNECTION_STRING")
    logger.info("Resolved secrets from local .env fallback.")

_resolve_secrets()

if not _cosmos_connection_string or not _azure_openai_key:
    logger.error("Missing critical connection strings for Cosmos DB or Azure OpenAI. Cannot proceed.")
    exit(1)

# --- AZURE OPENAI CLIENT ---
from openai import AzureOpenAI
import pymongo

aoai_client = AzureOpenAI(
    api_key=_azure_openai_key,
    api_version="2023-05-15",
    azure_endpoint=_azure_openai_endpoint
)

# --- MONGODB (COSMOS DB vCORE) CLIENT ---
mongo_client = pymongo.MongoClient(_cosmos_connection_string)
db = mongo_client["medical_coding_db"]
collection = db[COLLECTION_NAME]

def setup_vector_index():
    """Sets up the Cosmos DB vCore vector index if it doesn't exist."""
    # Cosmos DB vCore vector index configuration (HNSW)
    try:
        # Create collection if it doesn't exist
        if COLLECTION_NAME not in db.list_collection_names():
            db.create_collection(COLLECTION_NAME)
            
        # Create Vector Index
        db.command({
            "createIndexes": COLLECTION_NAME,
            "indexes": [
                {
                    "name": "vectorSearchIndex",
                    "key": {
                        "embedding": "cosmosSearch"
                    },
                    "cosmosSearchOptions": {
                        "kind": "vector-ivf",
                        "numLists": 1,
                        "similarity": "COS",
                        "dimensions": 1536
                    }
                }
            ]
        })
        logger.info("Vector index successfully created or already exists.")
    except Exception as e:
        logger.warning(f"Index creation warning (might already exist): {e}")

# --- ETL FUNCTIONS ---

def extract_text_from_pdf(pdf_path):
    logger.info(f"Reading {pdf_path}...")
    doc = fitz.open(pdf_path)
    full_text = ""
    for page in doc:
        full_text += page.get_text() + "\n"
    return full_text

def split_text_by_disease_entity(text):
    logger.info("Chunking text by Level 2 headers (Disease Entities)...")
    pattern = r'(?=\n\s*[a-z]\.\s+[A-Z])'
    chunks = re.split(pattern, text)
    cleaned_chunks = [chunk.strip() for chunk in chunks if len(chunk.strip()) > 50]
    logger.info(f"Found {len(cleaned_chunks)} distinct disease entity chunks.")
    return cleaned_chunks

def generate_metadata_with_llm(chunk_text):
    """Use Azure OpenAI GPT-4o to extract disease name"""
    try:
        response = aoai_client.chat.completions.create(
            model=os.environ.get("AZURE_OPENAI_DEPLOYMENT", "gpt-4o"),
            messages=[
                {"role": "system", "content": "You are a strict data extraction assistant. Your ONLY job is to output the short disease name."},
                {"role": "user", "content": f"Extract the primary disease entity name from the following text. Respond ONLY with the short disease name (e.g., 'HIV', 'Sepsis', 'MRSA', 'Zika'). Do not write sentences. Do not explain.\n\nText:\n{chunk_text[:500]}\n\nDisease Name:"}
            ],
            max_tokens=15
        )
        content = response.choices[0].message.content
        if content is None:
            return "Unknown Entity"
        entity_name = content.strip().replace("'", "").replace('"', "")
        return entity_name
    except Exception as e:
        logger.error(f"LLM Metadata error: {e}")
        return "Unknown Entity"

def generate_embedding(text):
    """Generate embedding using Azure OpenAI"""
    response = aoai_client.embeddings.create(
        input=text,
        model=_azure_openai_deployment
    )
    return response.data[0].embedding

def process_and_store_chunks(chunks):
    logger.info("Processing chunks and storing in Cosmos DB...")
    
    documents_to_insert = []
    
    for i, chunk in enumerate(chunks):
        if not re.match(r'^[a-z]\.\s+', chunk) and i == 0:
            continue
            
        chunk_id = f"guideline-IC-chap1-{i}"
        letter_match = re.match(r'^([a-z])\.\s+', chunk)
        section_letter = letter_match.group(1) if letter_match else f"unknown-{i}"
        exact_source_citation = f"Section I.C.1.{section_letter}"
        
        disease_entity = generate_metadata_with_llm(chunk)
        embedding = generate_embedding(chunk)
        
        logger.info(f"Processed chunk {i} ({exact_source_citation}): {disease_entity}...")
        
        documents_to_insert.append({
            "_id": chunk_id,
            "text": chunk,
            "embedding": embedding,
            "metadata": {
                "chunk_id": chunk_id,
                "disease_entity": disease_entity,
                "chapter": "Chapter 1",
                "source": exact_source_citation
            }
        })
        
    if documents_to_insert:
        # Upsert documents
        for doc in documents_to_insert:
            collection.update_one({"_id": doc["_id"]}, {"$set": doc}, upsert=True)
        logger.info(f"Successfully upserted {len(documents_to_insert)} chunks in Cosmos DB.")

def test_query(query_text):
    logger.info(f"\n--- Testing Vector Query: '{query_text}' ---")
    query_embedding = generate_embedding(query_text)
    
    # Cosmos DB Vector Search Pipeline
    pipeline = [
        {
            "$search": {
                "cosmosSearch": {
                    "vector": query_embedding,
                    "path": "embedding",
                    "k": 1
                },
                "returnStoredSource": True
            }
        },
        {
            "$project": {
                "embedding": 0,
                "score": {"$meta": "searchScore"}
            }
        }
    ]
    
    results = list(collection.aggregate(pipeline))
    
    if results:
        top_match = results[0]
        logger.info(f"Matched Entity: {top_match['metadata']['disease_entity']}")
        logger.info(f"Source: {top_match['metadata']['source']}")
        logger.info(f"Score: {top_match['score']}")
        logger.info("Snippet:")
        logger.info(top_match['text'][:300] + "...\n")
    else:
        logger.info("No results found.")

if __name__ == "__main__":
    setup_vector_index()
    raw_text = extract_text_from_pdf(PDF_PATH)
    semantic_chunks = split_text_by_disease_entity(raw_text)
    process_and_store_chunks(semantic_chunks)
    test_query("What are the rules for coding Severe Sepsis?")
