import fitz  # PyMuPDF
import re
import os
import json
import chromadb
from chromadb.utils import embedding_functions
from openai import OpenAI
from pydantic import BaseModel, Field
from dotenv import load_dotenv

# Load .env from the parent directory (capstone_danish)
dotenv_path = os.path.join(os.path.dirname(__file__), '..', '.env')
load_dotenv(dotenv_path)

# --- CONFIGURATION ---
PDF_PATH = os.path.join(os.path.dirname(__file__), '..', 'guideline_data', 'chapter-1.pdf')
CHROMA_DB_PATH = os.path.join(os.path.dirname(__file__), '..', 'rag_chroma_db')
COLLECTION_NAME = "icd10_guidelines"

# Load OpenRouter API key from .env (User named it API_KEY)
OPENROUTER_API_KEY = os.environ.get("OPENROUTER_API_KEY", "sk-or-v1-dummy")

# Initialize OpenRouter Client (using OpenAI SDK)
client = OpenAI(
    base_url="https://openrouter.ai/api/v1",
    api_key=OPENROUTER_API_KEY,
)

# Initialize local HuggingFace embedding model (Free, runs locally)
embedding_func = embedding_functions.SentenceTransformerEmbeddingFunction(
    model_name="all-MiniLM-L6-v2"
)

# Initialize ChromaDB
chroma_client = chromadb.PersistentClient(path=CHROMA_DB_PATH)
collection = chroma_client.get_or_create_collection(
    name=COLLECTION_NAME, 
    embedding_function=embedding_func,
    metadata={"hnsw:space": "cosine"}
)

# Pydantic schema for structured LLM output
class ChunkMetadata(BaseModel):
    disease_entity: str = Field(description="The primary disease or condition this guideline covers (e.g., 'Sepsis', 'HIV', 'Zika virus')")

def extract_text_from_pdf(pdf_path):
    print(f"Reading {pdf_path}...")
    doc = fitz.open(pdf_path)
    full_text = ""
    for page in doc:
        full_text += page.get_text() + "\n"
    return full_text

def split_text_by_disease_entity(text):
    print("Chunking text by Level 2 headers (Disease Entities)...")
    # The PDF is perfectly formatted with "a. ", "b. ", "c. " followed by a capitalized word for disease entities.
    # We will use Regex to split it exactly at these boundaries.
    
    # Pattern looks for: newline, optional spaces, a single lowercase letter, a period, space, and a Capital letter.
    pattern = r'(?=\n\s*[a-z]\.\s+[A-Z])'
    
    # Split the text
    chunks = re.split(pattern, text)
    
    # Clean up empty chunks and trim whitespace
    cleaned_chunks = [chunk.strip() for chunk in chunks if len(chunk.strip()) > 50]
    
    print(f"Found {len(cleaned_chunks)} distinct disease entity chunks.")
    return cleaned_chunks

def generate_metadata_with_llm(chunk_text):
    # Use OpenRouter to extract the clean 'disease_entity' name for metadata
    try:
        response = client.chat.completions.create(
            # You can change this to any free model on OpenRouter
            model="google/gemma-4-31b-it:free",
            messages=[
                {"role": "system", "content": "You are a strict data extraction assistant. Your ONLY job is to output the short disease name."},
                {"role": "user", "content": f"Extract the primary disease entity name from the following text. Respond ONLY with the short disease name (e.g., 'HIV', 'Sepsis', 'MRSA', 'Zika'). Do not write sentences. Do not explain.\n\nText:\n{chunk_text[:500]}\n\nDisease Name:"}
            ],
            max_tokens=15
        )
        content = response.choices[0].message.content
        if content is None:
            return "Unknown Entity"
        entity_name = content.strip().replace("'", "").replace('"', "")
        return entity_name
    except Exception as e:
        print(f"LLM Metadata error: {e}")
        return "Unknown Entity"

def process_and_store_chunks(chunks):
    print("Processing chunks and storing in Vector DB...")
    
    ids = []
    documents = []
    metadatas = []
    
    for i, chunk in enumerate(chunks):
        # We skip the very first chunk if it's just the introduction text before 'a.'
        if not re.match(r'^[a-z]\.\s+', chunk) and i == 0:
            continue
            
        chunk_id = f"guideline-IC-chap1-{i}"
        
        # Extract the specific section letter (a, b, c...) for perfect audit traceability
        letter_match = re.match(r'^([a-z])\.\s+', chunk)
        section_letter = letter_match.group(1) if letter_match else f"unknown-{i}"
        exact_source_citation = f"Section I.C.1.{section_letter}"
        
        # Call OpenRouter to get the clean disease name
        disease_entity = generate_metadata_with_llm(chunk)
        
        print(f"Storing chunk {i} ({exact_source_citation}): {disease_entity}...")
        
        ids.append(chunk_id)
        documents.append(chunk)
        metadatas.append({
            "chunk_id": chunk_id,
            "disease_entity": disease_entity,
            "chapter": "Chapter 1",
            "source": exact_source_citation
        })
        
    # Add to ChromaDB (this will automatically generate embeddings using the local model)
    collection.add(
        documents=documents,
        metadatas=metadatas,
        ids=ids
    )
    print(f"Successfully stored {len(ids)} chunks in ChromaDB at {CHROMA_DB_PATH}")

def test_query(query_text):
    print(f"\n--- Testing Query: '{query_text}' ---")
    results = collection.query(
        query_texts=[query_text],
        n_results=1
    )
    
    if results['documents'] and len(results['documents'][0]) > 0:
        print(f"Matched Entity: {results['metadatas'][0][0]['disease_entity']}")
        print(f"Source: {results['metadatas'][0][0]['source']}")
        print("Snippet:")
        print(results['documents'][0][0][:300] + "...\n")
    else:
        print("No results found.")

if __name__ == "__main__":
    if OPENROUTER_API_KEY == "sk-or-v1-dummy":
        print("WARNING: You are using a dummy OpenRouter API key. Please set OPENROUTER_API_KEY in your terminal.")
    
    # 1. Extract Text
    raw_text = extract_text_from_pdf(PDF_PATH)
    
    # 2. Semantic Split (Regex)
    semantic_chunks = split_text_by_disease_entity(raw_text)
    
    # 3. Enrich & Store (OpenRouter + SentenceTransformers + ChromaDB)
    process_and_store_chunks(semantic_chunks)
    
    # 4. Verification Test
    test_query("What are the rules for coding Severe Sepsis?")
