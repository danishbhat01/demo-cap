"""
Deterministic Graph-Rule Reconciliation Engine for ICD-10-CM Claims.

Separates clinical evidence evaluation (LLM) from structural rule validation (Python):
1. Normalizes rule targets (Exact codes, Closed Ranges B95-B97, Wildcards A05.-).
2. Evaluates EXCLUDES1 pairwise across all candidate codes (order-independent).
3. Enforces CODE_FIRST presence and sequencing order.
4. Evaluates USE_ADDITIONAL_CODE companions (exact and ranges), producing INCOMPLETE status if absent.
5. Records EXCLUDES2 and CODE_ALSO audits.
6. Preserves the untouched LLM clinical evaluation without mutation.
"""

from __future__ import annotations
import re
from typing import Dict, List, Optional, Any
from dataclasses import dataclass, field
from guardrails import resolve_principal_conflict

# ---------------------------------------------------------------------------
# Feature flag: set to True to enable three-state CODE_FIRST / USE_ADDITIONAL_CODE
# conditional evaluation (NOT_APPLICABLE / SATISFIED / APPLICABLE_BUT_UNSATISFIED).
# Set to False to revert to the old hard-blocker behaviour (safe rollback).
# ---------------------------------------------------------------------------
USE_CONDITIONAL_RULES: bool = True


@dataclass(frozen=True)
class RuleTarget:
    target: str
    target_type: str = "DiseaseCode"

    @classmethod
    def from_dict_or_str(cls, val: Any) -> RuleTarget:
        if isinstance(val, dict):
            return cls(
                target=val.get("target") or val.get("code") or val.get("range") or "",
                target_type=val.get("target_type") or "DiseaseCode"
            )
        return cls(target=str(val), target_type="DiseaseCode")


class RangeMatcher:
    """Matches candidate ICD-10 codes against exact codes, closed ranges, and wildcards."""

    @staticmethod
    def normalize_code(code: str) -> str:
        return code.strip().upper().replace(" ", "")

    @classmethod
    def matches(cls, candidate: str, rule_target: str | RuleTarget) -> bool:
        if isinstance(rule_target, RuleTarget):
            target_str = rule_target.target
        else:
            target_str = str(rule_target)

        cand = cls.normalize_code(candidate)
        tgt = cls.normalize_code(target_str)

        if not cand or not tgt:
            return False

        # 1. Exact match (e.g., "B95.62" == "B95.62" or "B20" == "B20")
        if cand == tgt:
            return True

        # 2. Wildcard match (e.g., "A05.-" or "A05.*" or "A05-")
        if tgt.endswith(".-") or tgt.endswith(".*"):
            prefix = tgt[:-2]
            return cand.startswith(prefix)
        if tgt.endswith("-") and not re.match(r'^[A-Z][0-9]{2}-[A-Z][0-9]{2}', tgt):
            prefix = tgt[:-1]
            return cand.startswith(prefix)

        # 3. Closed Range match (e.g., "B95-B97" or "A15-A19")
        range_match = re.match(r'^([A-Z][0-9]{2}(?:\.[0-9A-Z]+)?)-([A-Z][0-9]{2}(?:\.[0-9A-Z]+)?)$', tgt)
        if range_match:
            start_code, end_code = range_match.groups()
            cand_cat = cand[:3]
            start_cat = start_code[:3]
            end_cat = end_code[:3]

            # If categories have identical letter prefix, compare numerically/lexicographically
            if start_cat <= cand_cat <= end_cat:
                return True

        return False


def find_organism_for_code(evidence_db: dict, target_code: str = "", disease_name: str = "") -> Optional[str]:
    """Traverses evidence_db['diagnoses'] to find causative organisms."""
    if not isinstance(evidence_db, dict):
        return None

    diagnoses = evidence_db.get("diagnoses", {})
    if not isinstance(diagnoses, dict):
        return None

    # 1. If disease_name matches a diagnosis key, return its organism
    if disease_name and disease_name in diagnoses:
        org = diagnoses[disease_name].get("organism")
        if org:
            return org

    # 2. Scan all confirmed diagnoses for any documented organism
    for name, details in diagnoses.items():
        if isinstance(details, dict) and details.get("organism"):
            return details["organism"]

    return None


def check_condition_active_in_evidence(
    activation_target: str,
    documented_evidence_codes: List[str] | set[str],
) -> bool:
    """
    Three-state activation check for conditional CODE_FIRST rules using pure code matching.

    Returns True if the activation_target (exact code, wildcard like T81.44-, or range)
    matches any code in `documented_evidence_codes` (codes mapped from confirmed chart diagnoses).
    Returns False if absent, meaning the rule is NOT APPLICABLE.

    Zero NLP, zero similarity thresholds, purely deterministic O(N) code matching.
    """
    if not documented_evidence_codes:
        return False

    target_rule = RuleTarget.from_dict_or_str(activation_target)
    return any(RangeMatcher.matches(code, target_rule) for code in documented_evidence_codes)


@dataclass
class ReconciledAuditEntry:
    code: str
    clinical_evaluation: dict  # Raw, untouched output from LLM Validator
    final_status: str          # VALID | INVALID | INCOMPLETE | SWAP | MANUAL_REVIEW
    reconciliation_notes: list[str] = field(default_factory=list)
    rules_evaluated: dict = field(default_factory=dict)
    sequencing_position: str = "secondary"

    def to_dict(self) -> dict:
        return {
            "code": self.code,
            "final_status": self.final_status,
            "decision": self.final_status,  # Backwards compatibility for UI
            "rationale": self.clinical_evaluation.get("rationale", ""),
            "chart_evidence": self.clinical_evaluation.get("chart_evidence", ""),
            "coding_rule": self.clinical_evaluation.get("coding_rule", ""),
            "swap_to": self.clinical_evaluation.get("swap_to"),
            "companion_codes_required": self.clinical_evaluation.get("companion_codes_required", []),
            "sequencing_position": self.sequencing_position,
            "reconciliation_notes": self.reconciliation_notes,
            "rules_evaluated": self.rules_evaluated,
            "clinical_evaluation": self.clinical_evaluation,
        }


def reconcile_claim_rules(
    clinical_verdicts: List[dict],
    tabular_rules_by_code: Dict[str, dict],
    evidence_db: dict,
    documented_evidence_codes: Optional[List[str]] = None,
) -> Dict[str, Any]:
    """
    Authoritative deterministic graph-rule reconciliation across the entire claim.

    `documented_evidence_codes`: List of all ICD-10 codes mapped from confirmed
    chart diagnoses (by Node 0/1). Used by three-state conditional rule evaluation
    to determine if a rule is activated without doing runtime NLP.

    Does NOT modify clinical_verdicts in place. Returns a structured reconciliation result.
    """
    entries: List[ReconciledAuditEntry] = []
    validated_sequence: List[dict] = []
    dropped_codes: List[dict] = []
    
    # 1. Initialize candidate entries while preserving raw clinical evaluations
    for cv in clinical_verdicts:
        code = cv.get("code", "")
        raw_decision = cv.get("decision", "VALID")
        seq_pos = cv.get("sequencing_position") or "secondary"

        entries.append(
            ReconciledAuditEntry(
                code=code,
                clinical_evaluation=cv,
                final_status=raw_decision,
                sequencing_position=seq_pos,
                rules_evaluated={
                    "EXCLUDES1": [],
                    "CODE_FIRST": [],
                    "USE_ADDITIONAL_CODE": [],
                    "EXCLUDES2": [],
                    "CODE_ALSO": []
                }
            )
        )

    all_claimed_codes = [e.code for e in entries]

    # 1.5. Enforce exactly ONE Principal Diagnosis
    principal_entries = [e for e in entries if e.sequencing_position == "principal" and e.final_status == "VALID"]
    if len(principal_entries) > 1:
        print(f"\n[Rule Engine] Detected {len(principal_entries)} competing principal diagnoses. Invoking Tie-Breaker...")
        competing_codes = [e.code for e in principal_entries]
        admission_evidence = evidence_db.get("admission", [])
        
        winning_code = resolve_principal_conflict(competing_codes, admission_evidence)
        
        for e in principal_entries:
            if e.code == winning_code:
                e.sequencing_position = "principal"
            else:
                e.sequencing_position = "secondary"
                e.reconciliation_notes.append(
                    f"Demoted to secondary: '{winning_code}' was determined to be the true principal admission reason."
                )

    # 2. Evaluate EXCLUDES1 Pairwise Across All Candidates (Order-Independent)
    # If Code A has EXCLUDES1 Code B, and both are present:
    for i, entry_a in enumerate(entries):
        rules_a = tabular_rules_by_code.get(entry_a.code, {})
        excl1_rules = [RuleTarget.from_dict_or_str(r) for r in rules_a.get("EXCLUDES1", [])]

        for j, entry_b in enumerate(entries):
            if i == j:
                continue

            for excl_rule in excl1_rules:
                if RangeMatcher.matches(entry_b.code, excl_rule):
                    entry_a.rules_evaluated["EXCLUDES1"].append({
                        "conflicting_code": entry_b.code,
                        "rule_target": excl_rule.target,
                        "status": "VIOLATION"
                    })

                    # Deterministic priority resolution
                    if entry_a.code == "B20" and entry_b.code == "Z21":
                        entry_b.final_status = "INVALID"
                        entry_b.reconciliation_notes.append(
                            f"EXCLUDES1 violation: {entry_b.code} (Asymptomatic HIV) is mutually exclusive with active {entry_a.code}."
                        )
                    elif entry_b.code == "B20" and entry_a.code == "Z21":
                        entry_a.final_status = "INVALID"
                        entry_a.reconciliation_notes.append(
                            f"EXCLUDES1 violation: {entry_a.code} (Asymptomatic HIV) is mutually exclusive with active {entry_b.code}."
                        )
                    else:
                        # Drop secondary code if one is principal
                        if entry_a.sequencing_position == "principal" and entry_b.sequencing_position != "principal":
                            entry_b.final_status = "INVALID"
                            entry_b.reconciliation_notes.append(
                                f"EXCLUDES1 violation: Incompatible with principal code {entry_a.code}."
                            )
                        elif entry_b.sequencing_position == "principal" and entry_a.sequencing_position != "principal":
                            entry_a.final_status = "INVALID"
                            entry_a.reconciliation_notes.append(
                                f"EXCLUDES1 violation: Incompatible with principal code {entry_b.code}."
                            )

    # 3. Evaluate CODE_FIRST Dependencies & Ordering
    # Active candidate codes that passed EXCLUDES1
    active_codes = [e.code for e in entries if e.final_status in ("VALID", "ADD_COMPANION", "SWAP")]

    for entry in entries:
        if entry.final_status not in ("VALID", "ADD_COMPANION", "SWAP"):
            continue

        rules = tabular_rules_by_code.get(entry.code, {})
        code_first_rules = [RuleTarget.from_dict_or_str(r) for r in rules.get("CODE_FIRST", [])]
        raw_cf_rules = rules.get("CODE_FIRST", [])

        for idx, cf_rule in enumerate(code_first_rules):
            raw_rule = raw_cf_rules[idx] if idx < len(raw_cf_rules) else {}
            is_conditional = raw_rule.get("is_conditional", False) if isinstance(raw_rule, dict) else False

            if USE_CONDITIONAL_RULES and is_conditional:
                # -------------------------------------------------------
                # Three-state conditional evaluation
                # -------------------------------------------------------
                condition_active = check_condition_active_in_evidence(
                    cf_rule.target, documented_evidence_codes or []
                )

                if not condition_active:
                    # State 1: NOT APPLICABLE — underlying condition not in chart
                    entry.rules_evaluated["CODE_FIRST"].append({
                        "required_target": cf_rule.target,
                        "condition": raw_rule.get("condition", ""),
                        "status": "NOT_APPLICABLE",
                        "note": raw_rule.get("note", ""),
                    })
                    continue

                # Condition IS active — check if required code is present
                matched_code = next((c for c in active_codes if RangeMatcher.matches(c, cf_rule)), None)

                if matched_code:
                    # State 2: SATISFIED
                    entry.sequencing_position = "secondary"
                    for other in entries:
                        if other.code == matched_code and other.sequencing_position != "principal":
                            other.sequencing_position = "principal"
                    entry.rules_evaluated["CODE_FIRST"].append({
                        "required_target": cf_rule.target,
                        "condition": raw_rule.get("condition", ""),
                        "satisfied_by": matched_code,
                        "status": "SATISFIED",
                        "note": raw_rule.get("note", ""),
                    })
                else:
                    # State 3: APPLICABLE_BUT_UNSATISFIED — real coding error
                    condition_label = raw_rule.get("condition") or cf_rule.target
                    entry.final_status = "INVALID"
                    entry.reconciliation_notes.append(
                        f"Missing mandatory underlying condition: Chart documents '{condition_label}' "
                        f"which requires {cf_rule.target} to be coded and sequenced first "
                        f"per Tabular instruction '{raw_rule.get('note', '')}'"
                    )
                    entry.rules_evaluated["CODE_FIRST"].append({
                        "required_target": cf_rule.target,
                        "condition": raw_rule.get("condition", ""),
                        "status": "APPLICABLE_BUT_UNSATISFIED",
                        "note": raw_rule.get("note", ""),
                    })
            else:
                # -------------------------------------------------------
                # Legacy hard-blocker path (non-conditional rules, or
                # USE_CONDITIONAL_RULES=False fallback)
                # -------------------------------------------------------
                # Keep existing O/T prefix exemptions for obstetric / injury codes
                if (cf_rule.target.startswith("O") and not any(c.startswith("O") for c in all_claimed_codes)) or \
                   (cf_rule.target.startswith("T") and not any(c.startswith("T") for c in all_claimed_codes)):
                    entry.rules_evaluated["CODE_FIRST"].append({
                        "required_target": cf_rule.target,
                        "status": "NOT_APPLICABLE_CONDITIONAL_COMPLICATION"
                    })
                    continue

                matched_code = next((c for c in active_codes if RangeMatcher.matches(c, cf_rule)), None)

                if not matched_code:
                    entry.final_status = "INVALID"
                    entry.reconciliation_notes.append(
                        f"Mandatory CODE_FIRST dependency missing: expected underlying condition satisfying '{cf_rule.target}'."
                    )
                    entry.rules_evaluated["CODE_FIRST"].append({
                        "required_target": cf_rule.target,
                        "status": "MISSING_DEPENDENCY"
                    })
                else:
                    entry.sequencing_position = "secondary"
                    for other in entries:
                        if other.code == matched_code and other.sequencing_position != "principal":
                            other.sequencing_position = "principal"
                    entry.rules_evaluated["CODE_FIRST"].append({
                        "required_target": cf_rule.target,
                        "satisfied_by": matched_code,
                        "status": "SATISFIED"
                    })

    # 4. Evaluate USE_ADDITIONAL_CODE Companions
    # Re-evaluate active valid codes after CODE_FIRST pass
    valid_candidates = [e for e in entries if e.final_status in ("VALID", "ADD_COMPANION")]

    for entry in entries:
        if entry.final_status not in ("VALID", "ADD_COMPANION"):
            continue

        rules = tabular_rules_by_code.get(entry.code, {})
        raw_uac_rules = rules.get("USE_ADDITIONAL_CODE", [])

        # Check Tabular USE_ADDITIONAL_CODE rules
        for raw_rule in raw_uac_rules:
            uac_rule = RuleTarget.from_dict_or_str(raw_rule)

            # Check if this companion code/condition is documented in the clinical encounter
            condition_active = check_condition_active_in_evidence(
                uac_rule.target, documented_evidence_codes or []
            )

            # If the companion condition is NOT documented in the chart, it is NOT APPLICABLE
            # (An encounter is not incomplete for omitting a manifestation/complication the patient does not have)
            if not condition_active:
                entry.rules_evaluated["USE_ADDITIONAL_CODE"].append({
                    "target": uac_rule.target,
                    "condition": raw_rule.get("condition", "") if isinstance(raw_rule, dict) else "",
                    "status": "NOT_APPLICABLE",
                    "note": raw_rule.get("note", "") if isinstance(raw_rule, dict) else "",
                })
                continue

            satisfied = any(
                RangeMatcher.matches(other.code, uac_rule)
                for other in valid_candidates
                if other.code != entry.code
            )

            if satisfied:
                entry.rules_evaluated["USE_ADDITIONAL_CODE"].append({
                    "target": uac_rule.target,
                    "status": "SATISFIED"
                })
            else:
                entry.rules_evaluated["USE_ADDITIONAL_CODE"].append({
                    "target": uac_rule.target,
                    "status": "MISSING_COMPANION"
                })
                # If code is otherwise valid, mark it INCOMPLETE due to missing mandatory companion
                if entry.final_status == "VALID" or entry.final_status == "ADD_COMPANION":
                    entry.final_status = "INCOMPLETE"
                    entry.reconciliation_notes.append(
                        f"Clinically supported, but INCOMPLETE: documented companion code/range '{uac_rule.target}' is missing from claim."
                    )

        # Also incorporate LLM-requested companion codes if present
        llm_companions = entry.clinical_evaluation.get("companion_codes_required", [])
        for comp in llm_companions:
            uac_rule = RuleTarget.from_dict_or_str(comp)
            if any(r.get("target") == uac_rule.target for r in entry.rules_evaluated["USE_ADDITIONAL_CODE"]):
                continue

            satisfied = any(
                RangeMatcher.matches(other.code, uac_rule)
                for other in valid_candidates
                if other.code != entry.code
            )
            if satisfied:
                entry.rules_evaluated["USE_ADDITIONAL_CODE"].append({
                    "target": uac_rule.target,
                    "status": "SATISFIED"
                })
            else:
                entry.rules_evaluated["USE_ADDITIONAL_CODE"].append({
                    "target": uac_rule.target,
                    "status": "MISSING_COMPANION"
                })
                if entry.final_status == "VALID" or entry.final_status == "ADD_COMPANION":
                    entry.final_status = "INCOMPLETE"
                    entry.reconciliation_notes.append(
                        f"Clinically supported, but INCOMPLETE: mandatory companion code/range '{uac_rule.target}' is missing from encounter."
                    )

    # 5. Record EXCLUDES2 & CODE_ALSO (Advisory Audits)
    for entry in entries:
        rules = tabular_rules_by_code.get(entry.code, {})
        for e2 in rules.get("EXCLUDES2", []):
            rt = RuleTarget.from_dict_or_str(e2)
            entry.rules_evaluated["EXCLUDES2"].append({
                "target": rt.target,
                "note": "EXCLUDES2 condition: co-coding permitted if clinically documented."
            })
        for ca in rules.get("CODE_ALSO", []):
            rt = RuleTarget.from_dict_or_str(ca)
            entry.rules_evaluated["CODE_ALSO"].append({
                "target": rt.target,
                "note": "CODE_ALSO recommendation: advisory coding note."
            })

    # 6. Assemble Validated Sequence and Dropped Codes
    principals = [e for e in entries if e.final_status in ("VALID", "INCOMPLETE", "ADD_COMPANION") and e.sequencing_position == "principal"]
    secondaries = [e for e in entries if e.final_status in ("VALID", "INCOMPLETE", "ADD_COMPANION") and e.sequencing_position != "principal"]

    # If no principal was explicitly tagged, promote the first valid code to principal
    if not principals and secondaries:
        principals.append(secondaries.pop(0))
        principals[0].sequencing_position = "principal"

    for e in principals + secondaries:
        validated_sequence.append({
            "code": e.code,
            "type": e.clinical_evaluation.get("type", "claimed"),
            "sequencing_position": e.sequencing_position,
            "status": e.final_status
        })

    for e in entries:
        if e.final_status in ("INVALID", "MANUAL_REVIEW", "SWAP"):
            reason = " | ".join(e.reconciliation_notes) if e.reconciliation_notes else e.clinical_evaluation.get("rationale", "Rejected by validation rules.")
            dropped_codes.append({
                "code": e.code,
                "reason": reason,
                "status": e.final_status
            })

    return {
        "validated_sequence": validated_sequence,
        "dropped_codes": dropped_codes,
        "audit_report": [e.to_dict() for e in entries]
    }
