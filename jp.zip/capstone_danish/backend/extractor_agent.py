import os
import re
import json
import asyncio
from typing import Dict, Optional, List
from pydantic import BaseModel, Field

from agent_framework import Agent
from llm_provider import get_llm_client

class DiagnosisDetails(BaseModel):
    confirmed: bool = Field(description="Whether the diagnosis is confirmed by the clinician (true) or uncertain (false)")
    severity: Optional[str] = Field(default=None, description="Severity qualifier if explicitly stated by clinician, e.g., 'Severe', 'Mild', 'Acute'. Null if not stated.")
    status: str = Field(description="Must be exactly one of: 'Active' | 'History of' | 'Suspected' | 'Ruled out'")
    source_quote: str = Field(description="Verbatim sentence from the medical chart proving this diagnosis exists")
    organism: Optional[str] = Field(default=None, description="Explicitly mentioned causative organism or pathogen mapped to this disease (e.g., 'MRSA', 'Klebsiella')")

class EvidenceDatabase(BaseModel):
    setting: Optional[str] = Field(default=None, description="Patient care setting — exactly one of: 'Inpatient' | 'Outpatient' | 'Emergency'. Null if unknown.")
    diagnoses: Dict[str, DiagnosisDetails] = Field(description="Dictionary keyed by the disease name as written by the clinician")
    organ_dysfunction: List[str] = Field(default_factory=list, description="List of explicitly documented organ failures or dysfunctions. Required for Severe Sepsis validation.")
    medical_history: List[str] = Field(default_factory=list, description="Past medical conditions, family history, or old surgeries NOT actively treated this encounter.")
    lab_values: dict = Field(default_factory=dict, description="Key documented lab values as key-value pairs.")
    medications: List[str] = Field(default_factory=list, description="List of explicitly mentioned medications")
    procedures: List[str] = Field(default_factory=list, description="List of explicitly mentioned procedures performed")


def _clean_and_parse_json(text: str) -> dict:
    t = text.strip()
    if t.startswith("```json"):
        t = t[7:]
    elif t.startswith("```"):
        t = t[3:]
    if t.endswith("```"):
        t = t[:-3]
    t = t.strip()

    try:
        return json.loads(t)
    except json.JSONDecodeError:
        pass

    # Use raw_decode to parse the first complete JSON object and ignore trailing text
    start_idx = t.find('{')
    if start_idx != -1:
        try:
            obj, _ = json.JSONDecoder().raw_decode(t[start_idx:])
            if isinstance(obj, dict):
                return obj
        except Exception:
            pass

    match = re.search(r'(\{.*\})', t, re.DOTALL)
    if match:
        return json.loads(match.group(1))
    raise ValueError(f"Could not parse valid JSON from output: {text[:200]}")


def run_extractor(raw_text: str) -> Optional[EvidenceDatabase]:
    print("Extractor Agent: Extracting clinical evidence from raw text...")
    
    prompt_path = os.path.join(os.path.dirname(__file__), '..', 'prompts', 'extractor_agent_prompt.md')
    with open(prompt_path, 'r', encoding='utf-8') as f:
        system_prompt = f.read()

    client = get_llm_client(temperature=0.0)
    
    agent = Agent(
        name="ExtractorAgent",
        client=client,
        instructions=system_prompt,
        default_options={"temperature": 0.0}
    )

    from async_runner import run_async

    try:
        response = run_async(agent.run(raw_text))
        
        # Extract raw text from response
        raw_output = ""
        if hasattr(response, 'text') and response.text:
            raw_output = response.text
        elif hasattr(response, 'value') and response.value:
            if isinstance(response.value, str):
                raw_output = response.value
            elif isinstance(response.value, dict):
                return EvidenceDatabase.model_validate(response.value)
            elif isinstance(response.value, EvidenceDatabase):
                return response.value
        else:
            raw_output = str(response)

        data = _clean_and_parse_json(raw_output)
        parsed_db = EvidenceDatabase.model_validate(data)

        print("Extractor Agent: Extraction successful!")
        return parsed_db
    except Exception as e:
        print(f"Extractor Agent: Extraction failed. Error: {e}")
        return None
