import os
import json
import re
from datetime import datetime
from difflib import SequenceMatcher
import chromadb
from chromadb.utils import embedding_functions
from dotenv import load_dotenv
import uuid
import asyncio
from agent_framework import Agent
from llm_provider import get_llm_client
import pymongo
from openai import AzureOpenAI

dotenv_path = os.path.join(os.path.dirname(__file__), '..', '.env')
load_dotenv(dotenv_path)

# Initialize Azure Cosmos DB for MongoDB (vCore) if URI exists
COSMOS_MONGO_URI = os.getenv("COSMOS_MONGO_URI")
cosmos_collection = None
azure_openai_client = None

if COSMOS_MONGO_URI:
    try:
        mongo_client = pymongo.MongoClient(COSMOS_MONGO_URI)
        cosmos_db = mongo_client["medical_coding_db"]
        cosmos_collection = cosmos_db["icd10_guidelines"]
        
        # Initialize Azure OpenAI for vector generation
        azure_openai_client = AzureOpenAI(
            api_key=os.getenv("AZURE_OPENAI_API_KEY"),  
            api_version="2023-05-15",
            azure_endpoint=os.getenv("AZURE_OPENAI_ENDPOINT")
        )
        print("Initialized Azure Cosmos DB for MongoDB (vCore) and Azure OpenAI.")
    except Exception as e:
        print(f"Warning: Could not initialize Cosmos DB: {e}")

# Initialize ChromaDB for local fallback RAG
try:
    chroma_client = chromadb.PersistentClient(path=os.path.join(os.path.dirname(__file__), '..', 'rag_chroma_db'))
    sentence_transformer_ef = embedding_functions.SentenceTransformerEmbeddingFunction(model_name="all-MiniLM-L6-v2")
    collection = chroma_client.get_collection(name="icd10_guidelines", embedding_function=sentence_transformer_ef)
except Exception as e:
    print(f"Warning: Could not initialize local ChromaDB: {e}")
    collection = None

def get_tabular_rules(target_code: str, driver) -> dict:
    query = """
    MATCH (leaf:DiseaseCode {code: $code})
    OPTIONAL MATCH (ancestor:DiseaseCode)-[:HAS_CHILD*1..]->(leaf)
    WITH leaf, collect(ancestor) + [leaf] AS family_nodes
    UNWIND family_nodes AS d

    OPTIONAL MATCH (d)-[:HAS_INCLUDE]->(t:ClinicalTerm) WHERE t.category IS NULL
    OPTIONAL MATCH (d)-[:HAS_SEARCH_TERM]->(o:ClinicalTerm) WHERE o.category = 'organism'
    OPTIONAL MATCH (d)-[e1_rel:EXCLUDES1]->(e1)
    OPTIONAL MATCH (d)-[e2_rel:EXCLUDES2]->(e2)
    OPTIONAL MATCH (d)-[cf_rel:CODE_FIRST]->(cf)
    OPTIONAL MATCH (d)-[ca_rel:CODE_ALSO]->(ca)
    OPTIONAL MATCH (d)-[uac_rel:USE_ADDITIONAL_CODE]->(uac)
    RETURN 
        leaf.code AS code,
        leaf.description AS disease_name,
        leaf.billable AS billable,
        collect(DISTINCT t.term) AS synonyms,
        collect(DISTINCT o.term) AS organisms,
        collect(DISTINCT {
            target: coalesce(e1.code, e1.range),
            target_type: labels(e1)[0],
            note: coalesce(e1_rel.note, ''),
            condition: coalesce(e1_rel.condition, ''),
            is_conditional: coalesce(e1_rel.is_conditional, false)
        }) AS EXCLUDES1,
        collect(DISTINCT {
            target: coalesce(e2.code, e2.range),
            target_type: labels(e2)[0],
            note: coalesce(e2_rel.note, ''),
            condition: coalesce(e2_rel.condition, ''),
            is_conditional: coalesce(e2_rel.is_conditional, false)
        }) AS EXCLUDES2,
        collect(DISTINCT {
            target: coalesce(cf.code, cf.range),
            target_type: labels(cf)[0],
            note: coalesce(cf_rel.note, ''),
            condition: coalesce(cf_rel.condition, ''),
            is_conditional: coalesce(cf_rel.is_conditional, false)
        }) AS CODE_FIRST,
        collect(DISTINCT {
            target: coalesce(ca.code, ca.range),
            target_type: labels(ca)[0],
            note: coalesce(ca_rel.note, ''),
            condition: coalesce(ca_rel.condition, ''),
            is_conditional: coalesce(ca_rel.is_conditional, false)
        }) AS CODE_ALSO,
        collect(DISTINCT {
            target: coalesce(uac.code, uac.range),
            target_type: labels(uac)[0],
            note: coalesce(uac_rel.note, ''),
            condition: coalesce(uac_rel.condition, ''),
            is_conditional: coalesce(uac_rel.is_conditional, false)
        }) AS USE_ADDITIONAL_CODE
    """
    try:
        with driver.session() as session:
            result = session.run(query, code=target_code).single()
            if not result:
                return None
            
            clean_result = {
                "code": result["code"],
                "disease_name": result["disease_name"],
                "billable": result["billable"],
                "synonyms": [x for x in result["synonyms"] if x],
                "organisms": [x for x in result["organisms"] if x],
                "EXCLUDES1": [x for x in result["EXCLUDES1"] if x["target"] is not None],
                "EXCLUDES2": [x for x in result["EXCLUDES2"] if x["target"] is not None],
                "CODE_FIRST": [x for x in result["CODE_FIRST"] if x["target"] is not None],
                "CODE_ALSO": [x for x in result["CODE_ALSO"] if x["target"] is not None],
                "USE_ADDITIONAL_CODE": [x for x in result["USE_ADDITIONAL_CODE"] if x["target"] is not None]
            }
            return clean_result
    except Exception as e:
        print(f"Neo4j Error: {e}")
        return None



def get_rag_guidelines(disease_name: str, synonyms: list) -> list[dict]:
    """
    Strict RAG retrieval: Queries the vector DB and returns retrieved guideline chunks.
    Automatically routes to Azure Cosmos DB for MongoDB (vCore) if configured,
    otherwise falls back to the local ChromaDB database.
    """
    search_terms = [disease_name] + synonyms
    search_query = " ".join(search_terms)
    
    # Branch 1: Azure Cosmos DB Vector Search
    if cosmos_collection is not None and azure_openai_client is not None:
        try:
            # 1. Generate the query vector
            response = azure_openai_client.embeddings.create(
                input=search_query,
                model="text-embedding-3-small"
            )
            query_vector = response.data[0].embedding
            
            # 2. Execute MongoDB $vectorSearch pipeline
            pipeline = [
                {
                    "$vectorSearch": {
                        "index": "vectorSearchIndex",
                        "path": "embedding",
                        "queryVector": query_vector,
                        "numCandidates": 100,
                        "limit": 2
                    }
                },
                {
                    "$project": {
                        "_id": 0,
                        "text": 1,
                        "source": 1,
                        "disease_entity": 1,
                        "score": {"$meta": "vectorSearchScore"}
                    }
                }
            ]
            
            cursor = cosmos_collection.aggregate(pipeline)
            retrieved_chunks = []
            for doc in cursor:
                retrieved_chunks.append({
                    "source": doc.get("source", "Unknown Section"),
                    "disease_entity": doc.get("disease_entity", "Unknown Entity"),
                    "text": doc.get("text", "")
                })
            return retrieved_chunks
        except Exception as e:
            print(f"Azure Cosmos DB RAG Error: {e}")
            return []

    # Branch 2: Local ChromaDB Fallback
    if not collection:
        return []
    
    try:
        results = collection.query(
            query_texts=[search_query],
            n_results=2
        )
        retrieved_chunks = []
        if results.get('documents') and len(results['documents'][0]) > 0:
            for i, doc in enumerate(results['documents'][0]):
                meta = results['metadatas'][0][i] if results.get('metadatas') else {}
                retrieved_chunks.append({
                    "source": meta.get("source", "Unknown Section"),
                    "disease_entity": meta.get("disease_entity", "Unknown Entity"),
                    "text": doc
                })
        return retrieved_chunks
    except Exception as e:
        print(f"Local ChromaDB RAG Error: {e}")
        return []

def resolve_code_range(range_str: str, organism: str, driver) -> str:
    if not organism:
        return None
    
    parts = range_str.split("-")
    if len(parts) != 2:
        return None
    range_start, range_end = parts
    
    query = """
    MATCH (d:DiseaseCode)-[:HAS_INCLUDE|HAS_SEARCH_TERM]->(t:ClinicalTerm)
    WHERE d.code >= $range_start AND d.code <= $range_end
    AND d.billable = true
    AND toLower(t.term) CONTAINS toLower($organism)
    RETURN d.code AS code
    LIMIT 1
    """
    try:
        with driver.session() as session:
            result = session.run(query, range_start=range_start, range_end=range_end, organism=organism).single()
            if result:
                return result["code"]
            return None
    except Exception as e:
        print(f"Neo4j Error in CodeRange resolution: {e}")
        return None

def under_coding_neo4j_lookup(diagnosis_name: str, driver, organism: str = None) -> list:
    # 1. Combine diagnosis and organism
    search_string = diagnosis_name.lower()
    if organism:
        search_string += " " + organism.lower()
        
    # 2. Deduplicate words in Python to prevent Cypher double-counting
    words = [w for w in search_string.replace(',', '').replace('.', '').split() if len(w) > 2]
    unique_words = list(set(words))
    
    if not unique_words:
        return []

    # Pilot is restricted to Chapter 1 (A00-B99)
    query = """
    MATCH (d:DiseaseCode)
    WHERE d.billable = true
    AND (d.code STARTS WITH 'A' OR d.code STARTS WITH 'B')
    
    WITH d, $diagnosis_words AS diagnosis_words
    
    // Count matches in DiseaseCode description
    WITH d, diagnosis_words,
         size([w IN diagnosis_words WHERE toLower(d.description) CONTAINS w]) AS desc_matches
         
    // Count matches in ClinicalTerms
    OPTIONAL MATCH (d)-[:HAS_INCLUDE|HAS_SEARCH_TERM]->(t:ClinicalTerm)
    WITH d, diagnosis_words, desc_matches, 
         max(size([w IN diagnosis_words WHERE t IS NOT NULL AND toLower(t.term) CONTAINS w])) AS max_term_matches
         
    WITH d, diagnosis_words, 
         CASE WHEN desc_matches > coalesce(max_term_matches, 0) THEN desc_matches ELSE coalesce(max_term_matches, 0) END AS best_match_count
         
    // Must match at least 2 significant words (or 1 if only 1 word provided)
    WHERE best_match_count >= CASE WHEN size(diagnosis_words) > 1 THEN 2 ELSE 1 END
    
    RETURN d.code AS code, d.description AS description, best_match_count
    ORDER BY best_match_count DESC, size(d.description) ASC
    LIMIT 5
    """
    try:
        with driver.session() as session:
            result = session.run(query, diagnosis_words=unique_words)
            return [{"code": r["code"], "description": r["description"]} for r in result]
    except Exception as e:
        print(f"Neo4j Error in Under-coding lookup: {e}")
        return []


def resolve_code_specificity(target_code: str, evidence_db: dict, driver) -> list:
    """
    Generic Specificity Resolution Service:
    Resolves more specific billable candidate codes within the same ICD-10 category/family
    based on clinical modifiers (organism, site, acuity, severity) present in evidence_db.
    """
    if not target_code or not driver or not isinstance(evidence_db, dict):
        return []

    # 1. Determine category prefix (e.g. 'A41' from 'A41.9', 'B18' from 'B18.2')
    base_category = target_code.split('.')[0] if '.' in target_code else target_code[:3]
    if len(base_category) < 3:
        return []

    # 2. Extract clinical modifiers from evidence_db
    modifier_tokens = set()
    diagnoses = evidence_db.get("diagnoses", {})
    if isinstance(diagnoses, dict):
        for diag_name, diag_info in diagnoses.items():
            if not isinstance(diag_info, dict):
                continue
            # Extract organism
            org = diag_info.get("organism")
            if org:
                for w in re.split(r'[\s,\-/]+', org.lower()):
                    if len(w) >= 3 and w not in ("and", "the", "for", "with", "positive", "confirmed", "type"):
                        modifier_tokens.add(w)
                if "mrsa" in org.lower():
                    modifier_tokens.add("mrsa")
                if "mssa" in org.lower():
                    modifier_tokens.add("mssa")

            # Extract severity / acuity
            sev = diag_info.get("severity")
            if sev and len(sev) >= 4:
                modifier_tokens.add(sev.lower())

            # Extract anatomical site
            site = diag_info.get("anatomical_site") or diag_info.get("site")
            if site and len(site) >= 3:
                for w in re.split(r'[\s,\-/]+', str(site).lower()):
                    if len(w) >= 3:
                        modifier_tokens.add(w)

            # Diagnosis name itself (exclude generic category words)
            for w in re.split(r'[\s,\-/]+', diag_name.lower()):
                if len(w) >= 4 and w not in ("infection", "disease", "syndrome", "confirmed", "patient", "status", "sepsis", "severe", "acute", "chronic", "unspecified", "primary", "secondary"):
                    modifier_tokens.add(w)

    # Also check lab_values or microbiology if present
    labs = evidence_db.get("lab_values", {})
    if isinstance(labs, dict):
        for lab_k, lab_v in labs.items():
            lab_text = f"{lab_k} {lab_v}".lower()
            if "mrsa" in lab_text:
                modifier_tokens.add("mrsa")
            if "mssa" in lab_text:
                modifier_tokens.add("mssa")

    significant_tokens = [t for t in modifier_tokens if len(t) >= 3 and t not in ("infection", "disease", "syndrome", "confirmed", "patient", "status", "sepsis", "severe", "acute", "chronic", "unspecified", "primary", "secondary")]
    if not significant_tokens:
        return []

    # 3. Query Neo4j within the target code's category
    query = """
    MATCH (cand:DiseaseCode)
    WHERE cand.code STARTS WITH $category_prefix
      AND cand.billable = true
      AND cand.code <> $target_code

    WITH cand, $modifiers AS mods

    // Check matches in description
    WITH cand, mods,
         [m IN mods WHERE toLower(cand.description) CONTAINS m] AS desc_matches

    // Check matches in ClinicalTerms (HAS_INCLUDE, HAS_SEARCH_TERM)
    OPTIONAL MATCH (cand)-[:HAS_INCLUDE|HAS_SEARCH_TERM]->(t:ClinicalTerm)
    WITH cand, mods, desc_matches,
         collect(DISTINCT toLower(coalesce(t.term, ''))) AS terms

    WITH cand, mods, desc_matches, terms,
         [m IN mods WHERE any(term IN terms WHERE term CONTAINS m)] AS term_matches

    WITH cand,
         [m IN mods WHERE m IN desc_matches OR m IN term_matches] AS all_matched_mods

    WHERE size(all_matched_mods) > 0

    RETURN cand.code AS code,
           cand.description AS description,
           all_matched_mods AS matched_modifiers,
           size(all_matched_mods) AS score
    ORDER BY score DESC, size(cand.description) ASC
    LIMIT 10
    """
    try:
        with driver.session() as session:
            result = session.run(
                query,
                category_prefix=base_category,
                target_code=target_code,
                modifiers=significant_tokens
            )
            replacements = [
                {
                    "code": r["code"],
                    "description": r["description"],
                    "matched_modifiers": r["matched_modifiers"]
                }
                for r in result
            ]
            return replacements
    except Exception as e:
        print(f"Neo4j Error in resolve_code_specificity: {e}")
        return []


def verify_swap_authority(target_code: str, swap_to: str, tabular_rules: dict, rag_guidelines: list) -> tuple[bool, str]:
    """
    Deterministic ICD-10-CM Swap Verification:
      IF swap_to in verified_replacements (from Neo4j Tabular Graph):
          ACCEPT (Verified by Neo4j Tabular Knowledge Graph)
      ELSE IF swap_to is explicitly cited in retrieved guideline text:
          ACCEPT (Verified by ICD-10-CM Official Coding Guidelines)
      ELSE:
          REJECT
    """
    if not swap_to or swap_to == target_code:
        return False, "Self-swap or empty swap code"

    # Source 1: Neo4j Tabular Knowledge Graph (ICD-10-CM Specificity Resolution)
    raw_candidates = tabular_rules.get("verified_replacements", []) if isinstance(tabular_rules, dict) else []
    verified_codes = [r["code"] if isinstance(r, dict) else r for r in raw_candidates]
    if swap_to in verified_codes:
        return True, "Verified by Neo4j Tabular Knowledge Graph (ICD-10-CM Category Specificity)"

    # Source 2: ICD-10-CM Official Coding Guidelines (RAG text)
    if isinstance(rag_guidelines, list):
        pattern = re.compile(rf'\b{re.escape(swap_to)}\b', re.IGNORECASE)
        for g in rag_guidelines:
            g_text = g.get("text", "") if isinstance(g, dict) else str(g)
            if pattern.search(g_text):
                source_sec = g.get("source", "Official Guideline") if isinstance(g, dict) else "Official Guideline"
                return True, f"Verified by ICD-10-CM Official Guidelines ({source_sec})"

    return False, f"Code {swap_to} is neither in Neo4j verified replacements ({verified_codes}) nor explicitly cited in ICD-10-CM guidelines"



# Re-export guardrail functions from guardrails.py for 100% backward compatibility
from guardrails import (
    log_telemetry,
    verify_numeric_grounding,
    verify_clinical_grounding,
    verify_guideline_grounding,
    verify_evidence_relevance,
)



