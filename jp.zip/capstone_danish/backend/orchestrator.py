import os
import json
from typing import TypedDict, Any, Optional, Dict, Callable
from dotenv import load_dotenv
from neo4j import GraphDatabase
from opentelemetry import trace

from extractor_agent import run_extractor
from validator_agent import run_validator
from rule_engine import reconcile_claim_rules, find_organism_for_code
import data_agent

dotenv_path = os.path.join(os.path.dirname(__file__), '..', '.env')
load_dotenv(dotenv_path)

tracer = trace.get_tracer(__name__)


class ClaimValidationState(TypedDict):
    raw_claimed_codes: list[str]
    evidence_db: dict
    code_queue: list[dict]
    processed_codes: list[str]
    iteration_count: int
    validated_sequence: list[dict]
    dropped_codes: list[dict]
    suggested_additions: list[dict]
    audit_report: list[dict]
    tabular_rules_by_code: dict[str, dict]
    documented_evidence_codes: list[str]

    current_node: str
    current_target_code: str | None
    current_target_type: str | None
    current_tabular_rules: dict | None
    current_rag_guidelines: str | None
    current_verdict: Any | None
    current_retries: int


def initialize_state(
    clinical_text: str,
    code_queue_input: list[str],
    precomputed_evidence_db: Optional[dict] = None
) -> ClaimValidationState:
    return {
        "raw_claimed_codes": list(code_queue_input),
        "evidence_db": dict(precomputed_evidence_db) if precomputed_evidence_db else {},
        "code_queue": [{"code": c, "type": "claimed"} for c in code_queue_input],
        "processed_codes": [],
        "iteration_count": 0,
        "validated_sequence": [],
        "dropped_codes": [],
        "suggested_additions": [],
        "audit_report": [],
        "tabular_rules_by_code": {},
        "documented_evidence_codes": [],
        "current_node": "INITIALIZE",
        "current_target_code": None,
        "current_target_type": None,
        "current_tabular_rules": None,
        "current_rag_guidelines": None,
        "current_verdict": None,
        "current_retries": 0
    }


def node_initialize(state: ClaimValidationState, clinical_text: str) -> ClaimValidationState:
    print("\n[Node 0] INITIALIZE")
    # If evidence_db was already extracted (e.g. by API runner), skip double extraction
    if state.get("evidence_db") and len(state["evidence_db"]) > 0:
        print("  Using precomputed evidence database (Skipping duplicate extraction).")
        state["current_node"] = "UNDER_CODING_CHECK"
        return state

    evidence_db = run_extractor(clinical_text)
    if not evidence_db:
        print("Fatal Error: Layer 1 Extraction Failed.")
        state["current_node"] = "TERMINAL_ERROR"
        return state
    state["evidence_db"] = json.loads(evidence_db.model_dump_json())
    state["current_node"] = "UNDER_CODING_CHECK"
    return state


def node_under_coding_check(state: ClaimValidationState, driver) -> ClaimValidationState:
    print("\n[Node 1] UNDER_CODING_CHECK")
    diagnoses = state["evidence_db"].get("diagnoses", {})
    documented_codes: set[str] = set()

    # Pre-compute 3-character prefixes of already claimed codes.
    # The specificity engine (Node 3 / resolve_code_specificity) handles upgrades
    # WITHIN the same 3-char family (e.g. A41.9 → A41.02).
    # Under-coding should only flag codes from ENTIRELY DIFFERENT families.
    claimed_prefixes = {code[:3] for code in state["raw_claimed_codes"] if len(code) >= 3}

    # Build a set of all codes already in the queue (claimed + any already suggested)
    # to prevent double-queuing.
    already_queued = {item["code"] for item in state["code_queue"]}

    for diag_name, details in diagnoses.items():
        if details.get("confirmed") or details.get("status") == "History of":
            organism = details.get("organism")
            matches = data_agent.under_coding_neo4j_lookup(diag_name, driver, organism)
            for match in matches:
                matched_code = match["code"]
                documented_codes.add(matched_code)
                suggested_prefix = matched_code[:3] if len(matched_code) >= 3 else matched_code

                # Guard 1: If this code's 3-char family is already claimed, the
                # specificity engine will handle the upgrade — do NOT double-queue it.
                if suggested_prefix in claimed_prefixes:
                    print(f"  Skipping '{matched_code}' for '{diag_name}' — family '{suggested_prefix}' already claimed; specificity engine will handle upgrade.")
                    break

                # Guard 2: If the exact code is already in the queue (claimed or previously
                # suggested), skip to avoid double-processing.
                if matched_code in already_queued:
                    print(f"  Skipping '{matched_code}' — already in processing queue.")
                    break

                # This is a genuinely unclaimed code family — flag as under-coding.
                print(f"  Suggested Under-coding: {matched_code} for '{diag_name}'")
                state["code_queue"].append({"code": matched_code, "type": "suggested"})
                state["suggested_additions"].append({
                    "code": matched_code,
                    "reason": f"Under-coding match for {diag_name}"
                })
                already_queued.add(matched_code)  # Track immediately to prevent duplicates from other diagnoses
                break

    state["documented_evidence_codes"] = list(documented_codes)
    print(f"  Documented evidence codes from chart diagnoses: {state['documented_evidence_codes']}")
    state["current_node"] = "QUEUE_ROUTER"
    return state


def node_queue_router(state: ClaimValidationState) -> ClaimValidationState:
    print("\n[Node 2] QUEUE_ROUTER")
    if state["iteration_count"] >= 20:
        print("  Hard loop limit reached. Emergency Stop.")
        state["current_node"] = "COMPILE_OUTPUT"
        return state
    if not state["code_queue"]:
        print("  Queue empty. Validation complete.")
        state["current_node"] = "COMPILE_OUTPUT"
        return state

    state["current_node"] = "NEO4J_QUERY"
    return state


def node_neo4j_query(state: ClaimValidationState, driver) -> ClaimValidationState:
    print("\n[Node 3] NEO4J_QUERY")
    current_item = state["code_queue"].pop(0)
    target_code = current_item["code"]
    target_type = current_item["type"]

    state["current_target_code"] = target_code
    state["current_target_type"] = target_type

    if target_code in state["processed_codes"]:
        print(f"  Code {target_code} already processed. Skipping.")
        state["current_node"] = "QUEUE_ROUTER"
        return state

    state["processed_codes"].append(target_code)
    state["iteration_count"] += 1

    if not (target_code.startswith('A') or target_code.startswith('B')):
        print(f"  Code {target_code} is outside Chapter 1 pilot scope.")
        state["dropped_codes"].append({
            "code": target_code,
            "reason": "Manual Review Required: Outside the current Chapter 1 pilot scope (Chapter not yet ingested into the Neo4j knowledge graph)."
        })
        state["current_node"] = "QUEUE_ROUTER"
        return state

    tabular_rules = data_agent.get_tabular_rules(target_code, driver)

    if not tabular_rules:
        print(f"  Code {target_code} not found in Neo4j.")
        state["dropped_codes"].append({"code": target_code, "reason": "Code not found in knowledge graph"})
        state["current_node"] = "QUEUE_ROUTER"
        return state
    if not tabular_rules["billable"]:
        print(f"  Code {target_code} is not billable.")
        state["dropped_codes"].append({"code": target_code, "reason": "Non-billable parent code"})
        state["current_node"] = "QUEUE_ROUTER"
        return state

    # Query generic specificity resolution service for verified candidate replacements
    verified_replacements = data_agent.resolve_code_specificity(target_code, state["evidence_db"], driver)
    tabular_rules["verified_replacements"] = verified_replacements
    if verified_replacements:
        print(f"  Specificity Service: Found verified replacement candidates: {[r['code'] for r in verified_replacements]}")

    state["current_tabular_rules"] = tabular_rules
    state["tabular_rules_by_code"][target_code] = tabular_rules
    state["current_node"] = "PAYLOAD_ASSEMBLER"
    return state


def node_payload_assembler(state: ClaimValidationState) -> ClaimValidationState:
    target_code = state["current_target_code"]
    print(f"\n[Node 4] PAYLOAD_ASSEMBLER for {target_code}")
    tabular_rules = state["current_tabular_rules"]
    disease_name = tabular_rules["disease_name"]
    synonyms = tabular_rules["synonyms"]

    rag_guidelines = data_agent.get_rag_guidelines(disease_name, synonyms)
    state["current_rag_guidelines"] = rag_guidelines
    state["current_retries"] = 0
    state["current_node"] = "VALIDATION_AGENT_CALL"
    return state


def node_validation_agent_call(state: ClaimValidationState) -> ClaimValidationState:
    target_code = state["current_target_code"]
    print(f"\n[Node 5] VALIDATION_AGENT_CALL for {target_code}")

    max_retries = 1
    corrective_feedback = None
    success = False
    verdict = None
    full_evidence_corpus = json.dumps(state["evidence_db"])

    while state["current_retries"] <= max_retries and not success:
        verdict = run_validator(
            evidence_db=json.dumps(state["evidence_db"], indent=2),
            target_code=target_code,
            all_claimed_codes=state["raw_claimed_codes"],
            neo4j_rules=json.dumps(state["current_tabular_rules"], indent=2),
            rag_guidelines=state["current_rag_guidelines"],
            corrective_feedback=corrective_feedback
        )

        if not verdict:
            corrective_feedback = "Validation crashed. Ensure your output is valid JSON matching the schema."
            state["current_retries"] += 1
            continue

        # GUARD 1 + 2: Numeric + Clinical grounding (deterministic)
        clin_ok, clin_err = data_agent.verify_clinical_grounding(verdict.chart_evidence, full_evidence_corpus)
        if not clin_ok:
            data_agent.log_telemetry(target_code, "Clinical", clin_err)
            corrective_feedback = f"Grounding Error: {clin_err}"
            print(f"[GUARD TRIGGERED] {target_code}: {clin_err}")
            state["current_retries"] += 1
            continue

        # GUARD 3: Build evidence slice (deterministic) + GUARD 3b: Alignment check (LLM closed-context)
        from guardrails import build_evidence_slice, verify_evidence_alignment
        evidence_slice = build_evidence_slice(
            target_code=target_code,
            tabular_rules=state["current_tabular_rules"],
            evidence_db=state["evidence_db"],
            validator_decision=verdict.decision,
            swap_to=getattr(verdict, "swap_to", None),
            validator_chart_evidence=verdict.chart_evidence,
        )
        align_ok, align_err = verify_evidence_alignment(evidence_slice, target_code)
        if not align_ok:
            data_agent.log_telemetry(target_code, "Alignment", align_err)
            if align_err.startswith("AMBIGUOUS:"):
                # AMBIGUOUS is terminal — skip remaining retries, route to Manual Review
                justification = align_err[len("AMBIGUOUS:"):]
                print(f"[GUARD TRIGGERED — AMBIGUOUS] {target_code}: {justification}")
                state["dropped_codes"].append({
                    "code": target_code,
                    "reason": f"Manual Review Required: Evidence alignment ambiguous — {justification}",
                })
                state["current_node"] = "QUEUE_ROUTER"
                return state
            corrective_feedback = align_err
            print(f"[GUARD TRIGGERED] {target_code}: {align_err[:120]}…")
            state["current_retries"] += 1
            continue

        # GUARD 4: Guideline grounding (deterministic)
        guide_ok, guide_err = data_agent.verify_guideline_grounding(verdict.coding_rule, state["current_rag_guidelines"])
        if not guide_ok:
            data_agent.log_telemetry(target_code, "Guideline", guide_err)
            corrective_feedback = guide_err
            print(f"[GUARD TRIGGERED] {target_code}: {guide_err}")
            state["current_retries"] += 1
            continue

        success = True

    if not success:
        print(f"[Node 5] Code {target_code} exhausted retries. Routing to Manual Review.")
        state["dropped_codes"].append({
            "code": target_code,
            "reason": "Failed fabrication guards (Manual Review required)"
        })
        state["current_node"] = "QUEUE_ROUTER"
        return state

    state["current_verdict"] = verdict
    state["current_node"] = "DECISION_ROUTER"
    return state


def node_decision_router(state: ClaimValidationState, driver) -> ClaimValidationState:
    target_code = state["current_target_code"]
    target_type = state["current_target_type"]
    verdict = state["current_verdict"]
    tabular_rules = state["current_tabular_rules"]

    print(f"\n[Node 6] DECISION_ROUTER for {target_code}: {verdict.decision}")

    if verdict.decision == "SWAP":
        if verdict.swap_to is not None and verdict.swap_to == target_code:
            print(f"  [GUARD TRIGGERED] Validator emitted self-swap for {target_code}. Forcing decision to VALID.")
            verdict.decision = "VALID"
            verdict.swap_to = None
        else:
            is_verified, reason = data_agent.verify_swap_authority(
                target_code=target_code,
                swap_to=verdict.swap_to,
                tabular_rules=tabular_rules,
                rag_guidelines=state.get("current_rag_guidelines", [])
            )
            if is_verified:
                print(f"  [SWAP ACCEPTED] {target_code} -> {verdict.swap_to}: {reason}")
            else:
                print(f"  [GUARD TRIGGERED] Validator emitted unverified SWAP from {target_code} to {verdict.swap_to} ({reason}). Reverting to VALID.")
                verdict.decision = "VALID"
                verdict.swap_to = None

    # Preserve untouched raw clinical evaluation in audit report
    raw_eval = json.loads(verdict.model_dump_json())
    raw_eval["type"] = target_type
    state["audit_report"].append(raw_eval)

    if verdict.decision == "SWAP":
        if verdict.swap_to and verdict.swap_to not in state["processed_codes"]:
            if not any(item['code'] == verdict.swap_to for item in state["code_queue"]):
                state["code_queue"].append({"code": verdict.swap_to, "type": "swap"})

    elif verdict.decision == "ADD_COMPANION":
        for comp_code in verdict.companion_codes_required:
            if "-" in comp_code:
                disease_name = tabular_rules.get("disease_name", "") if tabular_rules else ""
                organism = find_organism_for_code(state["evidence_db"], target_code, disease_name)
                resolved_code = data_agent.resolve_code_range(comp_code, organism, driver)
                if resolved_code:
                    if resolved_code not in state["processed_codes"] and not any(item['code'] == resolved_code for item in state["code_queue"]):
                        state["code_queue"].append({"code": resolved_code, "type": "companion"})
                else:
                    verdict.warnings.append(f"Failed to resolve CodeRange {comp_code} based on organism '{organism}'")
            else:
                if comp_code not in state["processed_codes"] and not any(item['code'] == comp_code for item in state["code_queue"]):
                    state["code_queue"].append({"code": comp_code, "type": "companion"})

    state["current_node"] = "QUEUE_ROUTER"
    return state


def node_compile_output(state: ClaimValidationState) -> ClaimValidationState:
    print("\n[Node 7] COMPILE_OUTPUT - Executing Deterministic Reconciliation Engine")

    reconciliation = reconcile_claim_rules(
        clinical_verdicts=state["audit_report"],
        tabular_rules_by_code=state["tabular_rules_by_code"],
        evidence_db=state["evidence_db"],
        documented_evidence_codes=state.get("documented_evidence_codes", []),
    )

    state["validated_sequence"] = reconciliation["validated_sequence"]
    state["dropped_codes"].extend(reconciliation["dropped_codes"])
    state["audit_report"] = reconciliation["audit_report"]

    valid_codes = {v["code"] for v in state["validated_sequence"]}
    state["suggested_additions"] = [
        s for s in state["suggested_additions"]
        if s["code"] in valid_codes
    ]

    state["current_node"] = "DONE"
    return state


def run_claim_validation(
    clinical_text: str,
    code_queue_input: list[str],
    precomputed_evidence_db: Optional[dict] = None,
    callbacks: Optional[Dict[str, Callable]] = None
) -> ClaimValidationState:
    state = initialize_state(clinical_text, code_queue_input, precomputed_evidence_db)
    neo4j_uri = os.getenv('NEO4J_URI')
    neo4j_auth = (os.getenv('NEO4J_USERNAME'), os.getenv('NEO4J_PASSWORD'))

    with tracer.start_as_current_span("orchestrator_graph_execution"):
        with GraphDatabase.driver(
            neo4j_uri,
            auth=neo4j_auth,
            max_connection_lifetime=60,
            keep_alive=True
        ) as neo4j_driver:
            while state["current_node"] not in ("DONE", "TERMINAL_ERROR"):
                node = state["current_node"]
                with tracer.start_as_current_span(node):
                    if node == "INITIALIZE":
                        state = node_initialize(state, clinical_text)
                    elif node == "UNDER_CODING_CHECK":
                        state = node_under_coding_check(state, neo4j_driver)
                    elif node == "QUEUE_ROUTER":
                        state = node_queue_router(state)
                    elif node == "NEO4J_QUERY":
                        state = node_neo4j_query(state, neo4j_driver)
                    elif node == "PAYLOAD_ASSEMBLER":
                        state = node_payload_assembler(state)
                    elif node == "VALIDATION_AGENT_CALL":
                        state = node_validation_agent_call(state)
                    elif node == "DECISION_ROUTER":
                        state = node_decision_router(state, neo4j_driver)
                    elif node == "COMPILE_OUTPUT":
                        state = node_compile_output(state)
                    else:
                        raise ValueError(f"Unknown graph node: {node}")

                # Fire thread-safe callback if registered
                if callbacks and "on_node_complete" in callbacks:
                    try:
                        callbacks["on_node_complete"](node, state)
                    except Exception as cb_err:
                        print(f"Callback error in node {node}: {cb_err}")

    return state
