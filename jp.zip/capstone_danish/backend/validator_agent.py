import os
import re
import json
import asyncio
from typing import List, Optional
from pydantic import BaseModel, Field

from agent_framework import Agent
from llm_provider import get_llm_client

class ValidatedCode(BaseModel):
    code: str = Field(description="The ICD-10-CM code (e.g. A41.9)")
    decision: str = Field(description="One of: VALID | INVALID | SWAP | ADD_COMPANION")
    rationale: str = Field(description="Plain language reason citing the specific rule applied and the evidence from the Evidence DB")
    chart_evidence: str = Field(description="Exact verbatim quote from the Evidence DB that supports or refutes this code.")
    coding_rule: str = Field(description="The specific Neo4j Tabular Rule or RAG Guideline applied")
    swap_to: Optional[str] = Field(default=None, description="Replacement code string if decision is SWAP, else null")
    companion_codes_required: List[str] = Field(default_factory=list, description="List of required companion codes if ADD_COMPANION")
    sequencing_position: Optional[str] = Field(default=None, description="One of: principal | secondary | null")
    warnings: List[str] = Field(default_factory=list, description="Non-blocking advisory notes")


def _clean_and_parse_json(text: str) -> dict:
    t = text.strip()
    if t.startswith("```json"):
        t = t[7:]
    elif t.startswith("```"):
        t = t[3:]
    if t.endswith("```"):
        t = t[:-3]
    t = t.strip()

    try:
        return json.loads(t)
    except json.JSONDecodeError:
        pass

    # Use raw_decode to parse the first complete JSON object and ignore trailing text
    start_idx = t.find('{')
    if start_idx != -1:
        try:
            obj, _ = json.JSONDecoder().raw_decode(t[start_idx:])
            if isinstance(obj, dict):
                return obj
        except Exception:
            pass

    match = re.search(r'(\{.*\})', t, re.DOTALL)
    if match:
        return json.loads(match.group(1))
    raise ValueError(f"Could not parse valid JSON from output: {text[:200]}")


def run_validator(evidence_db: str, target_code: str, all_claimed_codes: list[str], neo4j_rules: str, rag_guidelines: any, corrective_feedback: str = None) -> Optional[ValidatedCode]:
    print(f"\n--- VALIDATING CODE: {target_code} ---")
    
    prompt_path = os.path.join(os.path.dirname(__file__), '..', 'prompts', 'validator_agent_prompt.md')
    with open(prompt_path, 'r', encoding='utf-8') as f:
        system_prompt = f.read()

    if corrective_feedback:
        system_prompt += f"\n\n[SYSTEM ERROR - RETRY REQUIRED]:\n{corrective_feedback}\nDo not repeat this error."

    if isinstance(rag_guidelines, list):
        if len(rag_guidelines) > 0:
            formatted_rag = "\n\n".join([
                f"--- SOURCE: {chunk.get('source', 'Unknown Section')} ({chunk.get('disease_entity', 'Unknown')}) ---\n{chunk.get('text', '')}"
                for chunk in rag_guidelines
            ])
        else:
            formatted_rag = "[]"
    elif not rag_guidelines:
        formatted_rag = "[]"
    else:
        formatted_rag = str(rag_guidelines)

    user_message = f"""--- CONTEXT PAYLOAD ---

EVIDENCE DB:
{evidence_db}

TARGET CODE TO VALIDATE:
{target_code}

ALL CLAIMED CODES IN THIS ENCOUNTER:
{all_claimed_codes}

NEO4J TABULAR RULES:
{neo4j_rules}

RAG GUIDELINES (Code-Specific):
{formatted_rag}
"""

    client = get_llm_client(temperature=0.0)
    
    agent = Agent(
        name="ValidatorAgent",
        client=client,
        instructions=system_prompt,
        default_options={"temperature": 0.0}
    )

    from async_runner import run_async

    try:
        response = run_async(agent.run(user_message))
        
        raw_output = ""
        if hasattr(response, 'text') and response.text:
            raw_output = response.text
        elif hasattr(response, 'value') and response.value:
            if isinstance(response.value, str):
                raw_output = response.value
            elif isinstance(response.value, dict):
                return ValidatedCode.model_validate(response.value)
            elif isinstance(response.value, ValidatedCode):
                return response.value
        else:
            raw_output = str(response)

        data = _clean_and_parse_json(raw_output)
        parsed_code = ValidatedCode.model_validate(data)
        return parsed_code
    except Exception as e:
        print(f"Validator Agent: Validation failed for {target_code}. Error: {e}")
        return None
