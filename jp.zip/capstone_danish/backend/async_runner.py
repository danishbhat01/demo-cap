import asyncio
import threading
from typing import Coroutine, Any

class _BackgroundLoopRunner:
    def __init__(self):
        self._loop: asyncio.AbstractEventLoop | None = None
        self._thread: threading.Thread | None = None
        self._lock = threading.Lock()

    def _ensure_running(self):
        with self._lock:
            if self._loop is None or not self._loop.is_running():
                self._loop = asyncio.new_event_loop()
                self._thread = threading.Thread(target=self._run_loop, daemon=True, name="AsyncRunnerThread")
                self._thread.start()

    def _run_loop(self):
        asyncio.set_event_loop(self._loop)
        self._loop.run_forever()

    def run_coroutine(self, coro: Coroutine) -> Any:
        self._ensure_running()
        future = asyncio.run_coroutine_threadsafe(coro, self._loop)
        return future.result()

_runner = _BackgroundLoopRunner()

def run_async(coro: Coroutine) -> Any:
    """Run an async coroutine synchronously on a persistent background event loop."""
    return _runner.run_coroutine(coro)
