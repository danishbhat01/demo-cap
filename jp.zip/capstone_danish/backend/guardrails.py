import os
import json
import re
from datetime import datetime
from difflib import SequenceMatcher
from dotenv import load_dotenv

from agent_framework import Agent
from llm_provider import get_llm_client
from async_runner import run_async

dotenv_path = os.path.join(os.path.dirname(__file__), '..', '.env')
load_dotenv(dotenv_path)

def log_telemetry(target_code: str, guard_type: str, message: str):
    log_entry = {
        "timestamp": datetime.now().isoformat() + "Z",
        "target_code": target_code,
        "guard_type": guard_type,
        "hallucinated_text": message
    }
    try:
        insights_dir = os.path.join(os.path.dirname(os.path.dirname(__file__)), "insights")
        os.makedirs(insights_dir, exist_ok=True)
        log_file = os.path.join(insights_dir, "telemetry_logs.jsonl")
        with open(log_file, "a", encoding="utf-8") as f:
            f.write(json.dumps(log_entry) + "\n")
    except Exception as e:
        print(f"Warning: Could not write telemetry log: {e}")

def verify_numeric_grounding(evidence_used: str, full_evidence_corpus: str) -> tuple[bool, str]:
    numbers_in_evidence = re.findall(r'[-+]?\d*\.\d+|\d+', evidence_used)
    for num in numbers_in_evidence:
        if num not in full_evidence_corpus:
            return False, f"Fabrication detected: The number '{num}' was cited in evidence but does not exist in the source medical chart."
    return True, ""

def verify_clinical_grounding(evidence_used: str, full_evidence_corpus: str) -> tuple[bool, str]:
    if not evidence_used or evidence_used.strip().upper() in ("NO_SUPPORTING_EVIDENCE_FOUND", "NONE", "N/A", "NO EVIDENCE FOUND"):
        return True, ""

    num_ok, num_err = verify_numeric_grounding(evidence_used, full_evidence_corpus)
    if not num_ok:
        return False, num_err

    # 1. Direct substring match
    if evidence_used.lower() in full_evidence_corpus.lower():
        return True, ""

    # 2. Sentence / clause-level matching
    sentences = [s.strip() for s in re.split(r'[\.\;\n]+', evidence_used) if len(s.strip()) > 4]
    if sentences:
        all_ok = True
        for sentence in sentences:
            if sentence.lower() in full_evidence_corpus.lower():
                continue
            ratio = SequenceMatcher(None, sentence.lower(), full_evidence_corpus.lower()).find_longest_match(0, len(sentence), 0, len(full_evidence_corpus)).size / len(sentence)
            if ratio < 0.70:
                words = set(re.findall(r'\w+', sentence.lower()))
                corpus_words = set(re.findall(r'\w+', full_evidence_corpus.lower()))
                if len(words) > 0 and len(words.intersection(corpus_words)) / len(words) >= 0.80:
                    continue
                all_ok = False
                break
        if all_ok:
            return True, ""

    # 3. Token-overlap set intersection
    ev_words = set(re.findall(r'\w+', evidence_used.lower()))
    corpus_words = set(re.findall(r'\w+', full_evidence_corpus.lower()))
    if len(ev_words) > 0 and len(ev_words.intersection(corpus_words)) / len(ev_words) >= 0.80:
        return True, ""

    return False, f"Fabrication detected: The evidence '{evidence_used}' was not found in the medical chart."

def verify_guideline_grounding(guideline_used: str, retrieved_guidelines: any) -> tuple[bool, str]:
    if not guideline_used or "no specific retrieved guideline" in guideline_used.lower():
        return True, ""
    
    rag_str = ""
    if isinstance(retrieved_guidelines, list):
        rag_str = " ".join([str(item) for item in retrieved_guidelines])
    elif retrieved_guidelines:
        rag_str = str(retrieved_guidelines)

    sections_cited = re.findall(
        r'(Section\s+I\.[A-Z]\.\d+[a-z0-9\.]*|Section\s+[IVX]+(?:\.[0-9a-zA-Z]+)*|I\.[A-Z]\.\d+[a-z0-9\.]*|Section\s+[IVX]+)',
        guideline_used,
        re.IGNORECASE
    )
    
    prompt_path = os.path.join(os.path.dirname(__file__), '..', 'prompts', 'validator_agent_prompt.md')
    universal_guidelines = ""
    if os.path.exists(prompt_path):
        with open(prompt_path, 'r', encoding='utf-8') as f:
            universal_guidelines = f.read()
    
    for section in sections_cited:
        clean_section = section.strip()
        sec_num = re.sub(r'^Section\s+', '', clean_section, flags=re.IGNORECASE)
        
        # Official Chapter 1 guidelines (Section I.C.1.*) are always recognized as valid
        if re.match(r'^I\.C\.1(\.[a-z0-9]+)*$', sec_num, re.IGNORECASE):
            continue

        found_in_rag = clean_section.lower() in rag_str.lower() or sec_num.lower() in rag_str.lower()
        found_in_univ = clean_section.lower() in universal_guidelines.lower() or sec_num.lower() in universal_guidelines.lower()

        if not found_in_rag and not found_in_univ:
            return False, f"Guideline Fabrication: Cited section {clean_section} was not found in the retrieved RAG context or Universal Guidelines."
    return True, ""

def verify_evidence_relevance(disease_name: str, evidence_used: str, target_code: str) -> tuple[bool, str]:
    """
    DEPRECATED STUB — kept for backward-compat import in data_agent.py.
    All callers in orchestrator.py now use build_evidence_slice() +
    verify_evidence_alignment() directly.
    Always returns (True, "") so it is a safe no-op if accidentally called.
    """
    return True, ""


# ---------------------------------------------------------------------------
# GUARD 3 — Deterministic Evidence Slice Builder
# ---------------------------------------------------------------------------

def build_evidence_slice(
    target_code: str,
    tabular_rules: dict,
    evidence_db: dict,
    validator_decision: str,
    swap_to: str | None,
    validator_chart_evidence: str,
) -> dict:
    """
    Deterministic pre-filter that constructs the narrow evidence slice
    passed to the closed-context alignment judge.

    Returns a slice dict ready for verify_evidence_alignment().
    Returns an empty dict (falsy) when no matching candidates are found —
    the caller should skip alignment entirely in that case.
    """
    import re

    tabular_rules = tabular_rules or {}
    evidence_db = evidence_db or {}

    # --- Concept vocabulary: synonyms + organisms from Neo4j rules ---
    synonyms = [s.lower() for s in (tabular_rules.get("synonyms") or []) if s]
    organisms = [o.lower() for o in (tabular_rules.get("organisms") or []) if o]
    disease_name_lower = (tabular_rules.get("disease_name") or "").lower()

    # Build a unified keyword set for this target code
    concept_words: set[str] = set()
    for term in synonyms + organisms + [disease_name_lower, target_code.lower()]:
        concept_words.update(w for w in re.findall(r'\w+', term) if len(w) > 2)

    # For SWAP: also add swap_to synonyms so both sides can be aligned
    if validator_decision == "SWAP" and swap_to:
        concept_words.add(swap_to.lower())

    candidates: list[dict] = []
    cid = 0

    diagnoses = evidence_db.get("diagnoses") or {}
    for diag_name, details in diagnoses.items():
        if not isinstance(details, dict):
            continue
        name_words = set(re.findall(r'\w+', diag_name.lower()))
        organism = (details.get("organism") or "").lower()
        source_quote = (details.get("source_quote") or "").strip()

        # Concept match: name overlap OR organism match
        overlap = name_words.intersection(concept_words)
        org_match = organism and any(o in organism or organism in o for o in organisms)

        if overlap or org_match:
            entities: dict = {
                "condition": diag_name,
                "status": details.get("status", ""),
                "confirmed": details.get("confirmed", False),
                "negated": not details.get("confirmed", True),
            }
            if details.get("severity"):
                entities["severity"] = details["severity"]
            if organism:
                entities["organism"] = details["organism"]

            if source_quote:
                candidates.append({
                    "id": f"diag-{cid}",
                    "text": source_quote,
                    "entities": entities,
                })
                cid += 1

    # Lab values
    lab_values = evidence_db.get("lab_values") or {}
    for lab_key, lab_val in lab_values.items():
        key_words = set(re.findall(r'\w+', lab_key.lower()))
        if key_words.intersection(concept_words):
            candidates.append({
                "id": f"lab-{cid}",
                "text": f"{lab_key}: {lab_val}",
                "entities": {"lab": lab_key, "value": str(lab_val)},
            })
            cid += 1

    # Procedures
    for proc in (evidence_db.get("procedures") or []):
        proc_words = set(re.findall(r'\w+', proc.lower()))
        if proc_words.intersection(concept_words):
            candidates.append({
                "id": f"proc-{cid}",
                "text": proc,
                "entities": {"procedure": proc},
            })
            cid += 1

    # Cap at 6 candidates
    candidates = candidates[:6]

    if not candidates:
        return {}

    return {
        "target_code": target_code,
        "target_concepts": synonyms or [disease_name_lower],
        "required_attributes": {"organism": organisms} if organisms else {},
        "validator_decision": validator_decision,
        "swap_to": swap_to,
        "validator_chart_evidence": validator_chart_evidence,
        "chart_evidence_candidates": candidates,
    }


# ---------------------------------------------------------------------------
# GUARD 3b — Closed-Context LLM Evidence Alignment Checker
# ---------------------------------------------------------------------------

# Sentinel returned by the function to signal AMBIGUOUS routing
_AMBIGUOUS_SENTINEL = "AMBIGUOUS"

def verify_evidence_alignment(
    evidence_slice: dict,
    target_code: str,
) -> tuple[bool, str]:
    """
    Closed-context LLM judge.

    Returns:
      (True,  "")                        — MATCHED: evidence is grounded
      (False, corrective_feedback_str)   — UNSUPPORTED or CONTRADICTED: retry
      (False, "AMBIGUOUS:<justification>") — AMBIGUOUS: caller must route to
                                             Manual Review without retry
    """
    if not evidence_slice:
        # No candidates found — skip alignment, treat as pass
        return True, ""

    cited_raw = (evidence_slice.get("validator_chart_evidence") or "").strip()
    if not cited_raw or cited_raw.upper() in (
        "NO_SUPPORTING_EVIDENCE_FOUND", "NONE", "N/A", "NO EVIDENCE FOUND"
    ):
        return True, ""

    cited_lower = cited_raw.lower()
    candidates = evidence_slice.get("chart_evidence_candidates") or []

    # --- Fast-Path: Deterministic Substring / Direct Match ---
    for c in candidates:
        cand_text = str(c.get("text", "")).strip().lower()
        if not cand_text:
            continue
        if cited_lower in cand_text or cand_text in cited_lower:
            print(f"  [AlignmentJudge FastPath] {target_code}: MATCHED | ID={c.get('id')} | Exact/Substring match")
            return True, ""

    system_prompt = (
        "You are an evidence provenance checker. "
        "Your ONLY task is to determine whether the validator's cited evidence "
        "faithfully corresponds to text found in the supplied chart evidence candidates. "
        "Do NOT apply clinical knowledge, infer meaning, or synthesise information. "
        "Compare texts only. "
        "Return a JSON object with exactly these keys:\n"
        "  verdict: one of MATCHED | UNSUPPORTED | CONTRADICTED | AMBIGUOUS\n"
        "  matched_ids: list of candidate IDs that support the cited evidence (empty list if none)\n"
        "  justification: one concise sentence\n"
        "Output ONLY valid JSON. No markdown fences."
    )

    user_message = (
        f"EVIDENCE SLICE:\n{json.dumps(evidence_slice, indent=2)}\n\n"
        "Does the validator's cited evidence (validator_chart_evidence) faithfully "
        "correspond to one or more of the chart_evidence_candidates?\n"
        "Return JSON only."
    )

    try:
        client = get_llm_client(temperature=0.0)
        agent = Agent(
            name="AlignmentJudge",
            client=client,
            instructions=system_prompt,
            default_options={"temperature": 0.0},
        )
        response = run_async(agent.run(user_message))
        raw = response.text.strip() if hasattr(response, "text") else str(response.value).strip()

        # Robust JSON extraction via regex
        json_match = re.search(r'\{.*\}', raw, re.DOTALL)
        if json_match:
            result = json.loads(json_match.group(0))
        else:
            result = json.loads(raw)

        verdict = str(result.get("verdict", "")).upper().strip()
        raw_matched = result.get("matched_ids")
        if isinstance(raw_matched, list):
            matched_ids = [str(m) for m in raw_matched if m is not None]
        elif isinstance(raw_matched, (str, int)):
            matched_ids = [str(raw_matched)]
        else:
            matched_ids = []
        justification = str(result.get("justification", "")).strip()

        print(f"  [AlignmentJudge] {target_code}: {verdict} | IDs={matched_ids} | {justification}")

        if verdict == "MATCHED":
            return True, ""

        if verdict == "AMBIGUOUS":
            # Signal caller to skip retry and route to Manual Review
            return False, f"AMBIGUOUS:{justification}"

        if verdict == "CONTRADICTED":
            candidate_texts = {
                str(c.get("id")): str(c.get("text", ""))
                for c in candidates
                if isinstance(c, dict) and "id" in c
            }
            conflicting = "; ".join(
                f'[{mid}] "{candidate_texts.get(mid, mid)}"' for mid in matched_ids
            ) or justification
            return False, (
                f"Alignment Error — CONTRADICTED: The chart candidates conflict with your "
                f"cited evidence. Conflicting source: {conflicting}. "
                f"Revise your chart_evidence to accurately reflect the chart."
            )

        # UNSUPPORTED
        available = "; ".join(
            f'[{c.get("id")}] "{c.get("text", "")}"'
            for c in candidates
            if isinstance(c, dict) and "id" in c
        )
        return False, (
            f"Alignment Error — UNSUPPORTED: Your cited evidence was not found in the "
            f"chart candidates for {target_code}. "
            f"You must cite only from these verified excerpts: {available}"
        )

    except json.JSONDecodeError as e:
        print(f"  [AlignmentJudge] JSON parse error for {target_code}: {e}")
        # Fuzzy fallback check before declaring AMBIGUOUS
        for c in candidates:
            cand_text = str(c.get("text", "")).strip().lower()
            if cand_text and SequenceMatcher(None, cited_lower, cand_text).ratio() > 0.70:
                print(f"  [AlignmentJudge FuzzyFallback] {target_code}: MATCHED | ID={c.get('id')}")
                return True, ""
        return False, f"AMBIGUOUS:AlignmentJudge returned unparseable output — routing to Manual Review."

    except Exception as e:
        print(f"  [AlignmentJudge] Execution error for {target_code}: {e}")
        return False, f"AMBIGUOUS:AlignmentJudge execution failed ({e}) — routing to Manual Review."

# ---------------------------------------------------------------------------
# GUARD 4 — Principal Diagnosis Tie-Breaker
# ---------------------------------------------------------------------------

def resolve_principal_conflict(competing_codes: list[str], admission_evidence: list[str]) -> str:
    """
    LLM-powered tie-breaker to determine the true principal diagnosis when multiple 
    valid codes are nominated for principal_position.
    """
    system_prompt = """
    You are an expert ICD-10-CM Principal Diagnosis Tie-Breaker.
    Multiple valid diagnoses have been nominated for the 'principal' position. 
    According to ICD-10-CM Section II guidelines, the principal diagnosis is defined as:
    "that condition established after study to be chiefly responsible for occasioning the admission of the patient to the hospital for care."

    Read the provided admission reasons from the patient's chart.
    Evaluate the competing ICD-10-CM codes.
    Select exactly ONE code that represents the true principal reason for admission.

    Return your response strictly as a JSON object:
    {
        "selected_principal_code": "<the winning code string>",
        "rationale": "<brief reason based on the admission evidence>"
    }
    """
    
    user_message = (
        f"Competing Codes: {competing_codes}\n"
        f"Admission Evidence from Chart: {admission_evidence}\n\n"
        f"Which code is the principal diagnosis?"
    )

    try:
        # Avoid creating a new event loop manually if we're in one, but standard helper is run_async
        def _run():
            client = get_llm_client(temperature=0.0)
            agent = Agent(
                name="PrincipalTieBreaker",
                client=client,
                instructions=system_prompt,
                default_options={"temperature": 0.0},
            )
            return agent.run(user_message)
            
        import asyncio
        loop = asyncio.get_event_loop()
        if loop.is_running():
            import nest_asyncio
            nest_asyncio.apply()
        
        response = asyncio.run(_run())
        raw = response.text.strip() if hasattr(response, "text") else str(response.value).strip()

        # Robust JSON extraction
        json_match = re.search(r'\{.*\}', raw, re.DOTALL)
        if json_match:
            result = json.loads(json_match.group(0))
        else:
            result = json.loads(raw)

        winning_code = result.get("selected_principal_code")
        print(f"  [Tie-Breaker] Selected {winning_code} over {competing_codes} | Rationale: {result.get('rationale')}")
        
        if winning_code in competing_codes:
            return winning_code
        
        # Fallback if LLM hallucinates a code
        return competing_codes[0]
        
    except Exception as e:
        print(f"  [Tie-Breaker] Error: {e}. Falling back to first code.")
        return competing_codes[0]

