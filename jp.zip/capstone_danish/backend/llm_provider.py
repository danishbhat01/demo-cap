import os
import sys
from dotenv import load_dotenv
from agent_framework.openai import OpenAIChatClient

dotenv_path = os.path.join(os.path.dirname(__file__), '..', '.env')
load_dotenv(dotenv_path)

import socket
import subprocess
import time

def _ensure_proxy_running():
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    try:
        sock.settimeout(0.5)
        result = sock.connect_ex(('127.0.0.1', 8001))
        if result == 0:
            return
    except Exception:
        pass
    finally:
        sock.close()

    proxy_script = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'proxy_server.py'))
    subprocess.Popen([sys.executable, proxy_script], cwd=os.path.dirname(proxy_script))

    for _ in range(20):
        time.sleep(0.3)
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        try:
            sock.settimeout(0.5)
            if sock.connect_ex(('127.0.0.1', 8001)) == 0:
                print("Local MAF Proxy on port 8001 is ready.")
                return
        except Exception:
            pass
        finally:
            sock.close()

def get_llm_client(temperature: float = 0.0) -> OpenAIChatClient:
    """
    Returns an agent_framework compatible ModelClient based on environment variables.
    Fallback order: Azure OpenAI -> Groq -> NVIDIA -> OpenRouter -> HuggingFace.
    """
    
    # 1. Azure OpenAI
    azure_key = os.environ.get("AZURE_OPENAI_KEY")
    azure_endpoint = os.environ.get("AZURE_OPENAI_ENDPOINT")
    azure_deployment = os.environ.get("AZURE_OPENAI_DEPLOYMENT")
    
    if azure_key and azure_endpoint and azure_deployment:
        print("LLM Provider: Azure OpenAI (MAF Client)")
        return OpenAIChatClient(
            model=azure_deployment,
            api_key=azure_key,
            azure_endpoint=azure_endpoint,
            api_version="2024-02-15-preview"
        )

    # 2. Google Gemini (Via Local MAF Proxy)
    gemini_key = os.environ.get("GEMINI_API_KEY")
    if gemini_key:
        _ensure_proxy_running()
        model_name = os.environ.get("GEMINI_MODEL", "gemini-2.0-flash")
        print(f"LLM Provider: Google Gemini ({model_name} via MAF Proxy on port 8001)")
        return OpenAIChatClient(
            model=model_name,
            api_key=gemini_key,
            base_url="http://127.0.0.1:8001/v1"
        )

    # 3. Mistral AI (Via Local MAF Proxy)
    mistral_key = os.environ.get("MISTRAL_API_KEY")
    if mistral_key:
        _ensure_proxy_running()
        model_name = os.environ.get("MISTRAL_MODEL", "mistral-large-latest")
        print(f"LLM Provider: Mistral AI ({model_name} via MAF Proxy on port 8001)")
        return OpenAIChatClient(
            model=model_name,
            api_key=mistral_key,
            base_url="http://127.0.0.1:8001/v1"
        )

    # 3. Novita AI (Via Local MAF Proxy)
    novita_key = os.environ.get("NOVITA_API_KEY")
    if novita_key:
        _ensure_proxy_running()
        model_name = os.environ.get("NOVITA_MODEL", "meta-llama/llama-3.3-70b-instruct")
        print(f"LLM Provider: Novita AI ({model_name} via MAF Proxy on port 8001)")
        return OpenAIChatClient(
            model=model_name,
            api_key=novita_key,
            base_url="http://127.0.0.1:8001/v1"
        )

    # 3. Groq Cloud (Via Local MAF Proxy)
    groq_key = os.environ.get("GROQ_API_KEY")
    if groq_key:
        _ensure_proxy_running()
        model_name = os.environ.get("GROQ_MODEL", "llama-3.3-70b-versatile")
        print(f"LLM Provider: Groq ({model_name} via MAF Proxy on port 8001)")
        return OpenAIChatClient(
            model=model_name,
            api_key=groq_key,
            base_url="http://127.0.0.1:8001/v1"
        )

    # 3. NVIDIA NIM (Via Local Proxy)
    nvidia_key = os.environ.get("NVIDIA_API_KEY")
    if nvidia_key:
        _ensure_proxy_running()
        print("LLM Provider: NVIDIA NIM (via Proxy Server on port 8001)")
        return OpenAIChatClient(
            model="meta/llama-3.1-70b-instruct",
            api_key=nvidia_key,
            base_url="http://127.0.0.1:8001/v1"
        )

    # 4. OpenRouter
    openrouter_key = os.environ.get("OPENROUTER_API_KEY")
    if openrouter_key:
        model_name = os.environ.get("OPENROUTER_MODEL", "google/gemma-4-26b-a4b-it:free")
        print(f"LLM Provider: OpenRouter ({model_name})")
        return OpenAIChatClient(
            model=model_name,
            api_key=openrouter_key,
            base_url="https://openrouter.ai/api/v1"
        )

    # 4. HuggingFace
    hf_key = os.environ.get("HF_API_KEY")
    if hf_key:
        print("LLM Provider: HuggingFace (MAF Client)")
        return OpenAIChatClient(
            model="meta-llama/Meta-Llama-3-8B-Instruct",
            api_key=hf_key,
            base_url="https://api-inference.huggingface.co/models/meta-llama/Meta-Llama-3-8B-Instruct/v1"
        )

    raise RuntimeError("All configured LLM providers failed or no keys were provided in .env")
