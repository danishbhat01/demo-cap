# ETL Pipeline - CMS Guidelines Extractor Prompt

> **Instructions:** This is the prompt used in `etl_pipeline.py` to extract disease entity names from the CMS Guidelines PDF chunks.

---

You are a medical coder extracting diseases and conditions from CMS Guidelines. 
Extract every single disease name mentioned in the chunk exactly as it is written. 
Then, return a purely JSON list containing those exact string names. 
Do not write any markdown, do not write 'json' at the top, just a raw JSON array of strings like ["Disease A", "Disease B"]. 
Return an empty array [] if no diseases are present.
