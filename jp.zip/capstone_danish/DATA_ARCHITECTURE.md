# ICD-10-CM Data Architecture & ETL Pipelines

This document outlines the data engineering lifecycle, Exploratory Data Analysis (EDA) findings, and the Tri-Layer Knowledge Architecture designed to eliminate LLM hallucinations for the Medical Coding Agent.

---

## 1. Exploratory Data Analysis (EDA) Findings

The foundation of accurate medical coding relies on two distinct datasets published annually by CMS. During our EDA phase, we identified fundamentally different structural characteristics for each dataset, necessitating distinct data engineering pipelines.

### A. The Tabular List (XML Data)
The ICD-10-CM Tabular list contains the structural hierarchy and deterministic rules.
* **Format:** Highly nested XML (`icd10cm_tabular_2026.xml`).
* **Structure:** Hierarchy flows down: `Chapter` -> `Section` (Block) -> `Category` (3-character) -> `Subcategory` -> `Code` (up to 7 characters).
* **Key Findings:** The XML contains deterministic rules such as `Excludes1` (mutually exclusive codes), `Excludes2` (not mutually exclusive), `Code First` (sequencing dependencies), and `Use Additional Code`.
* **Data Engineering Choice:** Relational databases (SQL) struggle with recursive parent-child lookups and dynamic relationship types. A **Neo4j Knowledge Graph** naturally captures hierarchical relationships and rules as connected nodes and edges using Cypher queries.

### B. The Official Guidelines (PDF Data)
The Official Guidelines for Coding and Reporting dictate clinical and narrative rules for edge cases.
* **Format:** Unstructured PDF document (`chapter-1.pdf`).
* **Structure:** Narrative guidelines organized by section headers and bullet points (e.g., Section I.C.1.a for HIV).
* **Key Findings:** These narrative rules cannot be represented as simple TRUE/FALSE graph edges. They require semantic understanding (e.g., *"If a patient is admitted for an HIV-related condition, sequence B20 first"*).
* **Data Engineering Choice:** This unstructured data is chunked, enriched with metadata, and embedded into a **Vector Database** (ChromaDB locally / Azure Cosmos DB Vector Search in production) for semantic RAG retrieval.

---

## 2. The Tri-Layer Knowledge Architecture

To ensure the Validator Agent operates with 100% accuracy, we divide the CMS data and prompts into three distinct layers:

### Layer 1: Tabular Knowledge Graph (Neo4j / Neo4j Aura on Azure)
* **What it stores:** Structured code nodes, disease descriptions, billable flags, synonyms, organism hints, and deterministic rule edges (`EXCLUDES1`, `CODE_FIRST`, `USE_ADDITIONAL_CODE`). Tabular rules stay in Neo4j across all environments.
* **Why:** Cypher graph queries return exact code rules in milliseconds, enforcing hard boundaries before LLM reasoning.

### Layer 2: Chapter-Specific Guidelines (ChromaDB / Azure Cosmos DB Vector Search)
* **What it stores:** Narrative guidelines specific to disease chapters (e.g., Section I.C rules for Sepsis, HIV, Neoplasms).
* **Why:** These guidelines are fetched dynamically via RAG based on the disease mentioned in the clinical chart.

### Layer 3: Universal Guidelines, Operational Coding Rules & System Prompt Injection
* **What it stores:** Hardcoded rules embedded directly into the system prompts (`extractor_agent_prompt.md` & `validator_agent_prompt.md`):
  1. **Medicolegal Extraction Rules:** Mandatory verbatim `source_quote` extraction, strict status enums (`Active` | `History of` | `Suspected` | `Ruled out`), and non-inference of diagnoses from lab values or vitals.
  2. **Universal Guidelines:** Universal conventions (Sections I.A & I.B) including Section I.A.19 (provider documentation authority) and Section I.B.2 (highest level of detail).
  3. **Encounter Setting Rules:** Section II & III (Inpatient principal/secondary diagnosis rules like II.H/III.C for uncertain diagnoses and III.B for abnormal findings) and Section IV (Outpatient first-listed rules like IV.H).
  4. **Citation & Verdict Schemas:** Strict JSON output requirements enforcing exact citations (`Section I.C.1.a.2`, `EXCLUDES1 (B20)`, `I.A.19`) for complete auditability.
* **Why:** Hardcoding these rules into the system prompts ensures every verdict follows regulatory guidelines without depending on vector RAG similarity.

---

## 3. ETL Pipeline Implementations

### A. Graph ETL Pipeline (`data/neo4j_data/parse_tabular-3.py`)

1. **XML Walk:** `xml.etree.ElementTree.iterparse` streams through the CMS XML tree chapter by chapter to minimize memory usage.
2. **Target Code Extraction:** Regular expressions (`CODE_REF_RE = r"([A-Z]\d{2}(?:\.[\d\-]{1,4})?)"`) isolate parenthesized code references (e.g., `(B20)` or `(B59)`).
3. **Condition & Qualifier Parsing:**
   * Strips codes from notes to extract human-readable context (e.g., *"Use additional code to identify manifestation, such as Pneumocystosis"*).
   * Checks `CONDITIONAL_KEYWORDS` regex (`if applicable`, `associated`, `such as`, `due to`, `following`, `complicating`, `caused by`) to mark `is_conditional = True/False`.
4. **Graph Hydration:** Hydrates Neo4j relationships with edge parameters (`note`, `condition`, `is_conditional`), enabling 3-state evaluation (`NOT_APPLICABLE`, `SATISFIED`, `UNSATISFIED`) in the Rule Engine.

### B. Under-Coding Detection Workflow (Layer 2 Part 1)
To ensure no billable codes are missed, the system includes a dedicated Under-Coding Graph Lookup:
1. Receives extracted clinical diagnoses from Layer 1.
2. Performs a graph traversal matching the literal diagnosis string against Neo4j code `synonyms` and `disease_name` properties.
3. Automatically queues highly matched unbilled codes for evaluation by the Validator.

### B. Vector ETL Pipeline (`data/guideline_data/vector_db_creator/etl_pipeline.py`)

1. **PDF Text Extraction:** PyMuPDF (`fitz`) extracts raw text page-by-page from the official PDF.
2. **Semantic Regex Chunking:** Uses pattern `r'(?=\n\s*[a-z]\.\s+[A-Z])'` to split text by Level 2 disease entity headers (`a. `, `b. `, `c. `) while keeping all sub-paragraphs contiguous.
3. **LLM Metadata Enrichment:** OpenRouter / Gemma model extracts clean `disease_entity` names (e.g., `'HIV'`, `'Sepsis'`) for metadata.
4. **Vector Indexing:** Local `SentenceTransformerEmbeddingFunction(model_name="all-MiniLM-L6-v2")` embeds chunks into ChromaDB with metadata (`chunk_id`, `disease_entity`, `chapter`, `source`).

---

## 4. Empirical Data Payload Examples (HIV Domain)

### A. Neo4j Knowledge Graph Query Payload (`B20`)
When `data_agent.py` queries Neo4j for code `B20` (Human Immunodeficiency Virus [HIV] disease), the graph returns this structured node payload:

```json
{
  "code": "B20",
  "disease_name": "Human immunodeficiency virus [HIV] disease",
  "billable": true,
  "synonyms": [
    "Acquired immunodeficiency syndrome",
    "AIDS",
    "AIDS-related complex",
    "HIV infection, symptomatic"
  ],
  "organisms": [],
  "EXCLUDES1": [
    {
      "target": "Z21",
      "target_type": "DiseaseCode",
      "note": "Asymptomatic human immunodeficiency virus [HIV] infection status",
      "condition": "Asymptomatic human immunodeficiency virus [HIV] infection status",
      "is_conditional": false
    },
    {
      "target": "B97.35",
      "target_type": "DiseaseCode",
      "note": "Human immunodeficiency virus, type 2 [HIV 2] as the cause of diseases classified elsewhere",
      "condition": "Human immunodeficiency virus, type 2 [HIV 2] as the cause of diseases classified elsewhere",
      "is_conditional": false
    }
  ],
  "EXCLUDES2": [],
  "CODE_FIRST": [],
  "CODE_ALSO": [],
  "USE_ADDITIONAL_CODE": [
    {
      "target": "B59",
      "target_type": "DiseaseCode",
      "note": "Use additional code to identify manifestation, such as Pneumocystosis (B59)",
      "condition": "Use additional code to identify manifestation, such as Pneumocystosis",
      "is_conditional": true
    }
  ]
}
```

### B. Vector DB Chunk Payload (`I.C.1.a`)
The chunk stored in ChromaDB for Section I.C.1.a:

```json
{
  "id": "guideline-IC-chap1-0",
  "metadata": {
    "chunk_id": "guideline-IC-chap1-0",
    "disease_entity": "HIV",
    "chapter": "Chapter 1",
    "source": "Section I.C.1.a"
  },
  "text": "a. Code only confirmed cases\nCode only confirmed cases of HIV infection/illness. This is an exception to the hospital inpatient guideline Section II, H.\n\nb. Selection and sequencing of HIV codes\n(1) Patient admitted for HIV-related condition\nIf a patient is admitted for an HIV-related condition, the principal diagnosis should be B20, Human immunodeficiency virus [HIV] disease followed by additional diagnosis codes for all reported HIV-related conditions.\n\n(2) Patient with HIV disease admitted for unrelated condition\nIf a patient with HIV disease is admitted for an unrelated condition (such as a traumatic injury), the code for the unrelated condition (e.g., the nature of injury code) should be the principal diagnosis. Other diagnoses would be B20 followed by additional diagnosis codes for all reported HIV-related conditions."
}
```

---

## 5. Enterprise Azure Migration Strategy

### Database Infrastructure
* **Tabular Rules (Neo4j):** Stays in **Neo4j** across both local development and Azure production (hosted on Neo4j AuraDB or a dedicated Azure Neo4j VM).
* **Unstructured Guidelines (Cosmos DB):** The local ChromaDB vector index migrates to **Azure Cosmos DB Vector Search** for enterprise vector RAG.

### Runtime Secret Management
* **Azure Key Vault:** The MAF `Data Agent` fetches Neo4j credentials, Cosmos DB connection strings, and Azure OpenAI keys from **Azure Key Vault** at runtime, ensuring zero sensitive credentials are hardcoded in source code.
