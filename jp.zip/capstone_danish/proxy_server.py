import os
import re
import asyncio
import uvicorn
from fastapi import FastAPI, Request, HTTPException
import httpx
from dotenv import load_dotenv

# Load env variables
dotenv_path = os.path.join(os.path.dirname(__file__), '.env')
load_dotenv(dotenv_path)

app = FastAPI()

@app.post("/v1/responses")
async def handle_responses(request: Request):
    body = await request.json()
    
    # Map to Chat Completions
    messages = []
    
    # 1. Instructions -> System message
    instructions = body.get("instructions")
    if instructions:
        messages.append({"role": "system", "content": instructions})
        
    # 2. Input -> Messages
    for item in body.get("input", []):
        if item.get("type") == "message":
            role = item.get("role")
            content_list = item.get("content", [])
            text = ""
            for c in content_list:
                if c.get("type") == "input_text":
                    text += c.get("text", "")
            messages.append({"role": role, "content": text})
            
    # 3. Model & Temperature
    # Default to the llama model if not provided
    model = body.get("model", "meta/llama-3.1-70b-instruct")
    temperature = body.get("temperature", 0.0)
    
    # Build payload
    payload = {
        "model": model,
        "messages": messages,
        "temperature": temperature
    }
    
    # 4. Response Format
    # In responses API, response_format is under "text" -> "format"
    text_options = body.get("text", {})
    if "format" in text_options:
        fmt = text_options["format"]
        if fmt.get("type") == "json_schema":
            payload["response_format"] = {
                "type": "json_schema",
                "json_schema": {
                    "name": fmt.get("name", "Schema"),
                    "schema": fmt.get("schema", {}),
                    "strict": fmt.get("strict", False)
                }
            }
            
    mistral_key = os.environ.get("MISTRAL_API_KEY")
    
    fallback_models = []
    if mistral_key:
        target_url = "https://api.mistral.ai/v1/chat/completions"
        target_model = os.environ.get("MISTRAL_MODEL", "mistral-large-latest")
        payload["model"] = target_model
        headers = {
            "Authorization": f"Bearer {mistral_key}",
            "Content-Type": "application/json"
        }
        provider_name = f"Mistral AI ({target_model})"
        fallback_models = ["mistral-small-latest", "open-mistral-nemo"]
    else:
        raise HTTPException(status_code=500, detail="MISTRAL_API_KEY not configured in .env")
    
    nim_data = None
    fallback_idx = 0

    async with httpx.AsyncClient(timeout=120.0) as client:
        for attempt in range(5):
            print(f"Forwarding to {provider_name} (attempt {attempt+1}) ...")
            try:
                resp = await client.post(
                    target_url,
                    json=payload,
                    headers=headers
                )
            except httpx.RequestError as exc:
                print(f"Network error on attempt {attempt+1}: {exc}")
                await asyncio.sleep(2.0)
                continue

            if resp.status_code == 200:
                nim_data = resp.json()
                print(f"Received success response from {provider_name}")
                break
            elif resp.status_code in (429, 413):
                err_text = resp.text
                print(f"Provider Rate Limited ({resp.status_code}): {err_text}")
                
                # 1. First, attempt to sleep and retry the CURRENT model (up to 3 times)
                if attempt < 3:
                    wait_sec = 3.0
                    match = re.search(r'try again in ([\d\.]+)s', err_text)
                    if match:
                        wait_sec = min(float(match.group(1)) + 1.0, 8.0)
                    print(f"Sleeping for {wait_sec:.1f}s before retry with current model...")
                    await asyncio.sleep(wait_sec)
                    continue
                
                # 2. If we have exhausted 3 retries, THEN attempt to fallback to a weaker model
                if mistral_key and fallback_idx < len(fallback_models):
                    next_model = fallback_models[fallback_idx]
                    fallback_idx += 1
                    provider_prefix = "Mistral AI"
                    print(f"Rate limit encountered. Switching to fallback model {next_model}...")
                    payload["model"] = next_model
                    provider_name = f"{provider_prefix} ({next_model} fallback)"
                    await asyncio.sleep(1.0)
                    continue
            elif resp.status_code in (500, 502, 503, 504) and attempt < 4:
                print(f"Provider Server Error ({resp.status_code}), retrying in 3s...")
                await asyncio.sleep(3.0)
                continue
            else:
                print(f"Provider Error ({resp.status_code}): {resp.text}")
                raise HTTPException(status_code=resp.status_code, detail=resp.text)
        else:
            raise HTTPException(status_code=504, detail=f"Failed after 5 attempts with {provider_name}")
        
    # 6. Extract result and format back to Responses API
    assistant_text = ""
    if "choices" in nim_data and len(nim_data["choices"]) > 0:
        assistant_text = nim_data["choices"][0]["message"].get("content", "")
        
    return {
        "id": nim_data.get("id", "res_dummy"),
        "created_at": nim_data.get("created", 1690000000),
        "model": nim_data.get("model", model),
        "object": "response",
        "parallel_tool_calls": False,
        "tool_choice": "auto",
        "tools": [],
        "output": [
            {
                "type": "message",
                "id": "msg_dummy",
                "status": "completed",
                "role": "assistant",
                "content": [
                    {
                        "type": "output_text",
                        "text": assistant_text
                    }
                ]
            }
        ],
        "usage": nim_data.get("usage", {"total_tokens": 0})
    }

if __name__ == "__main__":
    print("Starting MAF Responses API Proxy for Mistral on port 8001...")
    uvicorn.run(app, host="127.0.0.1", port=8001)
