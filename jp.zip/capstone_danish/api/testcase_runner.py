from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
import os
import re
import ast
import uuid
import threading
from pathlib import Path
import fitz  # PyMuPDF

from .models import Job, JobStatus
from .job_store import job_store
from .pipeline_runner import run_pipeline

router = APIRouter(prefix="/testcases", tags=["testcases"])

TESTS_DIR = Path(__file__).parent.parent / "tests"
SESSIONS_DIR = Path(__file__).parent.parent / "sessions"

class TestCaseOption(BaseModel):
    id: str
    name: str
    description: str
    claimed_codes: list[str]

def _parse_testcase_file(filepath: Path) -> dict | None:
    try:
        content = filepath.read_text(encoding="utf-8")
        tree = ast.parse(content)
        
        claimed_codes = []
        clinical_text = ""
        
        # Simple AST traversal to find assigned variables
        for node in ast.walk(tree):
            if isinstance(node, ast.Assign):
                for target in node.targets:
                    if isinstance(target, ast.Name):
                        if target.id == "claimed_codes" and isinstance(node.value, ast.List):
                            claimed_codes = [elt.value for elt in node.value.elts if hasattr(elt, 'value')]
                        elif target.id == "clinical_text" and hasattr(node.value, 'value'):
                            clinical_text = node.value.value
                            
        if not clinical_text:
            return None
            
        # Extract a brief description from the Chief Complaint or History of Present Illness
        desc = ""
        lines = [line.strip() for line in clinical_text.split("\n") if line.strip()]
        for i, line in enumerate(lines):
            if "CHIEF COMPLAINT" in line.upper() or "HISTORY OF PRESENT ILLNESS" in line.upper():
                desc = lines[i] + (f" {lines[i+1]}" if i + 1 < len(lines) else "")
                break
        if not desc and lines:
            desc = lines[0][:100] + "..."
            
        name = filepath.name.replace("run_", "").replace(".py", "").replace("_", " ").title()
        if "Testcase" in name:
            name = name.replace("Testcase", "Test Case ")
            
        return {
            "id": filepath.name,
            "name": name.strip(),
            "description": desc,
            "claimed_codes": claimed_codes,
            "clinical_text": clinical_text
        }
    except Exception as e:
        print(f"Error parsing test case {filepath}: {e}")
        return None

def _generate_mock_pdf(text: str, output_path: str):
    """Generates a multi-page PDF from text using PyMuPDF (fitz)."""
    doc = fitz.open()
    page = doc.new_page()
    
    fontsize = 11
    line_height = fontsize * 1.2
    margin = 50
    width = page.rect.width - 2 * margin
    max_y = page.rect.height - margin
    y = margin
    
    for paragraph in text.split('\n'):
        words = paragraph.split(' ')
        line = ""
        for word in words:
            test_line = line + " " + word if line else word
            if fitz.get_text_length(test_line, fontname="helv", fontsize=fontsize) > width:
                if y + line_height > max_y:
                    page = doc.new_page()
                    y = margin
                page.insert_text((margin, y), line, fontname="helv", fontsize=fontsize)
                y += line_height
                line = word
            else:
                line = test_line
        if line:
            if y + line_height > max_y:
                page = doc.new_page()
                y = margin
            page.insert_text((margin, y), line, fontname="helv", fontsize=fontsize)
            y += line_height

    doc.save(output_path)
    doc.close()

@router.get("", response_model=list[TestCaseOption])
def list_test_cases():
    test_cases = []
    if not TESTS_DIR.exists():
        return []
        
    for file in sorted(TESTS_DIR.glob("*testcase*.py")):
        data = _parse_testcase_file(file)
        if data:
            test_cases.append(TestCaseOption(**data))
            
    return test_cases

@router.post("/{tc_id}/run")
def run_test_case(tc_id: str):
    filepath = TESTS_DIR / tc_id
    if not filepath.exists():
        raise HTTPException(status_code=404, detail="Test case not found")
        
    data = _parse_testcase_file(filepath)
    if not data:
        raise HTTPException(status_code=500, detail="Failed to parse test case data")
        
    job_id = str(uuid.uuid4())
    session_dir = SESSIONS_DIR / job_id
    session_dir.mkdir(parents=True, exist_ok=True)
    
    claim_path = session_dir / "claim.pdf"
    chart_path = session_dir / "chart.pdf"
    log_path   = session_dir / "pipeline_log.txt"
    
    # Generate mock PDFs for the frontend viewer
    claim_text = "CLAIMED CODES:\n\n" + "\n".join(data["claimed_codes"])
    _generate_mock_pdf(claim_text, str(claim_path))
    _generate_mock_pdf(data["clinical_text"], str(chart_path))
    
    job = Job(
        job_id=job_id,
        session_dir=str(session_dir),
        claim_pdf_path=str(claim_path),
        chart_pdf_path=str(chart_path),
        log_path=str(log_path),
    )
    job_store.create(job)
    
    # We also need to seed the extractor_input.json since we mock the PDF extraction
    import json
    input_json = session_dir / "extractor_input.json"
    with open(input_json, "w", encoding="utf-8") as f:
        json.dump({
            "clinical_text": data["clinical_text"],
            "claimed_codes": data["claimed_codes"]
        }, f)
    
    t = threading.Thread(target=run_pipeline, args=(job,), daemon=True, name=f"pipeline-{job_id}")
    t.start()
    
    return {"job_id": job_id, "status": job.status.value}
