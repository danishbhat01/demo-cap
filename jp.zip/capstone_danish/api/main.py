"""
FastAPI Application — ICD-10 Clinical Auditing Platform API
"""
from __future__ import annotations
import os
import re
import json 
import uuid
import threading
from contextlib import asynccontextmanager
from pathlib import Path

from fastapi import FastAPI, File, UploadFile, HTTPException, BackgroundTasks, Body
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, JSONResponse

from .models import Job, JobStatus
from .job_store import job_store
from .pdf_utils import validate_pdf, PDFValidationError
from .pipeline_runner import run_pipeline
from .testcase_runner import router as testcase_router

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------
SESSIONS_DIR = Path(__file__).parent.parent / "sessions"
SESSIONS_DIR.mkdir(exist_ok=True)

MAX_UPLOAD_BYTES = 50 * 1024 * 1024  # 50 MB per file
ALLOWED_CONTENT_TYPES = {"application/pdf"}


# ---------------------------------------------------------------------------
# App lifecycle
# ---------------------------------------------------------------------------
@asynccontextmanager
async def lifespan(app: FastAPI):
    # start_cleanup_daemon()
    yield


app = FastAPI(
    title="ICD-10 Clinical Auditing Platform",
    version="2.0.0",
    description="AI-powered ICD-10-CM claim validation pipeline.",
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],   # tighten in production
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(testcase_router)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------
def _sanitize_filename(name: str) -> str:
    """Strip dangerous characters from uploaded filenames."""
    name = Path(name).name  # remove any path traversal
    return re.sub(r"[^\w.\-]", "_", name)


def _require_job(job_id: str) -> Job:
    job = job_store.get(job_id)
    if not job:
        raise HTTPException(status_code=404, detail=f"Job '{job_id}' not found.")
    return job


async def _read_and_validate(upload: UploadFile, label: str) -> bytes:
    """Read, size-check, content-type-check, and structurally validate a PDF upload."""
    if upload.content_type not in ALLOWED_CONTENT_TYPES:
        raise HTTPException(
            status_code=400,
            detail=f"{label}: only PDF files are accepted (got '{upload.content_type}').",
        )
    data = await upload.read()
    if len(data) > MAX_UPLOAD_BYTES:
        raise HTTPException(
            status_code=413,
            detail=f"{label}: file exceeds the 50 MB upload limit.",
        )
    try:
        validate_pdf(data, upload.filename or label)
    except PDFValidationError as exc:
        raise HTTPException(status_code=422, detail=str(exc))
    return data


# ---------------------------------------------------------------------------
# Routes
# ---------------------------------------------------------------------------

@app.post("/jobs", status_code=201)
async def create_job(
    claim_pdf: UploadFile = File(..., description="Claim PDF containing billed ICD-10 codes"),
    chart_pdf: UploadFile = File(..., description="Medical chart PDF containing clinical notes"),
):
    """
    Upload a claim PDF and a clinical chart PDF simultaneously.
    Creates an isolated session and starts the validation pipeline.
    """
    # Validate both files (simultaneous upload, sequential validation)
    claim_bytes = await _read_and_validate(claim_pdf, "Claim PDF")
    chart_bytes = await _read_and_validate(chart_pdf, "Chart PDF")

    # Create isolated session directory
    job_id = str(uuid.uuid4())
    session_dir = SESSIONS_DIR / job_id
    session_dir.mkdir(parents=True, exist_ok=True)

    claim_path = session_dir / "claim.pdf"
    chart_path = session_dir / "chart.pdf"
    log_path   = session_dir / "pipeline_log.txt"

    claim_path.write_bytes(claim_bytes)
    chart_path.write_bytes(chart_bytes)

    # Build Job object
    job = Job(
        job_id=job_id,
        session_dir=str(session_dir),
        claim_pdf_path=str(claim_path),
        chart_pdf_path=str(chart_path),
        log_path=str(log_path),
        chart_filename=_sanitize_filename(chart_pdf.filename or "chart.pdf"),
        claim_filename=_sanitize_filename(claim_pdf.filename or "claim.pdf"),
    )
    job_store.create(job)

    # Spawn pipeline in a daemon thread (avoids asyncio deadlocks with sentence-transformers)
    t = threading.Thread(target=run_pipeline, args=(job,), daemon=True, name=f"pipeline-{job_id}")
    t.start()

    return {"job_id": job_id, "status": job.status.value}


@app.get("/jobs")
def list_jobs():
    """List all jobs — used by the SME Manual Review Inbox."""
    jobs = job_store.all()
    return [
        {
            "job_id": j.job_id,
            "status": j.status.value,
            "progress": j.progress_percentage,
            "chart_filename": j.chart_filename,
            "claim_filename": j.claim_filename,
            "created_at": j.created_at.isoformat() if j.created_at else None,
            "completed_at": j.completed_at.isoformat() if j.completed_at else None,
        }
        for j in jobs
    ]


@app.get("/jobs/{job_id}")
def get_job(job_id: str):
    """Full job metadata."""
    job = _require_job(job_id)
    return job.model_dump(mode="json", exclude={"session_dir", "chart_pdf_path", "claim_pdf_path", "report_path", "evidence_path", "log_path"})


@app.get("/jobs/{job_id}/status")
def get_job_status(job_id: str):
    """Rich pipeline status payload for frontend polling."""
    job = _require_job(job_id)
    return job.status_payload()


@app.get("/jobs/{job_id}/report")
def get_job_report(job_id: str):
    """Return the final audit report JSON."""
    job = _require_job(job_id)
    if job.status != JobStatus.COMPLETED:
        raise HTTPException(status_code=409, detail=f"Job is not yet complete (status: {job.status.value}).")
    if not job.report_path or not os.path.isfile(job.report_path):
        raise HTTPException(status_code=404, detail="Audit report not found on disk.")
    return FileResponse(job.report_path, media_type="application/json")


@app.patch("/jobs/{job_id}/report")
def sme_override_report(job_id: str, overrides: dict = Body(...)):
    """
    SME Human Review Override endpoint.
    Accepts a JSON payload with SME decisions and saves them into the
    audit_report.json alongside the original AI decisions.
    This is the single source of truth for the final approved PDF export.
    Works identically in local (sessions/) and Azure (mounted File Share) modes.
    """
    job = _require_job(job_id)
    if job.status != JobStatus.COMPLETED:
        raise HTTPException(status_code=409, detail=f"Job is not complete (status: {job.status.value}).")
    if not job.report_path or not os.path.isfile(job.report_path):
        raise HTTPException(status_code=404, detail="Audit report not found on disk.")

    # Load existing report
    with open(job.report_path, "r", encoding="utf-8") as f:
        report = json.load(f)

    # Merge SME decisions into each audit entry
    # overrides["entries"] is a list of { code, sme_decision, sme_override_code, sme_notes }
    sme_entries = {e["code"]: e for e in overrides.get("entries", [])}
    for entry in report.get("audit_entries", []):
        code = entry.get("code")
        if code in sme_entries:
            sme = sme_entries[code]
            entry["sme_decision"]       = sme.get("sme_decision")        # APPROVE | REJECT | OVERRIDE
            entry["sme_override_code"]  = sme.get("sme_override_code")   # only if OVERRIDE
            entry["sme_notes"]          = sme.get("sme_notes", "")
            entry["sme_reviewed"]       = True
        else:
            entry.setdefault("sme_reviewed", False)

    # Stamp the report with review metadata
    report["sme_approved"]   = True
    report["sme_approved_at"] = overrides.get("approved_at", "")
    report["chart_filename"] = job.chart_filename
    report["claim_filename"] = job.claim_filename

    # Persist back to disk (same path — works locally and on Azure File Share)
    with open(job.report_path, "w", encoding="utf-8") as f:
        json.dump(report, f, indent=2)

    return {"status": "approved", "job_id": job_id, "chart_filename": job.chart_filename}


@app.get("/jobs/{job_id}/pdf/{doc_type}")
def get_job_pdf(job_id: str, doc_type: str):
    """
    Serve claim or chart PDF back to the frontend.
    doc_type must be 'claim' or 'chart'.
    """
    job = _require_job(job_id)
    if doc_type == "claim":
        path = job.claim_pdf_path
    elif doc_type == "chart":
        path = job.chart_pdf_path
    else:
        raise HTTPException(status_code=400, detail="doc_type must be 'claim' or 'chart'.")
    if not path or not os.path.isfile(path):
        raise HTTPException(status_code=404, detail=f"{doc_type} PDF not found.")
    return FileResponse(path, media_type="application/pdf")


@app.get("/jobs/{job_id}/text/{doc_type}")
def get_job_text(job_id: str, doc_type: str):
    """
    Extract and return plain text from a stored PDF for the frontend viewer.
    doc_type must be 'claim' or 'chart'.
    """
    import fitz
    job = _require_job(job_id)
    if doc_type == "claim":
        path = job.claim_pdf_path
    elif doc_type == "chart":
        path = job.chart_pdf_path
    else:
        raise HTTPException(status_code=400, detail="doc_type must be 'claim' or 'chart'.")
    if not path or not os.path.isfile(path):
        input_json = os.path.join(job.session_dir, "extractor_input.json")
        if os.path.isfile(input_json):
            with open(input_json, "r", encoding="utf-8") as f:
                data = json.load(f)
                if doc_type == "chart":
                    return JSONResponse(content={"text": data.get("clinical_text", "")})
                else:
                    return JSONResponse(content={"text": "Claimed Codes:\n" + "\n".join(data.get("claimed_codes", []))})
        raise HTTPException(status_code=404, detail=f"{doc_type} document not found.")
    text = ""
    with fitz.open(path) as doc:
        for page in doc:
            text += page.get_text()
    return JSONResponse(content={"text": text})


@app.get("/jobs/{job_id}/logs")
def get_job_logs(job_id: str):
    """Return the raw pipeline log as plain text."""
    job = _require_job(job_id)
    if not job.log_path or not os.path.isfile(job.log_path):
        raise HTTPException(status_code=404, detail="Log file not found.")
    with open(job.log_path, encoding="utf-8") as f:
        content = f.read()
    return JSONResponse(content={"log": content})


@app.delete("/jobs/{job_id}", status_code=204)
def cancel_job(job_id: str):
    """Cancel a queued job (does not kill a running pipeline thread)."""
    job = _require_job(job_id)
    if job.status == JobStatus.RUNNING:
        raise HTTPException(status_code=409, detail="Cannot cancel a running job.")
    job.status = JobStatus.CANCELLED
    job_store.update(job)
