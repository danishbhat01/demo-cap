"""
Pipeline Runner — wraps the orchestrator, emits progress updates to the Job,
and persists all intermediate artifacts to the session directory.
"""
from __future__ import annotations
import sys
import os
import json
import logging
import traceback
import copy
from datetime import datetime
from pathlib import Path

# ---------------------------------------------------------------------------
# The backend/ orchestration code lives one level up, so we add it to sys.path
# ---------------------------------------------------------------------------
BACKEND_DIR = Path(__file__).parent.parent / "backend"
sys.path.insert(0, str(BACKEND_DIR))

from .models import Job, JobStatus, PipelineStage
from .job_store import job_store
import orchestrator as orch

# Pipeline stages definition — add future agents here; frontend renders dynamically
PIPELINE_STAGES = [
    PipelineStage(name="pdf_parse",       label="PDF Parsing"),
    PipelineStage(name="extraction",      label="Clinical Extraction"),
    PipelineStage(name="under_coding",    label="Under-Coding Detection"),
    PipelineStage(name="kg_retrieval",    label="Knowledge Graph Retrieval"),
    PipelineStage(name="rag_retrieval",   label="Guideline Retrieval (RAG)"),
    PipelineStage(name="validation",      label="ICD Validator"),
    PipelineStage(name="compile",         label="Report Compilation"),
]

STAGE_PROGRESS = {
    "pdf_parse":    5,
    "extraction":   20,
    "under_coding": 35,
    "kg_retrieval": 55,
    "rag_retrieval": 70,
    "validation":   85,
    "compile":      100,
}


def _get_stage(stages: list[PipelineStage], name: str) -> PipelineStage:
    return next(s for s in stages if s.name == name)


def _setup_logger(log_path: str) -> logging.Logger:
    logger = logging.getLogger(log_path)
    logger.setLevel(logging.DEBUG)
    if not logger.handlers:
        fh = logging.FileHandler(log_path, encoding="utf-8")
        fh.setFormatter(logging.Formatter("%(asctime)s [%(levelname)s] %(message)s"))
        logger.addHandler(fh)
    return logger


def _advance(job: Job, stage_name: str, agent_label: str, logger: logging.Logger):
    """Marks a stage as running and updates the Job in the store."""
    stage = _get_stage(job.stages, stage_name)
    stage.status = "running"
    stage.started_at = datetime.utcnow()
    job.current_stage = stage.label
    job.current_agent = agent_label
    job.progress_percentage = STAGE_PROGRESS.get(stage_name, job.progress_percentage)
    job_store.update(job)
    logger.info(f"[STAGE START] {stage_name} — {agent_label}")


def _complete_stage(job: Job, stage_name: str, logger: logging.Logger):
    stage = _get_stage(job.stages, stage_name)
    stage.status = "completed"
    stage.completed_at = datetime.utcnow()
    if stage.started_at:
        stage.elapsed_seconds = round((stage.completed_at - stage.started_at).total_seconds(), 2)
    job_store.update(job)
    logger.info(f"[STAGE DONE]  {stage_name} — {stage.elapsed_seconds}s")


def _save(path: str, data: dict | list, logger: logging.Logger):
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, default=str)
    logger.debug(f"Artifact saved → {path}")


def run_pipeline(job: Job) -> None:
    """
    Main pipeline entry point. Called by FastAPI in a background thread.
    """
    session_dir = job.session_dir
    log_path = job.log_path
    logger = _setup_logger(log_path)

    try:
        # Mark running
        job.status = JobStatus.RUNNING
        job.started_at = datetime.utcnow()
        job.stages = copy.deepcopy(PIPELINE_STAGES)
        job_store.update(job)
        logger.info(f"Pipeline started for job {job.job_id}")

        # ------------------------------------------------------------------ #
        # STAGE 1 — PDF Parse: extract raw text from chart PDF               #
        # ------------------------------------------------------------------ #
        _advance(job, "pdf_parse", "PDF Text Extractor", logger)
        import fitz
        from .ocr_service import extract_text_from_pdf

        chart_text = ""
        with fitz.open(job.chart_pdf_path) as doc:
            for page in doc:
                chart_text += page.get_text()
        
        if len(chart_text.strip()) < 50:
            logger.info("Chart text very short or empty. Invoking OCR service...")
            chart_text = extract_text_from_pdf(job.chart_pdf_path)

        # Extract ICD codes from claim PDF (simple text scan)
        claim_text = ""
        with fitz.open(job.claim_pdf_path) as doc:
            for page in doc:
                claim_text += page.get_text()
        
        if len(claim_text.strip()) < 50:
            logger.info("Claim text very short or empty. Invoking OCR service...")
            claim_text = extract_text_from_pdf(job.claim_pdf_path)

        _save(os.path.join(session_dir, "extractor_input.json"),
              {"chart_text": chart_text, "claim_text": claim_text}, logger)
        _complete_stage(job, "pdf_parse", logger)

        # Parse claimed codes from claim PDF — look for ICD-10 patterns
        import re
        claimed_codes = list(dict.fromkeys(
            re.findall(r'\b[A-TV-Z][0-9]{2}(?:\.[0-9A-Z]{1,4})?\b', claim_text)
        ))
        logger.info(f"Claimed codes extracted: {claimed_codes}")

        # ------------------------------------------------------------------ #
        # STAGE 2 — Clinical Extraction                                       #
        # ------------------------------------------------------------------ #
        _advance(job, "extraction", "Extractor Agent", logger)
        from extractor_agent import run_extractor
        evidence_model = run_extractor(chart_text)
        if not evidence_model:
            raise RuntimeError("Extractor Agent returned empty output.")

        evidence_db = json.loads(evidence_model.model_dump_json())
        _save(os.path.join(session_dir, "evidence_db.json"), evidence_db, logger)
        _complete_stage(job, "extraction", logger)

        # ------------------------------------------------------------------ #
        # STAGE 3–7 — Run the orchestrator with thread-safe callbacks         #
        # ------------------------------------------------------------------ #
        kg_retrieval_log: list[dict] = []
        validator_inputs: list[dict] = []
        validator_outputs: list[dict] = []

        _advance(job, "under_coding", "Under-Coding Detector", logger)

        def on_node_complete(node_name: str, state: dict):
            if node_name == "UNDER_CODING_CHECK":
                _complete_stage(job, "under_coding", logger)
                _advance(job, "kg_retrieval", "Neo4j Graph Query", logger)

            elif node_name == "NEO4J_QUERY":
                target = state.get("current_target_code")
                rules = state.get("current_tabular_rules")
                if rules:
                    kg_retrieval_log.append({"code": target, "rules": rules})

            elif node_name == "PAYLOAD_ASSEMBLER":
                _complete_stage(job, "kg_retrieval", logger)
                _advance(job, "rag_retrieval", "ChromaDB RAG Retrieval", logger)
                _save(os.path.join(session_dir, "kg_retrieval.json"), kg_retrieval_log, logger)
                _complete_stage(job, "rag_retrieval", logger)
                _advance(job, "validation", "ICD Validator Agent", logger)

            elif node_name == "VALIDATION_AGENT_CALL":
                target = state.get("current_target_code")
                validator_inputs.append({
                    "code": target,
                    "evidence_db": state.get("evidence_db"),
                    "tabular_rules": state.get("current_tabular_rules"),
                })
                v = state.get("current_verdict")
                if v:
                    validator_outputs.append({
                        "code": target,
                        "decision": v.decision,
                        "rationale": v.rationale,
                    })

        # Run orchestrator with precomputed evidence_db and thread-safe callbacks
        final_state = orch.run_claim_validation(
            clinical_text=chart_text,
            code_queue_input=claimed_codes,
            precomputed_evidence_db=evidence_db,
            callbacks={"on_node_complete": on_node_complete}
        )

        _save(os.path.join(session_dir, "validator_input.json"),  validator_inputs,  logger)
        _save(os.path.join(session_dir, "validator_output.json"), validator_outputs, logger)

        # ------------------------------------------------------------------ #
        # STAGE 7 — Compile Report                                            #
        # ------------------------------------------------------------------ #
        _advance(job, "compile", "Report Compiler", logger)
        audit_report = {
            "job_id": job.job_id,
            "claimed_codes": claimed_codes,
            "validated_sequence": final_state["validated_sequence"],
            "audit_entries": final_state["audit_report"],
            "dropped_codes": final_state["dropped_codes"],
            "suggested_additions": final_state["suggested_additions"],
            "generated_at": datetime.utcnow().isoformat() + "Z",
        }
        report_path = os.path.join(session_dir, "audit_report.json")
        _save(report_path, audit_report, logger)
        job.report_path = report_path
        _complete_stage(job, "compile", logger)

        # Mark complete
        job.status = JobStatus.COMPLETED
        job.progress_percentage = 100
        job.completed_at = datetime.utcnow()
        job.current_stage = "Complete"
        job.current_agent = None
        job_store.update(job)
        logger.info(f"Pipeline completed successfully for job {job.job_id}")

    except Exception as exc:
        job.status = JobStatus.FAILED
        job.error_message = str(exc)
        job.completed_at = datetime.utcnow()
        job_store.update(job)
        if logger:
            logger.error(f"Pipeline FAILED: {exc}\n{traceback.format_exc()}")
        raise
