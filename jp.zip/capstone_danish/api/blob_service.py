"""
Blob Service — Dual-mode storage abstraction layer.

Priority Order:
  1. Azure Key Vault  → fetch AZURE_STORAGE_CONNECTION_STRING → Azure Blob Storage mode
  2. Local .env file  → AZURE_STORAGE_CONNECTION_STRING set    → Azure Blob Storage mode
  3. Neither set      → Local filesystem mode (sessions/ folder)
"""
from __future__ import annotations
import os
import logging
from pathlib import Path
from dotenv import load_dotenv

dotenv_path = Path(__file__).parent.parent / ".env"
load_dotenv(dotenv_path)

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Step 1: Try to resolve AZURE_STORAGE_CONNECTION_STRING via Key Vault first
# ---------------------------------------------------------------------------
_storage_connection_string: str | None = None
_azure_mode: bool = False

def _resolve_storage_secret() -> str | None:
    """
    Attempts to resolve AZURE_STORAGE_CONNECTION_STRING using:
      1. Azure Key Vault (if AZURE_KEY_VAULT_URL is set)
      2. Local .env / environment variable (fallback)
    """
    keyvault_url = os.environ.get("AZURE_KEY_VAULT_URL")
    
    if keyvault_url:
        try:
            from azure.identity import DefaultAzureCredential
            from azure.keyvault.secrets import SecretClient
            
            credential = DefaultAzureCredential()
            client = SecretClient(vault_url=keyvault_url, credential=credential)
            # Azure Key Vault uses hyphens, not underscores
            secret = client.get_secret("AZURE-STORAGE-CONNECTION-STRING")
            logger.info("Blob Service: Resolved storage secret from Azure Key Vault.")
            return secret.value
        except ImportError:
            logger.warning("Blob Service: azure-identity SDK not installed. Falling back to .env")
        except Exception as e:
            logger.warning(f"Blob Service: Key Vault lookup failed ({e}). Falling back to .env")
    
    # Fallback: read directly from environment / .env
    return os.environ.get("AZURE_STORAGE_CONNECTION_STRING")


def _init():
    """Initialize the blob service and determine which mode to operate in."""
    global _storage_connection_string, _azure_mode
    
    conn_str = _resolve_storage_secret()
    
    if conn_str:
        _storage_connection_string = conn_str
        _azure_mode = True
        logger.info("Blob Service initialized in AZURE mode.")
    else:
        _azure_mode = False
        logger.info("Blob Service initialized in LOCAL FILESYSTEM mode.")

_init()


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def is_azure_mode() -> bool:
    """Returns True if we are operating in Azure Blob Storage mode."""
    return _azure_mode

AZURE_CONTAINER_NAME = os.environ.get("AZURE_BLOB_CONTAINER", "pdf-uploads")

def upload_pdf(file_bytes: bytes, job_id: str, filename: str, local_dir: str) -> str:
    """
    Upload a PDF to the appropriate storage backend.
    
    Returns:
        str: The local file path (local mode) or the Azure Blob name (azure mode).
    """
    if _azure_mode:
        return _upload_to_azure(file_bytes, job_id, filename)
    else:
        return _save_locally(file_bytes, local_dir, filename)


def get_pdf_url(job_id: str, filename: str, local_path: str, expiry_hours: int = 1) -> str:
    """
    Get a URL or path to access the PDF for the frontend.
    
    Returns:
        str: A temporary SAS URL (Azure mode) or a local file path (local mode).
    """
    if _azure_mode:
        return _generate_sas_url(job_id, filename, expiry_hours)
    else:
        return local_path


# ---------------------------------------------------------------------------
# Azure Blob Storage Helpers
# ---------------------------------------------------------------------------

def _upload_to_azure(file_bytes: bytes, job_id: str, filename: str) -> str:
    """Upload file to Azure Blob Storage and return the blob name."""
    try:
        from azure.storage.blob import BlobServiceClient
        
        blob_name = f"jobs/{job_id}/{filename}"
        blob_service_client = BlobServiceClient.from_connection_string(_storage_connection_string)
        blob_client = blob_service_client.get_blob_client(
            container=AZURE_CONTAINER_NAME,
            blob=blob_name
        )
        blob_client.upload_blob(file_bytes, overwrite=True)
        logger.info(f"Uploaded to Azure Blob: {blob_name}")
        return blob_name
    except Exception as e:
        logger.error(f"Azure upload failed: {e}")
        raise


def _generate_sas_url(job_id: str, filename: str, expiry_hours: int) -> str:
    """Generate a temporary SAS URL for a blob."""
    try:
        from datetime import datetime, timezone, timedelta
        from azure.storage.blob import (
            BlobServiceClient,
            generate_blob_sas,
            BlobSasPermissions,
        )
        
        blob_name = f"jobs/{job_id}/{filename}"
        blob_service_client = BlobServiceClient.from_connection_string(_storage_connection_string)
        account_name = blob_service_client.account_name
        account_key = blob_service_client.credential.account_key
        
        sas_token = generate_blob_sas(
            account_name=account_name,
            container_name=AZURE_CONTAINER_NAME,
            blob_name=blob_name,
            account_key=account_key,
            permission=BlobSasPermissions(read=True),
            expiry=datetime.now(timezone.utc) + timedelta(hours=expiry_hours),
        )
        
        sas_url = f"https://{account_name}.blob.core.windows.net/{AZURE_CONTAINER_NAME}/{blob_name}?{sas_token}"
        logger.info(f"Generated SAS URL for blob: {blob_name}")
        return sas_url
    except Exception as e:
        logger.error(f"SAS URL generation failed: {e}")
        raise


# ---------------------------------------------------------------------------
# Local Filesystem Helpers
# ---------------------------------------------------------------------------

def _save_locally(file_bytes: bytes, local_dir: str, filename: str) -> str:
    """Save file to local sessions directory and return the file path."""
    file_path = os.path.join(local_dir, filename)
    with open(file_path, "wb") as f:
        f.write(file_bytes)
    logger.info(f"Saved locally: {file_path}")
    return file_path
