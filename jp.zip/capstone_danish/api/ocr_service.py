import os
import fitz
import base64
import requests
import logging

logger = logging.getLogger(__name__)

def _get_base64_image(page) -> str:
    """Render a PDF page to a JPEG image and return as a base64 string."""
    # Use a scale matrix for better resolution (2x)
    mat = fitz.Matrix(2, 2)
    pix = page.get_pixmap(matrix=mat)
    img_data = pix.tobytes("jpeg")
    return base64.b64encode(img_data).decode("utf-8")

def _extract_with_mistral(pdf_path: str) -> str:
    """Extract text from PDF using Mistral's pixtral-12b-2409 vision model."""
    mistral_key = os.environ.get("MISTRAL_API_KEY")
    if not mistral_key:
        raise ValueError("MISTRAL_API_KEY environment variable is not set. Cannot run OCR.")

    url = "https://api.mistral.ai/v1/chat/completions"
    headers = {
        "Authorization": f"Bearer {mistral_key}",
        "Content-Type": "application/json"
    }
    
    extracted_text = ""
    
    try:
        with fitz.open(pdf_path) as doc:
            for page_num, page in enumerate(doc):
                logger.info(f"Extracting OCR for page {page_num + 1}/{doc.page_count} via Mistral...")
                base64_image = _get_base64_image(page)
                
                payload = {
                    "model": "pixtral-12b-2409",
                    "messages": [
                        {
                            "role": "user",
                            "content": [
                                {
                                    "type": "text", 
                                    "text": "You are a medical data extraction assistant. Extract all text exactly as written in this medical document. Do not summarize, do not add conversational filler, and do not add external information. Output only the extracted text."
                                },
                                {
                                    "type": "image_url", 
                                    "image_url": f"data:image/jpeg;base64,{base64_image}"
                                }
                            ]
                        }
                    ],
                    "temperature": 0.0
                }
                
                response = requests.post(url, headers=headers, json=payload, timeout=60)
                response.raise_for_status()
                
                data = response.json()
                page_text = data["choices"][0]["message"]["content"]
                extracted_text += page_text + "\n\n"
                
    except Exception as e:
        logger.error(f"Mistral OCR Failed: {e}")
        raise RuntimeError(f"OCR Extraction failed: {e}")
        
    return extracted_text.strip()

def _extract_with_azure(pdf_path: str) -> str:
    """Extract text from PDF using Azure Document Intelligence."""
    azure_endpoint = os.environ.get("AZURE_DOC_INTEL_ENDPOINT")
    azure_key = os.environ.get("AZURE_DOC_INTEL_KEY")
    
    if not azure_endpoint or not azure_key:
        raise ValueError("Azure Document Intelligence credentials are missing.")
        
    logger.info("Extracting OCR via Azure Document Intelligence...")
    
    # ---------------------------------------------------------
    # Placeholder: Implement Azure Document Intelligence SDK logic here
    # Example:
    # from azure.ai.documentintelligence import DocumentIntelligenceClient
    # from azure.core.credentials import AzureKeyCredential
    # client = DocumentIntelligenceClient(azure_endpoint, AzureKeyCredential(azure_key))
    # with open(pdf_path, "rb") as f:
    #     poller = client.begin_analyze_document("prebuilt-document", analyze_request=f)
    # result = poller.result()
    # return result.content
    # ---------------------------------------------------------
    
    raise NotImplementedError("Azure Document Intelligence OCR is architected but not yet fully implemented.")

def extract_text_from_pdf(pdf_path: str) -> str:
    """
    Main entrypoint for OCR extraction.
    Routes to the appropriate provider based on the OCR_PROVIDER env var.
    """
    provider = os.environ.get("OCR_PROVIDER", "mistral").lower()
    
    if provider == "azure":
        return _extract_with_azure(pdf_path)
    else:
        return _extract_with_mistral(pdf_path)
