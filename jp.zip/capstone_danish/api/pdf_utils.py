"""PDF validation utilities."""
from __future__ import annotations
import io
import fitz  # PyMuPDF


class PDFValidationError(Exception):
    pass


def validate_pdf(file_bytes: bytes, filename: str) -> None:
    """
    Validates that:
    1. The bytes represent a valid PDF.
    2. The PDF has a searchable text layer (not image-only).
    Raises PDFValidationError with a user-friendly message on failure.
    """
    try:
        doc = fitz.open(stream=file_bytes, filetype="pdf")
    except Exception:
        raise PDFValidationError(
            f"'{filename}' is not a valid PDF file. Please upload a valid PDF."
        )

    if doc.page_count == 0:
        raise PDFValidationError(f"'{filename}' contains no pages.")

    # Check for searchable text across the first 5 pages (or all if fewer)
    pages_to_check = min(5, doc.page_count)
    total_text = ""
    for i in range(pages_to_check):
        total_text += doc[i].get_text().strip()

    doc.close()
