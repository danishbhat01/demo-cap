from __future__ import annotations
import uuid
from datetime import datetime
from enum import Enum
from typing import Optional
from pydantic import BaseModel, Field


class JobStatus(str, Enum):
    QUEUED = "QUEUED"
    RUNNING = "RUNNING"
    COMPLETED = "COMPLETED"
    FAILED = "FAILED"
    CANCELLED = "CANCELLED"


class PipelineStage(BaseModel):
    name: str
    label: str
    status: str = "waiting"   # waiting | running | completed | failed
    started_at: Optional[datetime] = None
    completed_at: Optional[datetime] = None
    elapsed_seconds: Optional[float] = None


class Job(BaseModel):
    job_id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    status: JobStatus = JobStatus.QUEUED
    progress_percentage: int = 0
    current_stage: Optional[str] = None
    current_agent: Optional[str] = None

    # Timestamps
    created_at: datetime = Field(default_factory=datetime.utcnow)
    started_at: Optional[datetime] = None
    completed_at: Optional[datetime] = None

    # Derived paths (never exposed to frontend, served via endpoints)
    session_dir: Optional[str] = None
    chart_pdf_path: Optional[str] = None
    claim_pdf_path: Optional[str] = None
    report_path: Optional[str] = None
    evidence_path: Optional[str] = None
    log_path: Optional[str] = None

    error_message: Optional[str] = None

    # Original uploaded filenames (for PDF naming on export)
    chart_filename: Optional[str] = None
    claim_filename: Optional[str] = None

    # Dynamic stage list — rendered directly by the frontend
    stages: list[PipelineStage] = Field(default_factory=list)

    @property
    def elapsed_seconds(self) -> Optional[float]:
        if self.started_at is None:
            return None
        end = self.completed_at or datetime.utcnow()
        return round((end - self.started_at).total_seconds(), 1)

    def status_payload(self) -> dict:
        """Rich status dict for GET /jobs/{id}/status"""
        return {
            "status": self.status.value,
            "progress": self.progress_percentage,
            "stage": self.current_stage,
            "current_agent": self.current_agent,
            "elapsed_seconds": self.elapsed_seconds,
            "stages": [s.model_dump() for s in self.stages],
            "error_message": self.error_message,
        }
