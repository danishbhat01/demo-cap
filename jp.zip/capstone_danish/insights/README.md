# Insights & Audit Reports

This directory serves as the centralized repository for all audit reports, execution telemetry, and pipeline decision logs generated during validation runs.

## Directory Structure

* **`audit_reports/`**: Contains timestamped JSON audit reports detailing the full decision trail for each processed claim (e.g. `TC1_*.json`, `TC2_*.json`).
* **`telemetry_logs.jsonl`**: Captures runtime telemetry, guardrail interventions, and hallucination prevention events.
